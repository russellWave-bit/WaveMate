const {app,BrowserWindow,Tray,Menu,screen,ipcMain,protocol,net,dialog,nativeImage}=require('electron');
const path=require('path'), fs=require('fs');
const {pathToFileURL}=require('url');
const helpers=require('./helpers.js');
const DEFAULTS=require('./defaults.json');

protocol.registerSchemesAsPrivileged([{scheme:'wm',privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true,corsEnabled:true}}]);
if(!app.requestSingleInstanceLock()){ app.quit(); }

let cfg=Object.assign({},DEFAULTS), overlay=null, settingsWin=null, tray=null, bounds=null, display=null;
const userDir=()=>app.getPath('userData');
const cfgFile=()=>path.join(userDir(),'settings.json');
function loadCfg(){ try{ cfg=Object.assign({},DEFAULTS,JSON.parse(fs.readFileSync(cfgFile(),'utf8'))); }catch(e){ cfg=Object.assign({},DEFAULTS); } }
let saveT=null;
function saveCfg(){ clearTimeout(saveT); saveT=setTimeout(()=>{ try{ fs.writeFileSync(cfgFile(),JSON.stringify(cfg,null,2)); }catch(e){} },300); }
function send(ch,d){ if(overlay&&!overlay.isDestroyed()) overlay.webContents.send('wm:'+ch,d); if(settingsWin&&!settingsWin.isDestroyed()&&ch==='settings') settingsWin.webContents.send('wm:'+ch,d); }

/* ---------------- settings changes ---------------- */
function patch(p){
  const before=cfg; cfg=Object.assign({},cfg,p); saveCfg();
  send('settings',cfg);
  if(p.display!=null&&p.display!==before.display) moveOverlay();
  if(p.typing!=null||p.quiet!=null) syncHelpers();
  if(p.dance!=null||p.quiet!=null) syncHelpers();
  if(p.startup!=null&&app.isPackaged) app.setLoginItemSettings({openAtLogin:!!cfg.startup});
  buildTray();
}

/* ---------------- overlay window ---------------- */
function pickDisplay(){ const all=screen.getAllDisplays(); display=all[cfg.display]||screen.getPrimaryDisplay(); bounds=display.bounds; }
function createOverlay(){
  pickDisplay();
  overlay=new BrowserWindow({x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height,transparent:true,frame:false,resizable:false,movable:false,hasShadow:false,
    alwaysOnTop:true,skipTaskbar:true,focusable:false,show:false,fullscreenable:false,thickFrame:false,backgroundColor:'#00000000',
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,backgroundThrottling:false}});
  overlay.setAlwaysOnTop(true,'screen-saver');
  overlay.setIgnoreMouseEvents(true,{forward:true});
  overlay.setMenu(null);
  overlay.loadURL('wm://app/overlay.html');
  overlay.once('ready-to-show',()=>{ overlay.setBounds(bounds); overlay.showInactive(); });
  overlay.on('closed',()=>{ overlay=null; });
}
function moveOverlay(){ pickDisplay(); if(overlay){ overlay.setBounds(bounds); overlay.webContents.reload(); } }

/* ---------------- settings window ---------------- */
function openSettings(){
  if(settingsWin&&!settingsWin.isDestroyed()){ settingsWin.show(); settingsWin.focus(); return; }
  settingsWin=new BrowserWindow({width:560,height:780,title:'WaveMate settings',backgroundColor:'#0b0d0f',autoHideMenuBar:true,
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}});
  settingsWin.setMenu(null);
  settingsWin.loadURL('wm://app/settings.html');
  settingsWin.on('closed',()=>{ settingsWin=null; });
}

/* ---------------- tray ---------------- */
function buildTray(){
  if(!tray){
    let img=nativeImage.createFromPath(path.join(__dirname,'assets','icon.png'));
    if(!img.isEmpty()) img=img.resize({width:20,height:20});
    tray=new Tray(img); tray.setToolTip('WaveMate'); tray.on('click',()=>openSettings());
  }
  tray.setContextMenu(Menu.buildFromTemplate([
    {label:cfg.quiet?'Wake WaveMate (quiet is on)':'Quiet mode (hide)',click:()=>patch({quiet:!cfg.quiet})},
    {label:cfg.hidden?'Come out from the edge':'Tuck away at the edge',click:()=>send('cmd',{name:'hide'})},
    {label:'Call the eye for a fight',click:()=>send('cmd',{name:'eye'})},
    {label:'Start a focus timer ('+cfg.pomodoro+' min)',click:()=>startPomodoro()},
    {label:'Settings…',click:()=>openSettings()},
    {type:'separator'},
    {label:'Quit WaveMate',click:()=>app.quit()}
  ]));
}

/* ---------------- Windows watchers ---------------- */
let procs={win:null,keys:null,audio:null}, helperDir='';
function stop(k){ if(procs[k]){ try{ procs[k].kill(); }catch(e){} procs[k]=null; } }
function syncHelpers(){
  if(process.platform!=='win32') return;
  if(!procs.win){
    procs.win=helpers.run(helperDir,'WinWatch',line=>{
      let d; try{ d=JSON.parse(line); }catch(e){ return; }
      const list=d.list.map(w=>{ const r=screen.screenToDipRect(null,{x:w.x,y:w.y,width:w.w,height:w.h}); return {id:w.id,x:r.x-bounds.x,y:r.y-bounds.y,w:r.width,h:r.height,fg:w.fg,fs:w.fs}; });
      const floor=display.workArea.y+display.workArea.height-bounds.y;
      send('win',{list,floor}); send('fs',!!d.fs);
    },()=>{ procs.win=null; });
  }
  const wantKeys=cfg.typing&&!cfg.quiet, wantAudio=cfg.dance&&!cfg.quiet;
  if(wantKeys&&!procs.keys) procs.keys=helpers.run(helperDir,'KeyWatch',line=>{ const n=parseInt(line,10); if(n>0) send('keys',n); },()=>{ procs.keys=null; });
  if(!wantKeys) stop('keys');
  if(wantAudio&&!procs.audio) procs.audio=helpers.run(helperDir,'AudioWatch',line=>{ const v=parseFloat(line); if(!isNaN(v)) send('audio',v); },()=>{ procs.audio=null; });
  if(!wantAudio){ stop('audio'); send('audio',0); }
}

/* ---------------- time: alarms, hourly chime, focus timer ---------------- */
let lastMinute='', pomoT=null;
function startPomodoro(){
  clearTimeout(pomoT); const m=Math.max(1,cfg.pomodoro|0);
  send('cmd',{name:'alarm',arg:{label:'Focus timer started: '+m+' minutes. You can do it!'}});
  pomoT=setTimeout(()=>send('cmd',{name:'alarm',arg:{label:'Focus time is over. Stretch, drink some water!'}}),m*60000);
}
setInterval(()=>{
  const d=new Date(), hm=('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2);
  if(hm===lastMinute) return; lastMinute=hm;
  (cfg.alarms||[]).forEach(a=>{ if(a.on!==false&&a.t===hm) send('cmd',{name:'alarm',arg:{label:a.label||('Alarm '+hm)}}); });
  if(cfg.hourly&&d.getMinutes()===0) send('cmd',{name:'time'});
},15000);

/* ---------------- cursor ---------------- */
let lastC={x:-1,y:-1}, lastSend=0;
setInterval(()=>{
  if(!overlay||!bounds) return;
  const p=screen.getCursorScreenPoint(), x=p.x-bounds.x, y=p.y-bounds.y, t=Date.now();
  if(x!==lastC.x||y!==lastC.y||t-lastSend>300){ lastC={x,y}; lastSend=t; send('cursor',{x,y}); }
},16);

/* ---------------- ipc ---------------- */
function userFileOk(p){ try{ const r=path.resolve(p); return r.startsWith(path.resolve(userDir())); }catch(e){ return false; } }
ipcMain.handle('wm:getSettings',()=>cfg);
ipcMain.handle('wm:displays',()=>screen.getAllDisplays().map((d,i)=>({i,label:'Screen '+(i+1)+' ('+d.bounds.width+'x'+d.bounds.height+')'+(d.id===screen.getPrimaryDisplay().id?' - main':'')})));
ipcMain.handle('wm:readFile',(e,p)=>{ try{ if(!userFileOk(p)) return null; return fs.readFileSync(p); }catch(err){ return null; } });
ipcMain.on('wm:ignore',(e,v)=>{ if(overlay&&!overlay.isDestroyed()) overlay.setIgnoreMouseEvents(!!v,{forward:true}); });
ipcMain.on('wm:patch',(e,p)=>patch(p));
ipcMain.on('wm:ready',()=>{ send('settings',cfg); syncHelpers(); });
ipcMain.on('wm:openSettings',()=>openSettings());
ipcMain.on('wm:quit',()=>app.quit());
ipcMain.on('wm:pomodoro',()=>startPomodoro());
ipcMain.on('wm:cmd',(e,c)=>send('cmd',c));
ipcMain.on('wm:removeChar',(e,id)=>{ const u=(cfg.userChars||[]).filter(x=>x.id!==id); patch({userChars:u,character:cfg.character===id?'octopus':cfg.character}); });
ipcMain.on('wm:addChar',async()=>{
  const r=await dialog.showOpenDialog({title:'Choose a character file',filters:[{name:'3D characters',extensions:['vrm','glb','gltf']}],properties:['openFile']});
  if(r.canceled||!r.filePaths[0]) return;
  const src=r.filePaths[0], dir=path.join(userDir(),'characters'); fs.mkdirSync(dir,{recursive:true});
  const base=path.basename(src), id='u_'+Date.now().toString(36), dest=path.join(dir,id+path.extname(base));
  fs.copyFileSync(src,dest);
  patch({userChars:(cfg.userChars||[]).concat([{id,name:base.replace(/\.[^.]+$/,'').slice(0,24),file:dest}]),character:id});
});
ipcMain.on('wm:addSkin',async()=>{
  const r=await dialog.showOpenDialog({title:'Choose a skin picture (png)',filters:[{name:'Skin picture',extensions:['png']}],properties:['openFile']});
  if(r.canceled||!r.filePaths[0]) return;
  const dir=path.join(userDir(),'characters'); fs.mkdirSync(dir,{recursive:true});
  const dest=path.join(dir,'skin_'+Date.now().toString(36)+'.png'); fs.copyFileSync(r.filePaths[0],dest);
  patch({skinFile:dest,character:'blocky'});
});

/* ---------------- app ---------------- */
app.whenReady().then(()=>{
  protocol.handle('wm',req=>{
    const u=new URL(req.url); let p=decodeURIComponent(u.pathname); if(p==='/'||!p) p='/overlay.html';
    const file=path.normalize(path.join(__dirname,p));
    if(!file.startsWith(path.normalize(__dirname))) return new Response('no',{status:403});
    return net.fetch(pathToFileURL(file).toString());
  });
  loadCfg();
  helperDir=path.join(userDir(),'helpers'); try{ helpers.install(helperDir); }catch(e){}
  if(app.isPackaged) app.setLoginItemSettings({openAtLogin:!!cfg.startup});
  createOverlay(); buildTray();
  screen.on('display-metrics-changed',()=>{ pickDisplay(); if(overlay) overlay.setBounds(bounds); });
});
app.on('second-instance',()=>openSettings());
app.on('window-all-closed',()=>{});
app.on('before-quit',()=>{ Object.keys(procs).forEach(stop); });
