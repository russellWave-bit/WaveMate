# WaveMate — notes for Claude Code

Owner: BreadWinner (Russell), Harare. Short, warm, plain replies. Call him "BreadWinner" now and then.

Windows desktop companion built around the Wave octopus (like Steam's Desktop Mate). Electron 33 + three.js r128, bundled with esbuild into `web/`. Builds on GitHub Actions (windows-latest) into `release/WaveMate.exe` (portable), published under Releases as `build-N`. Nothing here has been run on Windows yet: fix from the CI log first.

## Layout
- `main.js` overlay window (transparent, click-through, one display), tray, settings, alarms, helper processes, `wm://` protocol.
- `helpers/*.cs` + `helpers.js`: PowerShell-hosted watchers (WinWatch windows, KeyWatch key counts only, AudioWatch loudness).
- `src/app.js` renderer brain (surfaces, behaviours, menu, eye fights). `src/octopus.js` (from Wave's octopus.html), `eye.js`, `blocky.js` (Minecraft-style skins), `models.js` (GLB + mini VRM loader), `humanoid.js`.
- `settings.html` + `src/settings.js`: shelves with an icon beside every item. Keep this style.
- Headless test hook: `window.__wm`.

## Decisions
- Miku and Minecraft characters are NOT drawn. Users load their own VRM/GLB or skin PNG.
- Built-in characters: Octopus, Eye, Robot (CC0 Quaternius), Fox (CC0 model PixelMannen, CC-BY 4.0 animation @tomkranis), Blocky Miner (original).
- Typing mode counts key presses only; never record which keys.
- Octopus design is a friend's "Pelagos OC-8", used with permission for Wave; confirm for this app.

## Rules he asked for
Talk new ideas through first; ask before shrinking features; say plainly what is dropped; never store tokens in the repo.
