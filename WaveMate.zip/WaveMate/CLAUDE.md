# WaveMate — notes for Claude Code

Owner: BreadWinner (Russell), Harare. Short, warm, plain replies. Call him "BreadWinner" now and then.

Windows desktop companion built around the Wave octopus (like Steam's Desktop Mate). Electron 33 + three.js r128, bundled with esbuild into `web/`. Builds on GitHub Actions (windows-latest) into `release/WaveMate.exe` (portable), published under Releases as `build-N`. Nothing here has been run on Windows yet: fix from the CI log first.

## Layout
- `main.js` overlay window (transparent, click-through, one display), tray, settings, alarms, helper processes, `wm://` protocol.
- `helpers/*.cs` + `helpers.js`: PowerShell-hosted watchers (WinWatch windows, KeyWatch key counts only, AudioWatch loudness).
- `src/app.js` renderer brain (surfaces, behaviours, menu, eye fights). `src/octopus.js` (from Wave's octopus.html), `eye.js`, `blocky.js` (Minecraft-style skins), `models.js` (GLB + mini VRM loader), `humanoid.js`.
- `settings.html` + `src/settings.js`: shelves with an icon beside every item. Keep this style.
- Headless test hook: `window.__wm`.

## Decisions
- Miku and Minecraft characters are NOT drawn. Users load their own VRM/GLB or skin PNG.
- Built-in characters: Octopus, Eye, Robot (CC0 Quaternius), Fox (CC0 model PixelMannen, CC-BY 4.0 animation @tomkranis), Blocky Miner (original).
- Typing mode counts key presses only; never record which keys.
- Octopus design is a friend's "Pelagos OC-8", used with permission for Wave; confirm for this app.

## Rules he asked for
Talk new ideas through first; ask before shrinking features; say plainly what is dropped; never store tokens in the repo.

## Round two (2026-11-15) — added
- VRM: spring-bone swaying (src/spring.js, VRM0 + VRM1 data incl. sphere colliders, motion nudge), expressions (happy/angry/sad/relaxed/surprised/blink + mouth shapes while talking). Tested only with a synthetic VRM (hair chain + joy morph), not a real Miku model yet.
- Robot/Fox: bone-aimed typing, reaching, fox tail wag, head look, sit/sleep tilt (models.js robotPost/foxPost). Note glTF strips dots from node names (UpperArm.L -> UpperArmL).
- Friends: up to 2 extra characters, each in its own overlay window (main.js buildOverlays; per-overlay cursor, windows, floor). Friends can live on the other screen; characters cannot walk between screens.
- Floor options: on taskbar / sitting in taskbar / bottom of screen (floorMode).
- Talk: bubbles or spoken (speechSynthesis), idle chatter, reacts to pats/music/typing; offline chat brain in src/talk.js; chat box is in Settings (overlay cannot take keyboard focus).
- Feeding: sushi/apple/cake dropped from the right-click menu, walks or hops to it; hunger rises over ~3 h, saved quietly.
- Character manager in Settings: rename, delete (also deletes the file), open folder.
- NOT done on purpose: link to the phone's Wave.
- Still untested on real Windows: click-through, PowerShell helpers, multi-overlay mouse hand-off, speechSynthesis voices.

## Round three (2026-11-15) — character tricks
- `src/acts.js`: list of tricks per kind (octopus 9, eye 9, robot 12, fox 9, blocky 17, people/VRM 14, other GLB 3) + `octAim` arm targets. `app.js` (startAct/tickAct/endAct) runs them in mode `'act'`, `e.act={a,id,t,p,dur,data}`; chosen in the idle roll (setting `tricks`: off/some/lots) or from the right-click "Show a trick" section / chat ("show me a trick").
- People poses in `src/actpose.js` (via humanoid.js `case 'act'`); blocky props (pickaxe, apple, block tower) in blocky.js; eye controls in eye.js (`c.act`); robot/fox use clips via `cfg.map act_*` plus bone posing in robotPost/foxPost; octopus uses arm aims + DOM props (ink cloud, juggling balls, bubbles).
- Bone reset fix in models.js: bind pose captured at load (`userData.restQ`), `newFrame()` resets bones the clips do not drive (compare with `quaternion.equals`, not `angleTo`).
- Headless check: `window.__wm.startAct(ent,id,true)`, `__wm.actIds()`.
- VRM bones are posed in the rig frame (models.js put()), tested with synthetic VRM0 and VRM1 in _test/vrmtest.mjs; real Miku-type models tested by BreadWinner only. Untested on real Windows (blocky/robot/fox/eye/octopus checked in headless Chromium).
- Summon: tray item + Ctrl+Alt+W (main.js summonAll), right-click quick row (Summon/Sleep/Tuck/Settings), floating `#pill` button when quiet or hidden (app.js pillOver, cmd `summonHere`).
