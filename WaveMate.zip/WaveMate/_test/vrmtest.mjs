import * as THREE from 'three';
import {createVRM} from '../src/models.js';
function mk(ver){
  const nodes=[]; const add=(name,pos,parent)=>{ const b=new THREE.Bone(); b.name=name; b.position.set(...pos); if(parent) parent.add(b); nodes.push(b); return b; };
  const hips=add('hips',[0,1,0]); const spine=add('spine',[0,0.1,0],hips), chest=add('chest',[0,0.15,0],spine), neck=add('neck',[0,0.15,0],chest), head=add('head',[0,0.1,0],neck);
  const sx=ver===0?-1:1; /* VRM0: character's left is at -x (faces -z) */
  const lu=add('lu',[sx*0.1,0.1,0],chest), ll=add('ll',[sx*0.3,0,0],lu); const ru=add('ru',[-sx*0.1,0.1,0],chest), rl=add('rl',[-sx*0.3,0,0],ru);
  const lul=add('lul',[sx*0.08,-0.05,0],hips), lll=add('lll',[0,-0.45,0],lul), rul=add('rul',[-sx*0.08,-0.05,0],hips), rll=add('rll',[0,-0.45,0],rul);
  const scene=new THREE.Group(); scene.add(hips); const m=new THREE.Mesh(new THREE.BoxGeometry(1,1.6,0.3),new THREE.MeshBasicMaterial()); m.position.y=0.8; scene.add(m);
  const hb=[['hips',0],['spine',1],['chest',2],['neck',3],['head',4],['leftUpperArm',5],['leftLowerArm',6],['rightUpperArm',7],['rightLowerArm',8],['leftUpperLeg',9],['leftLowerLeg',10],['rightUpperLeg',11],['rightLowerLeg',12]];
  const ext=ver===0?{VRM:{humanoid:{humanBones:hb.map(([bone,node])=>({bone,node}))}}}:{VRMC_vrm:{humanoid:{humanBones:Object.fromEntries(hb.map(([k,n])=>[k,{node:n}]))}}};
  return {scene,parser:{json:{extensions:ext},associations:new Map(),getDependency:async(t,i)=>nodes[i]}};
}
const dirs=(api,A,B)=>{ api.root.updateMatrixWorld(true); const f=n=>api.root.getObjectByName(n).getWorldPosition(new THREE.Vector3()); const a=f(A),b=f(B); return b.sub(a).normalize().toArray().map(x=>+x.toFixed(2)); };
for(const ver of [0,1]){
  const api=await createVRM(mk(ver),{});
  const run=(S,n=80)=>{ for(let i=0;i<n;i++) api.update(0.03,Object.assign({facing:1,unitScale:7},S)); };
  console.log('--- VRM'+ver);
  run({mode:'idle'});
  console.log('idle  screenRight arm dir (expect ~[+,-,0])',dirs(api,'lu','ll'),' screenLeft',dirs(api,'ru','rl'));
  const sr=(ver===0)?['ll','lu']:['ll','lu']; 
  run({mode:'pat'});
  console.log('pat   arms (expect up, outward)',dirs(api,'lu','ll'),dirs(api,'ru','rl'));
  run({mode:'sit'});
  console.log('sit   thigh (expect forward +z, down 0)',dirs(api,'lul','lll'),'calf',dirs(api,'lll',  'lll'));
  run({mode:'idle'}); run({mode:'wave'});
  console.log('wave  arm on screen-left should be up',dirs(api,'ru','rl'),'| other',dirs(api,'lu','ll'));
}
