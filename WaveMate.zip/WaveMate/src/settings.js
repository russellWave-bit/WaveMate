const wm=window.wm;
let cfg={}; let displays=[];
const BUILTIN=[['octopus','🐙','Wave Octopus','Your Wave octopus'],['eye','👁️','Wave Eye','The small mic eye'],['robot','🤖','Robot','Artist-made, CC0'],['fox','🦊','Fox','Artist-made, CC0 / CC-BY'],['blocky','⛏️','Blocky Miner','Takes any skin picture']];
const put=(k,v)=>{ cfg[k]=v; wm.send('patch',{[k]:v}); };
function h(tag,cls,html){ const e=document.createElement(tag); if(cls) e.className=cls; if(html!=null) e.innerHTML=html; return e; }
function row(icon,label,sub,control){ const r=h('div','row'); r.appendChild(h('span','ic',icon)); const l=h('div','lb',label+(sub?'<small>'+sub+'</small>':'')); r.appendChild(l); if(control) r.appendChild(control); return r; }
function toggle(key){ const s=h('div','sw'+(cfg[key]?' on':'')); s.onclick=()=>{ put(key,!cfg[key]); s.classList.toggle('on',!!cfg[key]); }; return s; }
function range(key,min,max,step,fmt){ const w=h('div'); w.style.cssText='display:flex;align-items:center;gap:8px'; const i=h('input'); i.type='range'; i.min=min; i.max=max; i.step=step; i.value=cfg[key]; const v=h('span','val',fmt(cfg[key])); i.oninput=()=>{ v.textContent=fmt(+i.value); put(key,+i.value); }; w.append(i,v); return w; }
function select(key,opts,num){ const s=h('select'); opts.forEach(o=>{ const op=h('option',null,o[1]); op.value=o[0]; if(String(cfg[key])===String(o[0])) op.selected=true; s.appendChild(op); }); s.onchange=()=>put(key,num?+s.value:s.value); return s; }
function btn(label,act,cls,arg){ const b=h('button','b '+(cls||''),label); b.onclick=()=>{ if(act==='cmd') wm.send('cmd',{name:arg}); else wm.send(act,arg); }; return b; }
function shelf(icon,title,rows){ const s=h('div','shelf'); s.appendChild(h('div','sh','<span class="ic">'+icon+'</span>'+title)); rows.forEach(r=>s.appendChild(r)); return s; }

function render(){
  const root=document.getElementById('root'); root.innerHTML='';
  /* characters */
  const grid=h('div','chars');
  const all=BUILTIN.map(b=>({id:b[0],icon:b[1],name:b[2],note:b[3]})).concat((cfg.userChars||[]).map(u=>({id:u.id,icon:'🧍',name:u.name,note:'Your file',user:true})));
  all.forEach(c=>{ const d=h('div','ch'+(cfg.character===c.id?' on':''),'<span class="e">'+c.icon+'</span><div>'+c.name+'<small>'+c.note+'</small></div>'); d.onclick=()=>{ put('character',c.id); render(); }; if(c.user){ const x=h('span','x','✕'); x.title='Remove'; x.onclick=ev=>{ ev.stopPropagation(); wm.send('removeChar',c.id); }; d.appendChild(x); } grid.appendChild(d); });
  const chShelf=shelf('🎭','Character',[]); chShelf.appendChild(grid);
  chShelf.appendChild(row('➕','Add a character file','VRM or GLB, for example a Miku model you downloaded',btn('Choose…','addChar')));
  chShelf.appendChild(row('🧱','Skin picture for the Blocky Miner','Any 64x64 or 64x32 png skin',btn('Choose…','addSkin')));
  chShelf.appendChild(row('🎨','Octopus shell colour',null,select('shell',[['white','White'],['graphite','Graphite']])));
  chShelf.appendChild(row('📏','Size','You can also scroll the mouse wheel over it',range('size',0.35,3,0.05,v=>Math.round(v*100)+'%')));
  root.appendChild(chShelf);

  root.appendChild(shelf('🚶','Moves',[
    row('🌀','Walk around on its own',null,toggle('wander')),
    row('🪑','Sit on top of windows',null,toggle('sitOnWindows')),
    row('🦘','Jump between windows',null,toggle('jumpBetween')),
    row('🧲','Follow me around','It hops after your mouse cursor',toggle('followCursor')),
    row('📌','Stay where I drop it','Float anywhere on the screen, no gravity',toggle('stayPut')),
    row('😴','Fall asleep when I am away',null,toggle('sleepWhenIdle')),
    row('⏳','Falls asleep after',null,range('sleepAfter',30,900,30,v=>Math.round(v/60*10)/10+' min'))
  ]));
  root.appendChild(shelf('👀','Reactions',[
    row('👁️','Look at my cursor',null,toggle('lookAtCursor')),
    row('🤏','Reach for my cursor','Grabs at it when the cursor comes close',toggle('grabCursor')),
    row('🥰','Enjoy head pats','Hold the cursor over its head',toggle('petting'))
  ]));
  root.appendChild(shelf('⌨️','Typing and sound',[
    row('⌨️','Imitate my typing','It only counts key presses. It never sees which keys.',toggle('typing')),
    row('🪟','Hop onto the window I am typing in',null,toggle('typingJoin')),
    row('💃','Dance when my PC plays sound','It hears how loud it is, never the sound itself',toggle('dance'))
  ]));
  root.appendChild(shelf('👁️','The little eye',[
    row('✨','Let the eye pop up now and then',null,toggle('popEye')),
    row('⚔️','Let it pick fights',null,toggle('eyeFights')),
    row('🕰️','About every',null,range('eyeEvery',3,60,1,v=>v+' min')),
    row('👋','Call the eye now',null,btn('Fight!','cmd','o','eye'))
  ]));
  /* alarms */
  const al=shelf('⏰','Time and alarms',[
    row('🕒','Tell me the time every hour',null,toggle('hourly')),
    row('🍅','Focus timer length',null,range('pomodoro',5,90,5,v=>v+' min')),
    row('▶️','Start a focus timer now',null,btn('Start','pomodoro','o'))
  ]);
  (cfg.alarms||[]).forEach((a,i)=>{ const d=h('div','alarm'); const t=h('input'); t.type='time'; t.value=a.t; t.onchange=()=>{ cfg.alarms[i].t=t.value; put('alarms',cfg.alarms); };
    const l=h('input'); l.type='text'; l.placeholder='What for?'; l.value=a.label||''; l.onchange=()=>{ cfg.alarms[i].label=l.value; put('alarms',cfg.alarms); };
    const s=h('div','sw'+(a.on!==false?' on':'')); s.onclick=()=>{ cfg.alarms[i].on=!(cfg.alarms[i].on!==false); put('alarms',cfg.alarms); s.classList.toggle('on',cfg.alarms[i].on!==false); };
    const x=h('button','b','✕'); x.onclick=()=>{ cfg.alarms.splice(i,1); put('alarms',cfg.alarms); render(); }; d.append(t,l,s,x); al.appendChild(d); });
  al.appendChild(row('➕','Add an alarm',null,btn('Add',null,null))); al.lastChild.querySelector('button').onclick=()=>{ cfg.alarms=(cfg.alarms||[]).concat([{t:'07:00',label:'',on:true}]); put('alarms',cfg.alarms); render(); };
  root.appendChild(al);
  root.appendChild(shelf('✨','Look and speed',[
    row('🌑','Shadow','"Cast" throws a shadow like Desktop Mate',select('shadow',[['cast','Cast on the screen'],['soft','Soft under it'],['off','None']])),
    row('🎞️','Frame rate','Lower is lighter on the PC',select('fps',[[30,'30'],[45,'45'],[60,'60']],true)),
    row('🪄','When it arrives',null,select('summon',[['slow','Assembles slowly'],['fast','Assembles fast'],['none','Just appears']]))
  ]));
  const scr=select('display',displays.map(d=>[d.i,d.label]),true);
  root.appendChild(shelf('🛡️','Quiet and safety',[
    row('🔇','Quiet mode','Hides it and switches off the watchers',toggle('quiet')),
    row('🎮','Hide during full-screen apps and games',null,toggle('hideFullscreen')),
    row('🖥️','Which screen',null,scr)
  ]));
  root.appendChild(shelf('🚀','Startup',[ row('🪟','Start with Windows',null,toggle('startup')) ]));
  const cr=h('div','cred','<b>Wave Octopus and Wave Eye</b>: the Pelagos OC-8 look, used with permission.<br><b>Robot</b>: Tomás Laulhé (Quaternius), CC0; morph targets by Don McCurdy.<br><b>Fox</b>: model by PixelMannen, CC0; rigging and animation by @tomkranis, CC BY 4.0.<br><b>Blocky Miner</b>: an original character made for WaveMate. Skins you add are yours.<br><b>Your own files</b>: you are responsible for the licence of any character file you add.');
  const aboutShelf=shelf('ℹ️','About and credits',[]); aboutShelf.appendChild(cr); root.appendChild(aboutShelf);
}
(async()=>{
  cfg=await wm.invoke('getSettings'); displays=await wm.invoke('displays'); render();
  wm.on('settings',s=>{ const keep=document.scrollingElement.scrollTop; const act=document.activeElement; if(act&&(act.tagName==='INPUT'&&act.type==='range')) { cfg=s; return; } cfg=s; render(); document.scrollingElement.scrollTop=keep; });
})();
