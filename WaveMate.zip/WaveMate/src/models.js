import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {makePose,stepPose} from './humanoid.js';
import {makeKeyboard,clamp,lerp,kf} from './props.js';

export function loadGLTF(src){
  const l=new GLTFLoader();
  return new Promise((res,rej)=>{
    if(typeof src==='string') l.load(src,res,undefined,rej);
    else l.parse(src,'',res,rej);
  });
}

function fitModel(scene,height){
  const box=new THREE.Box3().setFromObject(scene), size=new THREE.Vector3(); box.getSize(size);
  const k=height/Math.max(size.y,1e-4); scene.scale.multiplyScalar(k);
  const b2=new THREE.Box3().setFromObject(scene);
  scene.position.x-= (b2.min.x+b2.max.x)/2; scene.position.z-=(b2.min.z+b2.max.z)/2; scene.position.y-=b2.min.y;
  return k;
}

/* ============ animated GLB characters (artist-made models with their own clips) ============ */
const find=(names,re)=>names.find(n=>re.test(n));
export function createClipChar(gltf,cfg){
  const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
  const model=gltf.scene; rig.add(model);
  fitModel(model,cfg.height||32);
  model.traverse(o=>{ if(o.isMesh){ o.frustumCulled=false; } });
  const mixer=new THREE.AnimationMixer(model);
  const clips={}; gltf.animations.forEach(a=>{ clips[a.name]=a; });
  const names=Object.keys(clips);
  const map=Object.assign({},cfg.map||{});
  const auto={idle:/idle|stand|survey|rest/i,walk:/walk/i,run:/run/i,dance:/danc/i,sit:/sit/i,wave:/wave|hello|greet/i,jump:/jump|hop/i,pat:/thumb|yes|happy/i,punch:/punch|attack|hit/i};
  for(const k in auto) if(!map[k]){ const n=find(names,auto[k]); if(n) map[k]=n; }
  if(!map.idle) map.idle=names[0];
  const acts={}; const act=(k)=>{ const n=map[k]; if(!n||!clips[n]) return null; if(!acts[n]) acts[n]=mixer.clipAction(clips[n]); return acts[n]; };
  let cur=null, curKey='', once=0, yaw=0, kbT=0;
  const kb=makeKeyboard(); kb.scale.setScalar(4.2); kb.visible=false; rig.add(kb);
  function play(key,ts,loopOnce){
    const a=act(key)||act('idle'); if(!a) return;
    if(cur===a && !loopOnce) { a.timeScale=ts||1; return; }
    a.reset(); a.timeScale=ts||1;
    if(loopOnce){ a.setLoop(THREE.LoopOnce,1); a.clampWhenFinished=true; } else a.setLoop(THREE.LoopRepeat,Infinity);
    a.enabled=true; a.fadeIn(0.25).play(); if(cur&&cur!==a) cur.fadeOut(0.25); cur=a;
  }
  play('idle');
  const H=cfg.height||32;
  const api={
    id:cfg.id,kind:'walk',root,unit:cfg.unit||7, clips:names,
    hit:(mode)=>({cx:0,cy:H*0.5,rx:cfg.rx||H*0.4,ry:H*0.52}),
    X:{},
    update(dt,S){
      const m=S.mode; let key='idle',ts=1;
      if(m==='walk'){ if((S.speed||0)>0.8 && map.run) { key='run'; } else key='walk'; ts=0.6+0.9*(S.speed||0.5); }
      else if(m==='sit'){ key=map.sit?'sit':'idle'; }
      else if(m==='sleep'){ key=map.sit?'sit':'idle'; ts=0.25; }
      else if(m==='dance') key=map.dance?'dance':'idle';
      else if(m==='wave'||m==='grab') key=map.wave?'wave':'idle';
      else if(m==='pat') key=map.pat?'pat':'idle';
      else if(m==='jump'||m==='fall') key=map.jump?'jump':'idle';
      const sk=key+'|'+ts.toFixed(1);
      if(S.startle>0.6 && once<=0 && map.jump){ play('jump',1.2,true); once=0.8; curKey='once'; }
      else if(S.punch>0.6 && once<=0 && map.punch){ play('punch',1.4,true); once=0.7; curKey='once'; }
      else if(once>0){ once-=dt; }
      else if(sk!==curKey || (cur!==act(key)&&act(key))){ curKey=sk; play(key,ts); }
      mixer.update(dt);
      /* turn: side-on while walking, quarter turn when still (animals) or face the camera (people) */
      const f=S.facing||1; let ty=0;
      if(m==='walk') ty=f*(cfg.walkYaw!=null?cfg.walkYaw:1.15); else if(cfg.idleYaw) ty=f*cfg.idleYaw;
      yaw+=(ty-yaw)*kf(dt,9); root.rotation.y=yaw;
      rig.rotation.z=(m==='drag')?clamp(-(S.vx||0)*0.0013,-0.45,0.45):0;
      const want=m==='type'?1:0; kbT+=(want-kbT)*kf(dt,10); kb.visible=kbT>0.02; kb.scale.setScalar(4.2*kbT*(cfg.kb||1)); kb.position.set(0,H*0.42,H*0.28); kb.rotation.x=0.15;
    },
    poke(){}, startle(){}, happy(){}, jet(){}, flinch(){}, wave(){}, tap(){},
    setMood(){}, summon(){}, takeApart(){}, isApart:()=>false, assembling:()=>false, shell(){},
    dispose(){ root.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  };
  return api;
}

/* ============ VRM models (people-style characters you add yourself). Simple skeleton driver; no hair physics. ============ */
const BONES=['hips','spine','chest','neck','head','leftUpperArm','leftLowerArm','rightUpperArm','rightLowerArm','leftUpperLeg','leftLowerLeg','rightUpperLeg','rightLowerLeg'];
export async function createVRM(gltf,cfg){
  cfg=cfg||{};
  const json=gltf.parser.json, ext=json.extensions||{};
  const v0=ext.VRM, v1=ext.VRMC_vrm;
  if(!v0&&!v1) throw new Error('This file is not a VRM model.');
  const idx={};
  if(v0&&v0.humanoid) (v0.humanoid.humanBones||[]).forEach(b=>{ idx[b.bone]=b.node; });
  else if(v1&&v1.humanoid) for(const k in v1.humanoid.humanBones) idx[k]=v1.humanoid.humanBones[k].node;
  const bones={};
  for(const n of BONES) if(idx[n]!=null) bones[n]=await gltf.parser.getDependency('node',idx[n]);
  if(!bones.hips||!bones.head) throw new Error('This VRM has no usable skeleton.');
  const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
  const model=gltf.scene; if(v0) model.rotation.y=Math.PI; rig.add(model);
  model.updateMatrixWorld(true);
  const fit=fitModel(model,32);
  const blinks=[],joys=[];
  model.traverse(o=>{
    if(o.isMesh||o.isSkinnedMesh){
      o.frustumCulled=false;
      const ms=Array.isArray(o.material)?o.material:[o.material];
      const out=ms.map(m=>{ const n=new THREE.MeshLambertMaterial({map:m.map||null,color:m.color?m.color.clone():0xffffff,transparent:m.transparent,alphaTest:m.alphaTest||0,side:THREE.DoubleSide,emissive:m.emissive?m.emissive.clone():0x000000,emissiveMap:m.emissiveMap||null});
        n.skinning=!!o.isSkinnedMesh; n.morphTargets=!!o.morphTargetInfluences; n.morphNormals=false; if(m.map) m.map.encoding=THREE.sRGBEncoding; return n; });
      o.material=Array.isArray(o.material)?out:out[0];
      if(o.morphTargetDictionary){ for(const nm in o.morphTargetDictionary){
        if(/^(blink|fcl_eye_close|eye_?close)$/i.test(nm)) blinks.push([o,o.morphTargetDictionary[nm]]);
        else if(/^(joy|fcl_all_joy|happy|fcl_eye_joy)$/i.test(nm)) joys.push([o,o.morphTargetDictionary[nm]]); } }
    }
  });
  const rest={}; for(const n in bones) rest[n]=bones[n].quaternion.clone();
  const hipRest=bones.hips.position.clone();
  const feet=new THREE.Box3().setFromObject(model).min.y;
  const hipsY=new THREE.Vector3().setFromMatrixPosition(bones.hips.matrixWorld); /* world, before scaling parent; we use ratio below */
  const hipH=(()=>{ model.updateMatrixWorld(true); const v=new THREE.Vector3().setFromMatrixPosition(bones.hips.matrixWorld); const b=new THREE.Box3().setFromObject(model); return v.y-b.min.y; })();
  const pose=makePose(); const E=new THREE.Euler(), Q=new THREE.Quaternion();
  const q=(x,y,z)=>Q.setFromEuler(E.set(x,y,z,'XYZ')).clone();
  const kb=makeKeyboard(); kb.scale.setScalar(4.6); kb.visible=false; rig.add(kb);
  let blinkT=2+Math.random()*3, blinkV=0, kbT=0, dropY=0, t=0;
  const setMorph=(list,v)=>list.forEach(([o,i])=>{ o.morphTargetInfluences[i]=v; });
  const api={
    id:cfg.id||'vrm',kind:'walk',root,unit:7,
    hit:(mode)=>mode==='perch'?{cx:0,cy:5,rx:10,ry:17}:{cx:0,cy:16,rx:10,ry:17},
    X:{},
    update(dt,S){
      t+=dt; const p=stepPose(pose,S,dt);
      root.rotation.y=p.turn;
      dropY+=((-hipH*p.drop*0.98)-dropY)*kf(dt,9);
      rig.position.y=dropY+(p.bob+p.hop)*32;
      const B=bones, R=rest;
      const set=(n,dq)=>{ if(B[n]) B[n].quaternion.copy(R[n]).multiply(dq); };
      set('spine',q(p.pitch*0.6,0,p.roll*0.6)); if(B.chest) set('chest',q(p.pitch*0.4,0,p.roll*0.4));
      if(B.neck) set('neck',q(p.headX*0.4,p.headY*0.4,p.headZ*0.4)); set('head',q(p.headX*0.6,p.headY*0.6,p.headZ*0.6));
      const arm=(side,ang,fw,el)=>{
        const L=side==='left', z=L?ang:ang+Math.PI;
        const dq=new THREE.Quaternion().setFromEuler(E.set(fw,0,0)).multiply(new THREE.Quaternion().setFromEuler(E.set(0,0,z)));
        set(L?'leftUpperArm':'rightUpperArm',dq);
        set(L?'leftLowerArm':'rightLowerArm',q(0,L?-el:el,0));
      };
      arm('left',p.aLa,p.aLf,p.aLe); arm('right',p.aRa,p.aRf,p.aRe);
      set('leftUpperLeg',q(p.lLx,0,0)); set('rightUpperLeg',q(p.lRx,0,0)); set('leftLowerLeg',q(p.lLk,0,0)); set('rightLowerLeg',q(p.lRk,0,0));
      /* blinking and joy */
      blinkT-=dt; if(blinkT<0){ blinkV=1; blinkT=2.5+Math.random()*3.5; }
      blinkV=Math.max(0,blinkV-dt*7);
      const closed=(S.mode==='sleep')?1:Math.sin(Math.PI*Math.min(1,blinkV))*1;
      setMorph(blinks,clamp(closed,0,1)); setMorph(joys,S.mode==='pat'?1:0);
      const want=S.mode==='type'?1:0; kbT+=(want-kbT)*kf(dt,10); kb.visible=kbT>0.02; kb.scale.setScalar(4.6*kbT); kb.position.set(0,hipH+dropY*0+2.5,7.5); kb.rotation.x=0.15;
    },
    poke(){}, startle(){}, happy(){}, jet(){}, flinch(){}, wave(){}, tap(){},
    setMood(){}, summon(){}, takeApart(){}, isApart:()=>false, assembling:()=>false, shell(){},
    dispose(){ root.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  };
  return api;
}
