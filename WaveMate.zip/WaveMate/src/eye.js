import * as THREE from 'three';
import {ringGeo,gearGeo,lensGeo,cyl} from './geo.js';
import {clamp,lerp,kf} from './props.js';

/* The Wave mic eye (PE-1) as a small floating character: bezel, glass, scale ring, knurled focus ring, 9-blade iris, lens, barrel. */
export function createEye(){
  const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
  const body=new THREE.Group(); rig.add(body);
  const gaze=new THREE.Group(); body.add(gaze);
  const M={
    white:new THREE.MeshPhysicalMaterial({color:0xf1f2f0,roughness:0.5,clearcoat:0.3,clearcoatRoughness:0.35}),
    steel:new THREE.MeshStandardMaterial({color:0xd4d8db,metalness:0.7,roughness:0.5,envMapIntensity:0.75}),
    brushed:new THREE.MeshStandardMaterial({color:0xb4babf,metalness:0.6,roughness:0.6,envMapIntensity:0.7}),
    dark:new THREE.MeshStandardMaterial({color:0x22272c,metalness:0.4,roughness:0.6,side:THREE.DoubleSide}),
    black:new THREE.MeshStandardMaterial({color:0x0e1114,metalness:0.2,roughness:0.6}),
    orange:new THREE.MeshStandardMaterial({color:0xe4572e,metalness:0.1,roughness:0.45}),
    blade:new THREE.MeshStandardMaterial({color:0x2a3036,metalness:0.55,roughness:0.45,side:THREE.DoubleSide}),
    glass:new THREE.MeshPhysicalMaterial({color:0x10161c,roughness:0.03,clearcoat:1,clearcoatRoughness:0.02,transparent:true,opacity:0.3,depthWrite:false,envMapIntensity:1.8,side:THREE.DoubleSide}),
    coated:null
  };
  { const c=document.createElement('canvas'); c.width=8; c.height=512; const x=c.getContext('2d'); x.fillStyle='#0a0d11'; x.fillRect(0,0,8,512);
    [[0.10,10,'rgba(120,90,190,.55)'],[0.20,7,'rgba(70,150,150,.6)'],[0.30,6,'rgba(190,140,60,.5)'],[0.40,8,'rgba(90,110,190,.5)'],[0.46,4,'rgba(200,200,210,.55)']].forEach(b=>{
      [b[0],1-b[0]].forEach(v=>{ const y0=v*512,w=b[1],gg=x.createLinearGradient(0,y0-w,0,y0+w); gg.addColorStop(0,'rgba(0,0,0,0)'); gg.addColorStop(.5,b[2]); gg.addColorStop(1,'rgba(0,0,0,0)'); x.fillStyle=gg; x.fillRect(0,y0-w,8,w*2); }); });
    const t=new THREE.CanvasTexture(c); t.encoding=THREE.sRGBEncoding;
    M.coated=new THREE.MeshPhysicalMaterial({color:0xffffff,map:t,metalness:0.1,roughness:0.08,clearcoat:1,clearcoatRoughness:0.04,envMapIntensity:1.5,side:THREE.DoubleSide}); }
  const add=(geo,mat,parent,z)=>{ const m=new THREE.Mesh(geo,mat); if(z!=null) m.position.z=z; parent.add(m); return m; };

  /* rear housing: white cup + dark barrel + fins */
  const cup=new THREE.Mesh(new THREE.SphereGeometry(1.12,40,24,0,Math.PI*2,0,Math.PI*0.5),M.white); cup.rotation.x=-Math.PI/2; cup.position.z=-0.15; gaze.add(cup);
  add(cyl(0.98,1.3,48,true),M.dark,gaze,0.1);
  const fins=new THREE.InstancedMesh(cyl(0.95,0.03,40),M.brushed,6),d=new THREE.Object3D();
  for(let i=0;i<6;i++){ d.position.set(0,0,-0.55-i*0.1); d.updateMatrix(); fins.setMatrixAt(i,d.matrix); } gaze.add(fins);
  /* front bezel + orange ring */
  const bez=new THREE.Group(); bez.position.z=0.85; gaze.add(bez);
  add(new THREE.TorusGeometry(1.0,0.075,20,80),M.steel,bez);
  add(new THREE.TorusGeometry(0.93,0.04,12,80),M.orange,bez,0.04);
  /* glass */
  add(lensGeo(0.86,0.2,0.05,22),M.glass,gaze,0.9);
  /* scale ring with ticks */
  const scale=new THREE.Group(); scale.position.z=0.7; gaze.add(scale);
  add(ringGeo(0.9,0.76,0.08),M.blade,scale);
  { const minor=new THREE.InstancedMesh(new THREE.BoxGeometry(0.012,0.06,0.01),M.steel,60), major=new THREE.InstancedMesh(new THREE.BoxGeometry(0.02,0.085,0.011),M.orange,12);
    let mi=0,ji=0; for(let i=0;i<60;i++){ const a=i/60*Math.PI*2,mj=i%5===0,r=mj?0.84:0.845; d.position.set(Math.cos(a)*r,Math.sin(a)*r,0.054); d.rotation.set(0,0,a-Math.PI/2); d.updateMatrix(); (mj?major:minor).setMatrixAt(mj?ji++:mi++,d.matrix); }
    minor.count=mi; major.count=ji; scale.add(minor,major); d.rotation.set(0,0,0); }
  /* focus ring */
  const focus=new THREE.Group(); focus.position.z=0.6; gaze.add(focus); add(gearGeo(0.86,0.74,72,0.1,0.022,0.74),M.steel,focus);
  /* iris */
  const iris=new THREE.Group(); iris.position.z=0.42; gaze.add(iris); add(ringGeo(0.74,0.58,0.06),M.brushed,iris);
  const blades=[]; { const sh=new THREE.Shape(); sh.absellipse(0.26,0.05,0.26,0.11,0,Math.PI*2,false,0);
    const bg=new THREE.ExtrudeGeometry(sh,{depth:0.012,bevelEnabled:false,curveSegments:20});
    for(let i=0;i<9;i++){ const b=new THREE.Mesh(bg,M.blade); b.userData.a=i*Math.PI*2/9; iris.add(b); blades.push(b); } }
  /* lens element */
  add(lensGeo(0.6,0.13,0.1,24),M.coated,gaze,0.22);
  /* two small drive motors */
  [-1,1].forEach(sg=>{ const m=add(cyl(0.12,0.5,20),M.black,gaze,0.25); m.position.x=sg*1.1; const c=add(cyl(0.125,0.04,20),M.orange,gaze,-0.02); c.position.x=sg*1.1; });

  const st={ap:0.25,look:{x:0,y:0},spin:0,t:0,tap:0,startle:0,happy:0,jump:0,jumpV:0,rigY:0,ex:0,wob:0};
  const api={
    id:'eye',kind:'float',root,unit:44,
    hit:(mode)=>mode==='perch'?{cx:0,cy:1.2,rx:1.5,ry:1.4}:{cx:0,cy:0,rx:1.5,ry:1.5},
    X:{}, lift:(k)=>k==='floor'?1.25:0,
    update(dt,c){
      c=c||{}; st.t+=dt;
      const dance=c.dance||0, sleep=(c.sleep||0)>0.5?1:0;
      const lx=c.look?clamp(c.lookX,-1,1):Math.sin(st.t*0.6)*0.3, ly=c.look?clamp(c.lookY,-1,1):Math.sin(st.t*0.43+1)*0.2;
      st.look.x+=(lx-st.look.x)*kf(dt,8); st.look.y+=(ly-st.look.y)*kf(dt,8);
      gaze.rotation.y=st.look.x*0.55; gaze.rotation.x=-st.look.y*0.45;
      st.startle*=Math.exp(-dt*1.6); st.happy*=Math.exp(-dt*0.9); st.tap*=Math.exp(-dt*4); st.wob*=Math.exp(-dt*3);
      st.jumpV+=(-34*st.jump-7*st.jumpV)*dt; st.jump+=st.jumpV*dt;
      const apT=sleep?0.03:(st.startle>0.15?0.97:(st.happy>0.2?0.1:(dance>0.3?0.35+0.3*Math.abs(Math.sin(st.t*4)):0.25+0.12*Math.sin(st.t*0.8))));
      st.ap+=(apT-st.ap)*kf(dt,st.startle>0.15?14:5);
      const tb=0.2+(1.4-0.2)*st.ap;
      blades.forEach(b=>{ const a=b.userData.a; b.position.set(Math.cos(a)*0.55,Math.sin(a)*0.55,-0.03); b.rotation.z=a+Math.PI/2+tb; });
      const sp=(sleep?0.1:1)+dance*2+st.tap*5+st.happy*2+st.startle*4;
      scale.rotation.z+=0.4*sp*dt; focus.rotation.z-=1.1*sp*dt;
      const f=c.float==null?1:c.float, sw=Math.sin(st.t*5.5)*dance;
      body.position.set(0.06*Math.sin(st.t*0.4)*f+0.2*sw,(0.1*Math.sin(st.t*1.1)+0.03*Math.sin(st.t*0.43))*f+st.jump+0.15*Math.abs(Math.sin(st.t*5.5))*dance,0);
      body.rotation.z=clamp(-(c.vx||0)*0.012,-0.5,0.5)+0.18*sw+0.2*Math.sin(st.t*14)*st.happy+st.wob*Math.sin(st.t*30)*0.2;
      body.rotation.y=Math.sin(st.t*0.3)*0.1*f;
      const bs=1+0.012*Math.sin(st.t*2); body.scale.set(bs,bs,bs);
      st.rigYT=(c.perch>0.5)?-(body.position.y-0.95):0;
      st.rigY+=(st.rigYT-st.rigY)*kf(dt,7); rig.position.y=st.rigY;
    },
    setMood(){}, poke(){ st.startle=1; st.jumpV+=3; st.ap=0.97; },
    startle(){ st.startle=1; st.jumpV+=2.4; }, happy(){ st.happy=1; }, jet(){ st.jumpV+=2; }, flinch(){ st.jumpV+=1.6; st.wob=1; },
    wave(){ st.happy=Math.max(st.happy,0.8); }, tap(){ st.tap=1; },
    summon(){}, takeApart(){}, isApart:()=>false, assembling:()=>false, shell(){},
    dispose(){ root.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  };
  return api;
}
