import * as THREE from 'three';
import {createOctopus} from './octopus.js';
import {createEye} from './eye.js';
import {createBlocky,skinFromBytes} from './blocky.js';
import {loadGLTF,createClipChar,createVRM} from './models.js';
import {makeKeyboard,makeBlob,clamp,lerp,kf} from './props.js';
import {DEFAULTS,BUILTIN} from './defaults.js';

const wm=window.wm;
const BASE=window.WM_BASE!=null?window.WM_BASE:'wm://app/';
let cfg=Object.assign({},DEFAULTS);
let W=innerWidth,H=innerHeight;

/* ======================= renderer, camera, light ======================= */
const canvas=document.getElementById('gl');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,premultipliedAlpha:true});
renderer.setClearColor(0x000000,0);
renderer.outputEncoding=THREE.sRGBEncoding;
renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.05;
const scene=new THREE.Scene();
const FOV=12, camera=new THREE.PerspectiveCamera(FOV,1,10,1e6);
function resize(){
  W=innerWidth; H=innerHeight;
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5)); renderer.setSize(W,H,false);
  canvas.style.width=W+'px'; canvas.style.height=H+'px';
  camera.aspect=W/H; const D=(H/2)/Math.tan(THREE.MathUtils.degToRad(FOV/2));
  camera.position.set(W/2,H/2,D); camera.lookAt(W/2,H/2,0); camera.far=D*4; camera.updateProjectionMatrix();
}
(function env(){
  const s=new THREE.Scene(), g=new THREE.SphereGeometry(50,32,16), pos=g.attributes.position, cols=[];
  for(let i=0;i<pos.count;i++){ const y=pos.getY(i)/50, c=new THREE.Color().setHSL(0.58,0.04,0.22+0.5*(y*0.5+0.5)); cols.push(c.r,c.g,c.b); }
  g.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));
  s.add(new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide})));
  const box=(w,h,p,k)=>{ const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({color:new THREE.Color().setScalar(k),side:THREE.DoubleSide})); m.position.set(p[0],p[1],p[2]); m.lookAt(0,0,0); s.add(m); };
  box(30,20,[-25,25,30],6); box(20,30,[35,10,12],4); box(40,10,[0,45,-10],5); box(25,12,[0,-22,35],1.4); box(10,40,[-40,0,-10],2.5); box(18,18,[10,12,48],3);
  const pm=new THREE.PMREMGenerator(renderer); scene.environment=pm.fromScene(s,0.02).texture; pm.dispose();
})();
const key=new THREE.DirectionalLight(0xffffff,1.5); key.position.set(-0.4,0.8,1).normalize().multiplyScalar(1000); scene.add(key);
key.position.set(-400,800,1000);
const hemi=new THREE.HemisphereLight(0xffffff,0xaab4ba,0.5); scene.add(hemi);
const blob=makeBlob(); scene.add(blob);

/* ======================= small helpers ======================= */
const $=s=>document.querySelector(s), fx=$('#fx'), menuEl=$('#menu');
const rnd=(a,b)=>a+Math.random()*(b-a), pick=a=>a[(Math.random()*a.length)|0];
let now=0; /* seconds */
function el(tag,cls,txt,parent){ const e=document.createElement(tag); if(cls) e.className=cls; if(txt!=null) e.textContent=txt; (parent||fx).appendChild(e); return e; }
function bubble(text,ent,secs){
  const b=el('div','bubble',text); const rect=headPos(ent);
  b.style.left=clamp(rect.x,80,W-80)+'px'; b.style.top=clamp(rect.y-14,40,H)+'px';
  const follow=setInterval(()=>{ const r=headPos(ent); b.style.left=clamp(r.x,80,W-80)+'px'; b.style.top=clamp(r.y-14,40,H)+'px'; },60);
  setTimeout(()=>{ b.classList.add('out'); },(secs||3)*1000); setTimeout(()=>{ clearInterval(follow); b.remove(); },(secs||3)*1000+500);
}
function floatText(txt,x,y,cls){ const e=el('div','float '+(cls||''),txt); e.style.left=x+'px'; e.style.top=y+'px'; setTimeout(()=>e.remove(),1700); }
function chime(){ try{ const a=chime.a||(chime.a=new AudioContext()); [660,880,1100].forEach((f,i)=>{ const o=a.createOscillator(),g=a.createGain(); o.frequency.value=f; o.type='sine'; g.gain.setValueAtTime(0.0001,a.currentTime+i*0.18); g.gain.exponentialRampToValueAtTime(0.18,a.currentTime+i*0.18+0.02); g.gain.exponentialRampToValueAtTime(0.0001,a.currentTime+i*0.18+0.4); o.connect(g).connect(a.destination); o.start(a.currentTime+i*0.18); o.stop(a.currentTime+i*0.18+0.45); }); }catch(e){} }

/* ======================= world: windows -> surfaces ======================= */
let wins=[], floorY=H-48, edges=[];
function buildEdges(){
  edges=[];
  const out=[];
  for(let i=0;i<wins.length;i++){
    const w=wins[i]; if(w.fs) continue;
    const y=w.y; if(y<110||y>floorY-30) continue;
    let segs=[[Math.max(0,w.x+6),Math.min(W,w.x+w.w-6)]];
    for(let j=0;j<i;j++){
      const u=wins[j]; if(y>=u.y-2&&y<=u.y+u.h+2){ const a=u.x,b=u.x+u.w; const nx=[]; segs.forEach(([s0,s1])=>{ if(b<=s0||a>=s1){ nx.push([s0,s1]); } else { if(a>s0) nx.push([s0,a]); if(b<s1) nx.push([b,s1]); } }); segs=nx; }
    }
    segs.forEach(([s0,s1])=>{ if(s1-s0>=110) out.push({id:w.id,x0:s0,x1:s1,y,kind:'win',fg:!!w.fg}); });
  }
  edges=out;
  edges.push({id:'floor',x0:0,x1:W,y:floorY,kind:'floor'});
}
function winById(id){ return wins.find(w=>w.id===id); }
function edgeOf(surf,x){
  if(!surf) return null;
  if(surf.kind==='floor') return edges[edges.length-1];
  return edges.find(e=>e.id===surf.id&&x>=e.x0-4&&x<=e.x1+4)||null;
}

/* ======================= characters ======================= */
const userFiles={};
async function makeChar(id){
  if(id==='octopus'){ const c=createOctopus(); c.shell(cfg.shell); return c; }
  if(id==='eye') return createEye();
  if(id==='blocky'){ const c=createBlocky(); if(cfg.skinFile){ try{ const buf=await wm.invoke('readFile',cfg.skinFile); if(buf){ const s=await skinFromBytes(buf); c.setSkin(s.canvas,s.slim); } }catch(e){ console.warn('skin',e); } } return c; }
  if(id==='robot'){ const g=await loadGLTF(BASE+'assets/robot.glb'); return createClipChar(g,{id:'robot',height:32,unit:7,walkYaw:1.15,map:{idle:'Idle',walk:'Walking',run:'Running',dance:'Dance',sit:'Sitting',wave:'Wave',jump:'Jump',pat:'ThumbsUp',punch:'Punch'}}); }
  if(id==='fox'){ const g=await loadGLTF(BASE+'assets/fox.glb'); return createClipChar(g,{id:'fox',height:21,unit:7,walkYaw:Math.PI/2,idleYaw:0.9,rx:15,kb:0.8,map:{idle:'Survey',walk:'Walk',run:'Run'}}); }
  const uc=(cfg.userChars||[]).find(u=>u.id===id);
  if(uc){ const buf=await wm.invoke('readFile',uc.file); if(!buf) throw new Error('file missing'); const ab=buf.buffer?buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength):buf; const g=await loadGLTF(ab);
    try{ return await createVRM(g,{id}); }catch(e){ return createClipChar(g,{id,height:32,unit:7,walkYaw:1.15}); } }
  return createOctopus();
}

const ent={char:null,x:W/2,y:-250,vx:0,vy:0,facing:1,mode:'fall',t:0,next:2,surf:null,tx:0,size:1,startle:0,punch:0,tapL:0,tapR:0,
  sitting:false,forced:null,forcedUntil:0,drag:null,hover:false,stay:false,hidden:false,music:0,typeUntil:0,wp:0,lastAct:0,hoverT:0,patUntil:0,patCool:0,
  jump:null,waveUntil:0,grabOn:false,followT:0,kbOct:null,tapAmt:[0,0,0,0,0,0,0,0],aimW:[0,0,0,0,0,0,0,0],swat:null,zzz:0,sleepy:0,joined:false};
let loading=false;
async function setCharacter(id,first){
  if(loading) return; loading=true;
  try{
    const c=await makeChar(id);
    if(ent.char){ scene.remove(ent.char.root); ent.char.dispose(); }
    ent.char=c; scene.add(c.root); ent.kbOct=null;
    if(id==='octopus'){ const kb=makeKeyboard(); kb.scale.setScalar(1.2); kb.position.set(0,-3.05,2.05); kb.rotation.x=0.25; kb.visible=false; c.body.add(kb); ent.kbOct=kb; if(cfg.summon!=='none'&&first!==false) c.summon(cfg.summon); }
    ent.mode='fall'; ent.surf=null; ent.vy=0; ent.t=0;
  }catch(e){ console.error(e); floatText('Could not load that character',W/2,H/2); }
  loading=false;
}
const sc=()=>ent.char.unit*cfg.size;

/* nominal head position (screen px) for bubbles and pats */
function hitRegion(e){
  const c=e.char; if(!c) return null; const k=modeKey(e), h=c.hit(k), s=e.char.unit*cfg.size, lift=c.lift?c.lift(k)*s:0;
  return {cx:e.x+h.cx*s, cy:e.y-(h.cy*s)-lift, rx:h.rx*s, ry:h.ry*s};
}
function modeKey(e){ if(!e.surf||e.mode==='jump'||e.mode==='fall'||e.mode==='drag') return 'air'; return e.sitting?'perch':'floor'; }
function headPos(e){ const r=hitRegion(e); return r?{x:r.cx,y:r.cy-r.ry}:{x:e.x,y:e.y-100}; }

/* ======================= settings / messages from the PC side ======================= */
function applySettings(s){
  const prev=cfg; cfg=Object.assign({},DEFAULTS,s);
  canvas.style.filter=cfg.shadow==='cast'?'drop-shadow(-11px 9px 6px rgba(0,0,0,0.30))':'none';
  blob.visible=cfg.shadow!=='off';
  if(ent.char&&ent.char.id==='octopus'&&prev.shell!==cfg.shell) ent.char.shell(cfg.shell);
  if(!ent.char||prev.character!==cfg.character||(cfg.character==='blocky'&&prev.skinFile!==cfg.skinFile)||JSON.stringify(prev.userChars)!==JSON.stringify(cfg.userChars)&&cfg.character!==ent.char.id) setCharacter(cfg.character,!ent.char);
  if(cfg.hidden!==ent.hidden) setHidden(cfg.hidden);
  ent.stay=!!cfg.stayPut&&ent.stay;
  scheduleEye();
}
wm.on('settings',applySettings);
wm.on('win',d=>{ wins=d.list||[]; floorY=d.floor||floorY; buildEdges(); });
wm.on('cursor',p=>{ cur.x=p.x; cur.y=p.y; });
wm.on('keys',n=>onKeys(n));
wm.on('audio',l=>{ audioLevel=l; });
wm.on('fs',v=>{ fullscreenOn=!!v; });
wm.on('cmd',c=>runCommand(c.name,c.arg));
const cur={x:W/2,y:H/2,px:W/2,py:H/2,v:0};
let audioLevel=0, fullscreenOn=false, lastCursorMove=0;

function runCommand(name,arg){
  const e=ent;
  switch(name){
    case 'sit': force('sit',60); break;
    case 'wander': e.forced=null; e.stay=false; wm.send('patch',{stayPut:false}); break;
    case 'dance': force('dance',20); break;
    case 'sleep': force('sleep',9999); break;
    case 'wave': e.waveUntil=now+2.4; e.char&&e.char.wave(); break;
    case 'time': { const d=new Date(); const t=d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'}); bubble('It is '+t,e,4); e.waveUntil=now+1.5; break; }
    case 'alarm': { chime(); e.waveUntil=now+3.5; bubble(arg&&arg.label||'Time is up!',e,6); if(e.char) e.char.happy(1); break; }
    case 'hide': setHidden(!e.hidden); wm.send('patch',{hidden:e.hidden}); break;
    case 'eye': startEye(true); break;
    case 'eyeVisit': startEye(false); break;
    case 'eyeAway': eyeLeave(); break;
    case 'summon': if(e.char&&e.char.id==='octopus') e.char.summon(cfg.summon==='none'?'slow':cfg.summon); break;
    case 'apart': if(e.char&&e.char.id==='octopus') e.char.takeApart(!e.char.isApart()); break;
    case 'follow': wm.send('patch',{followCursor:!cfg.followCursor}); break;
    case 'drop': e.mode='fall'; e.surf=null; e.vy=0; break;
    default: break;
  }
}
function force(mode,secs){ ent.forced=mode; ent.forcedUntil=now+secs; ent.stay=false; if(ent.hidden) setHidden(false); }
function setHidden(v){ ent.hidden=v; if(v){ ent.forced=null; ent.mode='hide'; const hw=(hitRegion(ent)||{rx:80}).rx; ent.tx=(ent.x<W/2)?-hw*0.35:W+hw*0.35; ent.surf={kind:'floor'}; } else { ent.mode='idle'; ent.tx=clamp(ent.x,120,W-120); ent.t=0; } }

/* ======================= typing / music input ======================= */
const TAP_ARMS=[7,0,6,1], TAP_X=[-0.55,0.55,-1.35,1.35];
function onKeys(n){
  if(!cfg.typing||cfg.quiet) return;
  now=performance.now()/1000; ent.lastAct=now;
  ent.typeUntil=now+2.2;
  for(let i=0;i<Math.min(n,3);i++){
    if(Math.random()<0.5) ent.tapL=1; else ent.tapR=1;
    const a=(Math.random()*4)|0; ent.tapAmt[TAP_ARMS[a]]=1;
  }
  if(ent.char) ent.char.tap&&ent.char.tap();
}

/* ======================= behaviour ======================= */
function landOn(e,edge){
  e.y=edge.y; e.vy=0; e.vx=0;
  e.surf=edge.kind==='floor'?{kind:'floor'}:{kind:'win',id:edge.id,relX:0};
  if(edge.kind==='win'){ const w=winById(edge.id); e.surf.relX=e.x-(w?w.x:0); }
  e.mode='idle'; e.t=0; e.next=rnd(0.6,2);
  if(e.char&&e.char.id==='octopus') e.char.flinch();
}
function nearestEdge(x,y,filter){
  let best=null,bd=1e9;
  edges.forEach(ed=>{ if(filter&&!filter(ed)) return; const cx=clamp(x,ed.x0+40,ed.x1-40), d=Math.abs(cx-x)+Math.abs(ed.y-y)*0.6; if(d<bd){ bd=d; best=ed; } });
  return best;
}
function startJump(e,ed,x){
  const x1=clamp(x==null?rnd(ed.x0+60,ed.x1-60):x,ed.x0+50,ed.x1-50);
  const dist=Math.hypot(x1-e.x,ed.y-e.y);
  e.jump={x0:e.x,y0:e.y,x1,y1:ed.y,t:0,T:clamp(dist/620,0.5,1.2),h:70+dist*0.16,edge:ed};
  e.mode='jump'; e.surf=null; e.facing=x1>=e.x?1:-1;
  if(e.char&&e.char.id==='octopus') e.char.jet();
}
function sitOk(e){ return e.surf&&(e.surf.kind==='win'?cfg.sitOnWindows:true); }

function think(e,dt){
  const c=e.char; if(!c) return;
  const isFloat=c.kind==='float';
  /* where am I standing? ride the window */
  if(e.surf&&e.surf.kind==='win'){
    const w=winById(e.surf.id);
    if(w){ e.x=w.x+e.surf.relX; e.y=w.y; }
    const ed=edgeOf(e.surf,e.x); if(!w||!ed){ e.mode='fall'; e.surf=null; e.vy=0; e.vx=0; }
    else e.y=ed.y;
  } else if(e.surf&&e.surf.kind==='floor') e.y=floorY;

  const act=Math.max(e.lastAct,lastCursorMove);
  /* music -> dance */
  e.music+=(audioLevel-e.music)*kf(dt,6);

  switch(e.mode){
    case 'fall': {
      const g=isFloat?420:2300, term=isFloat?300:1500;
      e.vy=Math.min(term,e.vy+g*dt); e.vx*=Math.exp(-dt*1.6);
      const oy=e.y; e.x=clamp(e.x+e.vx*dt,30,W-30); e.y+=e.vy*dt;
      let land=null; for(const ed of edges){ if(oy<=ed.y+1&&e.y>=ed.y&&e.x>=ed.x0&&e.x<=ed.x1&&(!land||ed.y<land.y)) land=ed; }
      if(!land&&e.y>=floorY) land=edges[edges.length-1];
      if(land){ landOn(e,land); }
      break; }
    case 'jump': {
      const j=e.jump; j.t+=dt; const s=clamp(j.t/j.T,0,1), es=s*s*(3-2*s)*0.35+s*0.65;
      e.x=lerp(j.x0,j.x1,es); e.y=lerp(j.y0,j.y1,s)-4*j.h*s*(1-s); e.vx=(j.x1-j.x0)/j.T; e.vy=(j.y1-j.y0)/j.T;
      if(s>=1){ const ed=j.edge; const real=edgeOf(ed.kind==='floor'?{kind:'floor'}:{kind:'win',id:ed.id},e.x)||nearestEdge(e.x,e.y); landOn(e,real||ed); e.jump=null; }
      break; }
    case 'drag': break;
    case 'hide': {
      e.x+=(e.tx-e.x)*kf(dt,5); e.y=floorY; break; }
    default: surfaceBehaviour(e,dt,act);
  }
  if(e.mode!=='fall'&&e.mode!=='jump'&&e.mode!=='drag'&&e.surf&&e.surf.kind==='win'){ const w=winById(e.surf.id); if(w) e.surf.relX=e.x-w.x; }
}

function surfaceBehaviour(e,dt,act){
  const ed=edgeOf(e.surf,e.x); if(!ed&&!e.stay){ e.mode='fall'; e.surf=null; return; }
  e.t+=dt; e.sitting=false;
  const calm=now-act, typing=now<e.typeUntil&&cfg.typing;
  /* forced states from the menu */
  if(e.forced&&now<e.forcedUntil){
    e.mode=e.forced; if(e.mode==='sit'||e.mode==='sleep') e.sitting=sitOk(e)||true; if(e.mode==='dance') e.sitting=false; return;
  } else e.forced=null;
  /* hide */
  if(e.hidden){ e.mode='hide'; return; }
  /* typing imitation */
  if(typing){
    e.mode='type'; e.sitting=!!e.surf&&e.surf.kind==='win';
    if(cfg.typingJoin&&!e.joined){ e.joined=true; const fg=edges.find(g=>g.fg&&g.kind==='win'); if(fg&&!(e.surf&&e.surf.kind==='win'&&e.surf.id===fg.id)){ startJump(e,fg,clamp(e.x,fg.x0+60,fg.x1-60)); return; } }
    return;
  } else e.joined=false;
  /* music */
  if(cfg.dance&&e.music>0.1){ e.mode='dance'; return; }
  /* pat / wave one-shots */
  if(now<e.patUntil){ e.mode='pat'; return; }
  if(now<e.waveUntil){ e.mode='wave'; return; }
  /* sleeping */
  if(cfg.sleepWhenIdle&&calm>cfg.sleepAfter&&!cfg.followCursor){ e.mode='sleep'; e.sitting=true; return; }
  if(e.mode==='sleep'){ e.mode='idle'; e.t=0; e.next=1.5; if(e.char) e.char.startle(0.6); e.startle=0.6; }
  /* grabbing the cursor */
  if(cfg.grabCursor&&e.grabOn){ e.mode='grab'; return; }
  /* following the cursor */
  if(cfg.followCursor&&now-lastCursorMove<10){ follow(e,dt); return; }
  if(e.mode==='walk'){
    const dir=Math.sign(e.tx-e.x), sp=(e.char.kind==='float'?110:125)*Math.max(0.7,Math.sqrt(cfg.size));
    e.facing=dir||e.facing; e.x+=dir*sp*dt; e.wp+=dt*7;
    const lo=ed?ed.x0+40:40, hi=ed?ed.x1-40:W-40;
    if(Math.abs(e.tx-e.x)<6||e.x<lo||e.x>hi){ e.x=clamp(e.x,lo,hi); e.mode='idle'; e.t=0; e.next=rnd(1.5,5); }
    return;
  }
  if(e.mode==='sit'){ e.sitting=true; if(e.t>e.next){ e.mode='idle'; e.t=0; e.next=rnd(0.5,2); } return; }
  if(e.stay){ e.mode='idle'; return; }
  e.mode='idle';
  if(e.t>e.next){
    e.t=0; e.next=rnd(2,6);
    const roll=Math.random(), canSit=sitOk(e);
    if(cfg.wander&&roll<0.38&&ed){ e.tx=rnd(ed.x0+50,ed.x1-50); e.mode='walk'; if(Math.abs(e.tx-e.x)<80) e.tx=e.x+(Math.random()<0.5?-1:1)*140; e.tx=clamp(e.tx,ed.x0+40,ed.x1-40); }
    else if(roll<0.62&&canSit){ e.mode='sit'; e.sitting=true; e.next=rnd(10,45); }
    else if(roll<0.8&&cfg.jumpBetween){
      const cand=edges.filter(g=>Math.abs((g.x0+g.x1)/2-e.x)<900&&Math.abs(g.y-e.y)<520&&g!==ed&&!(ed&&g.id===ed.id&&g.kind===ed.kind));
      if(cand.length&&(cfg.sitOnWindows||cand.some(g=>g.kind==='floor'))){ const t=pick(cfg.sitOnWindows?cand:cand.filter(g=>g.kind==='floor')); startJump(e,t); }
    }
    else if(roll<0.9){ e.waveUntil=now+2.2; if(e.char) e.char.wave(); }
  }
}
function follow(e,dt){
  const cx=cur.x, cy=cur.y; e.followT-=dt;
  const ed=edgeOf(e.surf,e.x);
  if(e.followT<=0){
    e.followT=0.5;
    const best=nearestEdge(cx,cy,g=>g.y>cy-30&&(cfg.sitOnWindows||g.kind==='floor'));
    if(best&&(!ed||best.y!==ed.y||best.id!==ed.id)&&Math.abs(best.y-(ed?ed.y:0))>6) { startJump(e,best,clamp(cx,best.x0+60,best.x1-60)); return; }
  }
  const dx=cx-e.x, dir=Math.sign(dx);
  if(Math.abs(dx)>90){ e.mode='walk'; e.facing=dir; const sp=170; e.x+=dir*sp*dt; e.wp+=dt*8; if(ed) e.x=clamp(e.x,ed.x0+30,ed.x1-30); e.tx=cx; }
  else { e.mode='idle'; e.facing=dir||e.facing; }
}

/* ======================= pointer: hover, drag, poke, menu ======================= */
let menuOpen=false, ignoring=true;
function setIgnore(v){ if(v!==ignoring){ ignoring=v; wm.send('ignore',v); } }
function inEllipse(r,x,y){ const dx=(x-r.cx)/r.rx, dy=(y-r.cy)/r.ry; return dx*dx+dy*dy<=1; }
addEventListener('pointerdown',ev=>{
  if(menuOpen){ if(!menuEl.contains(ev.target)) closeMenu(); return; }
  if(ev.button!==0||!ent.char) return;
  const r=hitRegion(ent); if(!r||!inEllipse(r,ev.clientX,ev.clientY)) return;
  ent.drag={ox:ev.clientX-ent.x,oy:ev.clientY-ent.y,sx:ev.clientX,sy:ev.clientY,moved:false,lx:ev.clientX,ly:ev.clientY,lt:performance.now()};
  ent.dragMode=ent.mode; ent.vx=ent.vy=0; ent.lastAct=now; if(ent.hidden){ setHidden(false); wm.send('patch',{hidden:false}); }
  canvas.setPointerCapture&&canvas.setPointerCapture(ev.pointerId);
});
addEventListener('pointermove',ev=>{
  const d=ent.drag; if(!d) return;
  if(!d.moved&&Math.hypot(ev.clientX-d.sx,ev.clientY-d.sy)>5){ d.moved=true; ent.mode='drag'; ent.surf=null; ent.sitting=false; ent.forced=null; ent.stay=false; }
  if(d.moved){
    const t=performance.now(), dt=Math.max(0.008,(t-d.lt)/1000);
    ent.vx=lerp(ent.vx,(ev.clientX-d.lx)/dt,0.4); ent.vy=lerp(ent.vy,(ev.clientY-d.ly)/dt,0.4);
    d.lx=ev.clientX; d.ly=ev.clientY; d.lt=t;
    ent.x=clamp(ev.clientX-d.ox,10,W-10); ent.y=clamp(ev.clientY-d.oy,60,H+20);
  }
});
addEventListener('pointerup',ev=>{
  const d=ent.drag; if(!d) return; ent.drag=null; ent.lastAct=now;
  if(!d.moved){ poke(ev); return; }
  /* dropped onto a window's title bar -> sit on top of it */
  const snap=edges.find(g=>g.kind==='win'&&ent.x>=g.x0&&ent.x<=g.x1&&ent.y>=g.y-30&&ent.y<=g.y+170&&cfg.sitOnWindows);
  ent.vx=clamp(ent.vx*0.5,-700,700); ent.vy=clamp(ent.vy*0.3,-500,500);
  if(cfg.stayPut){ ent.stay=true; ent.surf=null; ent.mode='idle'; ent.vx=ent.vy=0; return; }
  if(snap){ ent.y=snap.y; landOn(ent,snap); ent.mode='sit'; ent.next=rnd(12,40); ent.t=0; ent.sitting=true; }
  else { ent.mode='fall'; ent.vy=Math.max(0,ent.vy); }
});
addEventListener('contextmenu',ev=>{ ev.preventDefault(); const r=hitRegion(ent); if(r&&inEllipse(r,ev.clientX,ev.clientY)) openMenu(ev.clientX,ev.clientY); });
addEventListener('wheel',ev=>{
  if(menuOpen||!ent.hover) return; const k=ev.deltaY<0?1.06:1/1.06; const s=clamp(cfg.size*k,0.35,3); cfg.size=s; wm.send('patch',{size:+s.toFixed(3)});
},{passive:true});
function poke(ev){
  const c=ent.char; if(!c) return; ent.startle=1; ent.lastAct=now;
  const r=hitRegion(ent); const head=r&&ev.clientY<r.cy+r.ry*0.1;
  if(c.id==='octopus'){ if(head||ent.surf==null) c.poke('head'); else { const o=((ev.clientX-ent.x)/(r.rx))>0?(Math.random()<0.5?1:2):(Math.random()<0.5?6:5); c.poke(o); } }
  else { c.poke(); }
  if(ent.mode==='sleep') ent.forced=null;
  floatText(pick(['!','?!','Hey!','Oh!','Boop!']),ev.clientX,ev.clientY-30);
}
function updateHover(dt){
  const r=hitRegion(ent); const over=!!r&&inEllipse(r,cur.x,cur.y)&&!fullscreenOn&&!cfg.quiet;
  ent.hover=over;
  setIgnore(!(over||menuOpen||!!ent.drag));
  /* patting: stay over the head for a moment */
  if(r&&over&&cfg.petting&&!ent.drag&&ent.surf&&cur.y<r.cy-r.ry*0.15){ ent.hoverT+=dt; if(ent.hoverT>0.7&&now>ent.patCool&&ent.mode!=='sleep'){ ent.patUntil=now+1.8; ent.patCool=now+7; ent.hoverT=0; ent.char.happy(1); for(let i=0;i<5;i++) setTimeout(()=>floatText('❤',headPos(ent).x+rnd(-30,30),headPos(ent).y+rnd(-5,25),'heart'),i*160); } }
  else ent.hoverT=Math.max(0,ent.hoverT-dt*2);
  /* reaching for the cursor */
  const hr=r?Math.hypot((cur.x-r.cx)/ (r.rx*1.55),(cur.y-r.cy)/(r.ry*1.35)):9;
  const fast=cur.v>900;
  ent.grabOn=cfg.grabCursor&&!ent.drag&&!!r&&!over&&!fast&&ent.surf!=null&&(ent.grabOn?hr<1.2:hr<1);
}

/* ======================= right-click menu ======================= */
function closeMenu(){ menuOpen=false; menuEl.classList.remove('on'); menuEl.innerHTML=''; }
function openMenu(x,y){
  menuOpen=true; setIgnore(false); menuEl.innerHTML='';
  const sect=(t)=>el('div','msec',t,menuEl);
  const item=(icon,label,fn,on)=>{ const b=el('button','mitem'+(on?' on':''),null,menuEl); el('span','mi',icon,b); el('span','ml',label,b); if(on) el('span','mk','✓',b); b.onclick=()=>{ closeMenu(); fn(); }; return b; };
  const chars=BUILTIN.concat((cfg.userChars||[]).map(u=>({id:u.id,name:u.name,icon:'🧍'})));
  sect('Character');
  const grid=el('div','mgrid',null,menuEl);
  chars.forEach(c=>{ const b=el('button','mchip'+(cfg.character===c.id?' on':''),null,grid); el('span','mi',c.icon,b); el('span','ml',c.name,b); b.title=c.note||''; b.onclick=()=>{ closeMenu(); wm.send('patch',{character:c.id}); }; });
  item('➕','Add a character file (VRM / GLB)…',()=>wm.send('addChar'));
  item('🧱','Use a skin picture on the Blocky Miner…',()=>wm.send('addSkin'));
  sect('Do something');
  item('🪑','Sit here',()=>runCommand('sit'));
  item('🚶','Walk around again',()=>runCommand('wander'));
  item('🧲','Follow me',()=>runCommand('follow'),cfg.followCursor);
  item('💃','Dance',()=>runCommand('dance'));
  item('😴','Sleep',()=>runCommand('sleep'));
  item('👋','Wave',()=>runCommand('wave'));
  item('🫥','Tuck away at the edge',()=>runCommand('hide'),ent.hidden);
  item('🕒','Tell me the time',()=>runCommand('time'));
  sect('Friends');
  item('👁️','Call the eye for a fight',()=>runCommand('eye'));
  item('🙂','Let the eye visit (no fight)',()=>runCommand('eyeVisit'));
  if(eye) item('👋','Send the eye away',()=>runCommand('eyeAway'));
  if(ent.char&&ent.char.id==='octopus'){ sect('Octopus'); item('✨','Summon again',()=>runCommand('summon')); item('🔧','Take apart / put together',()=>runCommand('apart')); }
  sect('WaveMate');
  item('⌨️','Imitate my typing',()=>wm.send('patch',{typing:!cfg.typing}),cfg.typing);
  item('🔇','Quiet mode (hide for a while)',()=>wm.send('patch',{quiet:!cfg.quiet}),cfg.quiet);
  item('⏱️','Start a focus timer',()=>wm.send('pomodoro'));
  item('⚙️','Settings…',()=>wm.send('openSettings'));
  item('⏻','Quit WaveMate',()=>wm.send('quit'));
  menuEl.classList.add('on');
  const mw=menuEl.offsetWidth, mh=menuEl.offsetHeight;
  menuEl.style.left=clamp(x,6,W-mw-6)+'px'; menuEl.style.top=clamp(y,6,H-mh-6)+'px';
}
addEventListener('keydown',e=>{ if(e.key==='Escape') closeMenu(); });

/* ======================= the little eye: visits, and fights ======================= */
let eye=null, eyeNextAt=0;
function scheduleEye(){ eyeNextAt=cfg.popEye&&cfg.character!=='eye'?performance.now()/1000+rnd(0.4,1.4)*cfg.eyeEvery*60:Infinity; }
function startEye(fight){
  if(eye||!ent.char||ent.hidden||cfg.character==='eye'){ if(eye&&fight) eye.fight=true; return; }
  const c=createEye(); scene.add(c.root);
  const side=Math.random()<0.5?-1:1, m=hitRegion(ent)||{cx:W/2,cy:H/2,rx:80,ry:100};
  eye={char:c,x:side<0?-80:W+80,y:rnd(H*0.15,H*0.5),vx:0,vy:0,stage:'enter',t:0,fight,round:0,rounds:3+((Math.random()*3)|0),side,hover:{x:0,y:0},spin:0,wob:0,hit:false};
  eye.hover={x:clamp(m.cx+side*(m.rx*1.6+90),80,W-80),y:clamp(m.cy-m.ry*0.5,90,H-120)};
  bubble(pick(['Is that... the eye?','Oh, the eye is here!','Here we go again…']),ent,2.5);
}
function eyeLeave(){ if(eye){ eye.stage='leave'; eye.t=0; } }
function eyeBubble(t){ if(eye){ const b=el('div','bubble small',t); b.style.left=clamp(eye.x,70,W-70)+'px'; b.style.top=(eye.y-70)+'px'; setTimeout(()=>b.classList.add('out'),1400); setTimeout(()=>b.remove(),1900); } }
function eyeTick(dt){
  const e=eye; e.t+=dt; const m=hitRegion(ent)||{cx:W/2,cy:H/2,rx:80,ry:100}; const mc={x:m.cx,y:m.cy};
  const goto=(tx,ty,r)=>{ e.x+=(tx-e.x)*kf(dt,r); e.y+=(ty-e.y)*kf(dt,r); };
  const prevX=e.x;
  switch(e.stage){
    case 'enter': goto(e.hover.x,e.hover.y,2.6); if(e.t>2.4){ e.stage=e.fight?'orbit':'peek'; e.t=0; } break;
    case 'peek': { goto(e.hover.x+Math.sin(e.t*1.5)*20,e.hover.y+Math.sin(e.t*2.1)*14,4); if(e.t>6){ e.stage='leave'; e.t=0; } break; }
    case 'orbit': { const a=e.t*3.2*e.side+(e.side<0?Math.PI:0), R=m.rx*1.5+70; goto(mc.x+Math.cos(a)*R,mc.y-m.ry*0.2+Math.sin(a)*R*0.55,6); if(e.t>1.0){ e.stage='wind'; e.t=0; e.windAng=Math.atan2(e.y-mc.y,e.x-mc.x); if(ent.char) ent.char.flinch(); } break; }
    case 'wind': { const R=m.rx*1.5+200; goto(mc.x+Math.cos(e.windAng)*R,mc.y+Math.sin(e.windAng)*R*0.7,5); e.spin=Math.min(1,e.t/0.5); if(e.t>0.7){ e.stage='dash'; e.t=0; e.sx=e.x; e.sy=e.y; eyeBubble(pick(['HYAA!','Take that!','Charge!','Bzzt!'])); } break; }
    case 'dash': { const s=clamp(e.t/0.2,0,1), q=s*s; e.x=lerp(e.sx,mc.x,q); e.y=lerp(e.sy,mc.y,q); e.spin=1; if(s>=1){ e.stage='knock'; e.t=0; eyeHit(m); } break; }
    case 'knock': { const s=clamp(e.t/0.6,0,1), q=1-Math.pow(1-s,3); e.x=lerp(e.kx0,e.kx1,q); e.y=lerp(e.ky0,e.ky1,q); e.spin=1-s; if(s>=1){ e.round++; if(e.round>=e.rounds){ e.stage='end'; e.t=0; endFight(); } else { e.stage='orbit'; e.t=0; } } break; }
    case 'end': { goto(e.hover.x,e.hover.y,3); if(e.t>2.2){ e.stage='leave'; e.t=0; } break; }
    case 'leave': { const tx=e.side<0?-140:W+140; e.x+=(tx-e.x)*kf(dt,1.4)+ (e.side<0?-1:1)*dt*160; e.y+=(-60-e.y)*kf(dt,0.6); if(e.t>2.6||e.x<-120||e.x>W+120){ scene.remove(e.char.root); e.char.dispose(); eye=null; scheduleEye(); return; } break; }
  }
  e.vx=(e.x-prevX)/Math.max(dt,0.001);
  const c=e.char; c.update(dt,{look:true,lookX:clamp((mc.x-e.x)/260,-1,1),lookY:clamp(-(mc.y-e.y)/260,-1,1),vx:e.vx*0.5,float:1,dance:e.stage==='wind'?1:0});
  const s=c.unit*0.62*Math.sqrt(cfg.size);
  c.root.position.set(e.x,H-e.y,10); c.root.scale.setScalar(s);
  c.root.rotation.z=(e.stage==='dash'?-0.0:0)+Math.sin(e.t*30)*0.03*e.spin;
}
function eyeHit(m){
  const e=eye, a=Math.atan2(e.y-m.cy,e.x-m.cx)+rnd(-0.6,0.6), R=m.rx*1.4+200;
  e.kx0=e.x; e.ky0=e.y; e.kx1=clamp(m.cx+Math.cos(a)*R,60,W-60); e.ky1=clamp(m.cy+Math.sin(a)*R*0.7,70,H-90);
  const ch=ent.char; if(ch){ ch.startle(1); ch.poke('head'); } ent.startle=1;
  floatText('💥',m.cx,m.cy,'boom'); setTimeout(()=>floatText('✦',m.cx+rnd(-40,40),m.cy+rnd(-40,20),'boom'),90);
  bubble(pick(['Ow!','Hey!','Oi!','Not again!','Stop that!','Rude!']),ent,1.6);
  /* hit back: the octopus whips an arm at it, others punch */
  ent.swat={x:e.x,y:e.y,t:0}; ent.punch=1;
  e.char.flinch();
}
function endFight(){
  const win=Math.random()<0.6;
  if(win){ bubble(pick(['Ha! Who is the boss now?','Eye: 0, me: 1.','Stay down, little eye.']),ent,3); ent.char.happy(1); eyeBubble('…ow'); }
  else { bubble(pick(['Okay okay, you win…','My arms are tired…']),ent,3); eyeBubble(pick(['Beep boop. Victory!','GG!'])); eye.char.happy(); }
}

/* ======================= per-frame character drive ======================= */
const _v=new THREE.Vector3();
function driveChar(e,dt){
  const c=e.char; if(!c) return;
  const isFloat=c.kind==='float';
  const mode=e.mode, onSurf=!!e.surf&&mode!=='jump'&&mode!=='fall'&&mode!=='drag';
  const sitting=(mode==='sit'||mode==='sleep'||(mode==='type'&&e.sitting))&&onSurf;
  e.startle*=Math.exp(-dt*3); e.punch*=Math.exp(-dt*3.2); e.tapL*=Math.exp(-dt*7); e.tapR*=Math.exp(-dt*7);
  const hr=hitRegion(e)||{cx:e.x,cy:e.y-100,rx:60,ry:80};
  const lx=cfg.lookAtCursor&&!cfg.quiet?clamp((cur.x-hr.cx)/380,-1,1):0, ly=cfg.lookAtCursor?clamp(-(cur.y-hr.cy)/380,-1,1):0;
  const S={mode,facing:e.facing,speed:mode==='walk'?(cfg.followCursor?1:0.5):0,vx:e.vx,vy:e.vy,lookX:lx,lookY:ly,cursorDx:cur.x-hr.cx,cursorDy:-(cur.y-hr.cy),
    grab:mode==='grab',punch:e.punch,startle:e.startle,tapL:e.tapL,tapR:e.tapR,sitting:e.sitting||sitting,music:clamp(e.music*4,0,1),surface:onSurf};
  if(isFloat){
    e.wp+=dt*(mode==='walk'?7:0);
    const ctl={look:cfg.lookAtCursor,lookX:lx,lookY:ly,vx:e.vx/(c.unit*cfg.size),vy:-e.vy/(c.unit*cfg.size),perch:sitting?1:0,stance:(onSurf&&!sitting)?1:0,ws:mode==='walk'?1:0,wp:e.wp,
      float:onSurf?(sitting?0.35:0.3):1,dance:mode==='dance'?clamp(0.5+e.music*3,0.5,1):0,sleep:mode==='sleep'?1:0,chute:(mode==='fall')?1:0};
    if(c.id==='octopus'){
      /* arms: typing on the keyboard, reaching for the cursor, hitting the eye */
      const aim=[null,null,null,null,null,null,null,null];
      const typing=mode==='type', kb=e.kbOct;
      if(kb){ kb.visible=typing; }
      for(let i=0;i<8;i++){
        let tgt=null, w=0;
        const ti=TAP_ARMS.indexOf(i);
        if(typing&&ti>=0){ e.tapAmt[i]*=Math.exp(-dt*9); tgt={x:TAP_X[ti]*1.0,y:-2.52-0.42*e.tapAmt[i],z:2.1+(ti>1?0.35:0)}; w=1; }
        else if(mode==='grab'&&i===e.grabArm){ c.bodyLocal(cur.x,H-cur.y,0,_v); const d=_v.length(); if(d>4.4) _v.multiplyScalar(4.4/d); tgt={x:_v.x,y:_v.y,z:Math.max(0.5,_v.z)+0.4}; w=1; }
        else if(e.swat&&i===e.swatArm){ e.swat.t+=0; c.bodyLocal(e.swat.x,H-e.swat.y,0,_v); const d=_v.length(); if(d>4.6) _v.multiplyScalar(4.6/d); tgt={x:_v.x,y:_v.y,z:_v.z+0.6}; w=Math.max(0,1-(e.swat.t)/0.7); }
        e.aimW[i]+=(w-e.aimW[i])*kf(dt,typing?14:(e.swat&&i===e.swatArm)?16:7);
        if(e.aimW[i]>0.01&&(tgt||e.lastAim&&e.lastAim[i])){ if(tgt){ aim[i]={x:tgt.x,y:tgt.y,z:tgt.z,w:e.aimW[i]}; (e.lastAim||(e.lastAim=[]))[i]=tgt; } else { const t0=e.lastAim[i]; aim[i]={x:t0.x,y:t0.y,z:t0.z,w:e.aimW[i]}; } }
      }
      if(mode==='grab'&&e.grabArm==null){ const dx=cur.x-hr.cx; const cand=dx>=0?[1,0,2]:[6,7,5]; e.grabArm=cand[0]; }
      if(mode!=='grab') e.grabArm=null;
      if(e.swat){ e.swat.t+=dt; if(e.swatArm==null){ const dx=e.swat.x-hr.cx; e.swatArm=dx>=0?(Math.random()<0.5?0:1):(Math.random()<0.5?7:6); } if(e.swat.t>0.8){ e.swat=null; e.swatArm=null; } }
      ctl.aim=aim;
      if(mode==='wave'&&!c.X._wave) { /* wave arm handled once on trigger */ }
    }
    c.update(dt,ctl);
  } else {
    c.update(dt,S);
  }
  /* placement */
  const s=c.unit*cfg.size, lift=c.lift?c.lift(modeKey(e))*s:0;
  c.root.position.set(e.x,H-e.y+lift,0); c.root.scale.setScalar(s);
  if(isFloat){
    const ty=(mode==='fall'||mode==='drag'||mode==='jump')?0:0;
    c.root.rotation.y=0; c.root.rotation.z=(mode==='drag')?clamp(-e.vx*0.0006,-0.4,0.4):0;
  }
  /* soft shadow under the feet */
  const onGround=!!e.surf&&mode!=='jump'&&mode!=='fall'&&mode!=='drag';
  blob.visible=cfg.shadow!=='off'&&onGround&&!sitting;
  if(blob.visible){ const w=hr.rx*1.6; blob.scale.set(w,w*0.16,1); blob.position.set(e.x,H-e.y-2,-30); blob.material.opacity=cfg.shadow==='soft'?1:0.7; }
  if(mode==='sleep'){ e.zzz-=dt; if(e.zzz<=0){ e.zzz=1.3; const h=headPos(e); floatText('z',h.x+rnd(10,40),h.y+10,'zzz'); } }
}
/* the octopus 'wave' needs a nudge when the mode starts */
let lastMode='';

/* ======================= main loop ======================= */
let last=performance.now(), acc=0, started=false;
function frame(t){
  requestAnimationFrame(frame);
  const dtr=Math.min(0.05,(t-last)/1000); last=t; now=t/1000;
  const cap=ent.mode==='sleep'?20:cfg.fps; acc+=dtr; if(acc<1/cap-0.002) return; const dt=Math.min(0.05,acc); acc=0;
  if(!ent.char) return;
  /* cursor speed */
  cur.v=Math.hypot(cur.x-cur.px,cur.y-cur.py)/Math.max(dt,0.001); if(cur.v>25) lastCursorMove=now; cur.px=cur.x; cur.py=cur.y;
  const hide=fullscreenOn&&cfg.hideFullscreen||cfg.quiet;
  canvas.style.opacity=hide?'0':'1'; fx.style.opacity=hide?'0':'1';
  if(hide){ setIgnore(true); return; }
  think(ent,dt);
  if(ent.mode!==lastMode){ if(ent.mode==='wave'&&ent.char.id==='octopus') ent.char.wave(); if(ent.mode==='jump'&&ent.char.id!=='octopus') ent.char.jet(); lastMode=ent.mode; }
  updateHover(dt);
  driveChar(ent,dt);
  if(eye) eyeTick(dt);
  else if(now>eyeNextAt&&ent.mode!=='sleep'&&!ent.hidden&&!ent.drag) startEye(cfg.eyeFights);
  /* time-based chimes are sent by the PC side; nothing else to do here */
    renderer.render(scene,camera);
}

/* ======================= start ======================= */
addEventListener('resize',()=>{ resize(); });
resize();
(async()=>{
  try{ const s=await wm.invoke('getSettings'); cfg=Object.assign({},DEFAULTS,s); }catch(e){}
  canvas.style.filter=cfg.shadow==='cast'?'drop-shadow(-11px 9px 6px rgba(0,0,0,0.30))':'none';
  edges=[{id:'floor',x0:0,x1:W,y:floorY,kind:'floor'}];
  await setCharacter(cfg.character,true);
  ent.x=rnd(W*0.3,W*0.7); ent.y=-200; scheduleEye();
  if(cfg.hidden) setHidden(true);
  wm.send('ready');
  requestAnimationFrame(frame);
})();
window.__wm={ent,hit:()=>hitRegion(ent),get eye(){return eye;},runCommand,setCharacter,cfgRef:()=>cfg,edgesRef:()=>edges};
