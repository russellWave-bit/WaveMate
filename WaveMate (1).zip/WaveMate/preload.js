const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('wm',{
  on:(ch,cb)=>{ ipcRenderer.on('wm:'+ch,(e,d)=>cb(d)); },
  send:(ch,d)=>{ ipcRenderer.send('wm:'+ch,d); },
  invoke:(ch,d)=>ipcRenderer.invoke('wm:'+ch,d)
});
