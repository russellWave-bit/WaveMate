const {app,BrowserWindow,Tray,Menu,screen,ipcMain,protocol,net,dialog,nativeImage,shell}=require('electron');
const path=require('path'), fs=require('fs');
const {pathToFileURL}=require('url');
const helpers=require('./helpers.js');
const DEFAULTS=require('./defaults.json');

protocol.registerSchemesAsPrivileged([{scheme:'wm',privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true,corsEnabled:true}}]);
if(!app.requestSingleInstanceLock()){ app.quit(); }

let cfg=Object.assign({},DEFAULTS), overlays=[], settingsWin=null, tray=null;
const userDir=()=>app.getPath('userData');
const cfgFile=()=>path.join(userDir(),'settings.json');
function loadCfg(){ try{ cfg=Object.assign({},DEFAULTS,JSON.parse(fs.readFileSync(cfgFile(),'utf8'))); }catch(e){ cfg=Object.assign({},DEFAULTS); } }
let saveT=null;
function saveCfg(){ clearTimeout(saveT); saveT=setTimeout(()=>{ try{ fs.writeFileSync(cfgFile(),JSON.stringify(cfg,null,2)); }catch(e){} },300); }
const alive=o=>o&&o.win&&!o.win.isDestroyed();
const cfgFor=ov=>Object.assign({},cfg,{character:ov.slot===0?cfg.character:((cfg.friends||[]).filter(Boolean)[ov.slot-1]||'fox'),slot:ov.slot});
const ovOf=sender=>overlays.find(o=>alive(o)&&o.win.webContents===sender);
function sendOv(ov,ch,d){ if(alive(ov)) ov.win.webContents.send('wm:'+ch,d); }
function sendAll(ch,d){ overlays.forEach(o=>sendOv(o,ch,d)); }
function sendSettings(){ overlays.forEach(o=>sendOv(o,'settings',cfgFor(o))); if(settingsWin&&!settingsWin.isDestroyed()) settingsWin.webContents.send('wm:settings',cfg); }

/* ---------------- settings changes ---------------- */
function patch(p){
  p=Object.assign({},p);
  const slot=p.slot|0; delete p.slot;
  if(p.character!=null&&slot>0){ const f=(cfg.friends||[]).slice(); f[slot-1]=p.character; delete p.character; p.friends=f; }
  const keys=Object.keys(p); if(!keys.length) return;
  const before=cfg; cfg=Object.assign({},cfg,p); saveCfg();
  if(keys.every(k=>k==='hunger')) return; /* quiet save, nobody needs to redraw for this */
  const layout=['friends','friendScreen','display'].some(k=>k in p&&JSON.stringify(p[k])!==JSON.stringify(before[k]));
  const friendCount=(cfg.friends||[]).filter(Boolean).slice(0,2).length+1;
  if(layout||friendCount!==overlays.length) buildOverlays(); else sendSettings();
  if('floorMode' in p) pushWins();
  if(p.typing!=null||p.quiet!=null||p.dance!=null) syncHelpers();
  if(p.startup!=null&&app.isPackaged) app.setLoginItemSettings({openAtLogin:!!cfg.startup});
  buildTray();
}

/* ---------------- overlay windows: one per character (the main one, and up to two friends) ---------------- */
function screens(){ const all=screen.getAllDisplays(); const main=all[cfg.display]||screen.getPrimaryDisplay(); const other=all.find(d=>d.id!==main.id)||main; return {main,other}; }
function createOverlay(slot,char,display){
  const bounds=display.bounds;
  const win=new BrowserWindow({x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height,transparent:true,frame:false,resizable:false,movable:false,hasShadow:false,
    alwaysOnTop:true,skipTaskbar:true,focusable:false,show:false,fullscreenable:false,thickFrame:false,backgroundColor:'#00000000',
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,backgroundThrottling:false}});
  win.setAlwaysOnTop(true,'screen-saver');
  win.setIgnoreMouseEvents(true,{forward:true});
  win.setMenu(null);
  win.loadURL('wm://app/overlay.html');
  const ov={win,display,bounds,slot,char,lastC:{x:-1,y:-1},lastSend:0};
  win.once('ready-to-show',()=>{ win.setBounds(bounds); win.showInactive(); });
  return ov;
}
function buildOverlays(){
  overlays.forEach(o=>{ try{ if(alive(o)) o.win.destroy(); }catch(e){} }); overlays=[];
  const {main,other}=screens();
  overlays.push(createOverlay(0,cfg.character,main));
  (cfg.friends||[]).filter(Boolean).slice(0,2).forEach((c,i)=>overlays.push(createOverlay(i+1,c,cfg.friendScreen==='other'?other:main)));
}

/* ---------------- settings window ---------------- */
function openSettings(){
  if(settingsWin&&!settingsWin.isDestroyed()){ settingsWin.show(); settingsWin.focus(); return; }
  settingsWin=new BrowserWindow({width:580,height:800,title:'WaveMate settings',backgroundColor:'#0b0d0f',autoHideMenuBar:true,
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}});
  settingsWin.setMenu(null);
  settingsWin.loadURL('wm://app/settings.html');
  settingsWin.on('closed',()=>{ settingsWin=null; });
}

/* ---------------- tray ---------------- */
function buildTray(){
  if(!tray){
    let img=nativeImage.createFromPath(path.join(__dirname,'assets','icon.png'));
    if(!img.isEmpty()) img=img.resize({width:20,height:20});
    tray=new Tray(img); tray.setToolTip('WaveMate'); tray.on('click',()=>openSettings());
  }
  tray.setContextMenu(Menu.buildFromTemplate([
    {label:cfg.quiet?'Wake WaveMate (quiet is on)':'Quiet mode (hide)',click:()=>patch({quiet:!cfg.quiet})},
    {label:cfg.hidden?'Come out from the edge':'Tuck away at the edge',click:()=>sendAll('cmd',{name:'hide'})},
    {label:'Call the eye for a fight',click:()=>sendOv(overlays[0],'cmd',{name:'eye'})},
    {label:'Start a focus timer ('+cfg.pomodoro+' min)',click:()=>startPomodoro()},
    {label:'Settings…',click:()=>openSettings()},
    {type:'separator'},
    {label:'Quit WaveMate',click:()=>app.quit()}
  ]));
}

/* ---------------- Windows watchers ---------------- */
let procs={win:null,keys:null,audio:null}, helperDir='', lastWin=null;
/* windows and the floor, worked out for each overlay's own screen */
function floorFor(ov){
  const d=ov.display, wa=d.workArea, bottomWork=wa.y+wa.height, screenBottom=d.bounds.y+d.bounds.height, tb=Math.max(0,screenBottom-bottomWork);
  let f=bottomWork; if(cfg.floorMode==='inside') f=bottomWork+tb*0.55; else if(cfg.floorMode==='screen') f=screenBottom;
  return f-ov.bounds.y;
}
function pushWins(){
  const rects=(lastWin?lastWin.list:[]).map(w=>({w,r:screen.screenToDipRect(null,{x:w.x,y:w.y,width:w.w,height:w.h})}));
  overlays.forEach(ov=>{ const list=rects.map(({w,r})=>({id:w.id,x:r.x-ov.bounds.x,y:r.y-ov.bounds.y,w:r.width,h:r.height,fg:w.fg,fs:w.fs})); sendOv(ov,'win',{list,floor:floorFor(ov)}); });
}
function stop(k){ if(procs[k]){ try{ procs[k].kill(); }catch(e){} procs[k]=null; } }
function syncHelpers(){
  if(process.platform!=='win32') return;
  if(!procs.win){
    procs.win=helpers.run(helperDir,'WinWatch',line=>{
      let d; try{ d=JSON.parse(line); }catch(e){ return; }
      lastWin=d; pushWins();
      sendAll('fs',!!d.fs);
    },()=>{ procs.win=null; });
  }
  const wantKeys=cfg.typing&&!cfg.quiet, wantAudio=cfg.dance&&!cfg.quiet;
  if(wantKeys&&!procs.keys) procs.keys=helpers.run(helperDir,'KeyWatch',line=>{ const n=parseInt(line,10); if(n>0) sendAll('keys',n); },()=>{ procs.keys=null; });
  if(!wantKeys) stop('keys');
  if(wantAudio&&!procs.audio) procs.audio=helpers.run(helperDir,'AudioWatch',line=>{ const v=parseFloat(line); if(!isNaN(v)) sendAll('audio',v); },()=>{ procs.audio=null; });
  if(!wantAudio){ stop('audio'); sendAll('audio',0); }
}

/* ---------------- time: alarms, hourly chime, focus timer ---------------- */
let lastMinute='', pomoT=null;
function startPomodoro(){
  clearTimeout(pomoT); const m=Math.max(1,cfg.pomodoro|0);
  sendOv(overlays[0],'cmd',{name:'alarm',arg:{label:'Focus timer started: '+m+' minutes. You can do it!'}});
  pomoT=setTimeout(()=>sendOv(overlays[0],'cmd',{name:'alarm',arg:{label:'Focus time is over. Stretch, drink some water!'}}),m*60000);
}
setInterval(()=>{
  const d=new Date(), hm=('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2);
  if(hm===lastMinute) return; lastMinute=hm;
  (cfg.alarms||[]).forEach(a=>{ if(a.on!==false&&a.t===hm) sendOv(overlays[0],'cmd',{name:'alarm',arg:{label:a.label||('Alarm '+hm)}}); });
  if(cfg.hourly&&d.getMinutes()===0) sendOv(overlays[0],'cmd',{name:'time'});
},15000);

/* ---------------- cursor ---------------- */
setInterval(()=>{
  if(!overlays.length) return;
  const p=screen.getCursorScreenPoint(), t=Date.now();
  overlays.forEach(ov=>{ const x=p.x-ov.bounds.x, y=p.y-ov.bounds.y; if(x!==ov.lastC.x||y!==ov.lastC.y||t-ov.lastSend>300){ ov.lastC={x,y}; ov.lastSend=t; sendOv(ov,'cursor',{x,y}); } });
},16);

/* ---------------- ipc ---------------- */
function userFileOk(p){ try{ const r=path.resolve(p); return r.startsWith(path.resolve(userDir())); }catch(e){ return false; } }
ipcMain.handle('wm:getSettings',e=>{ const o=ovOf(e.sender); return o?cfgFor(o):cfg; });
ipcMain.handle('wm:chars',()=>{ const out=[]; for(const u of (cfg.userChars||[])){ let size=0; try{ size=fs.statSync(u.file).size; }catch(e){} out.push({id:u.id,size}); } return out; });
ipcMain.handle('wm:displays',()=>screen.getAllDisplays().map((d,i)=>({i,label:'Screen '+(i+1)+' ('+d.bounds.width+'x'+d.bounds.height+')'+(d.id===screen.getPrimaryDisplay().id?' - main':'')})));
ipcMain.handle('wm:readFile',(e,p)=>{ try{ if(!userFileOk(p)) return null; return fs.readFileSync(p); }catch(err){ return null; } });
ipcMain.on('wm:ignore',(e,v)=>{ const o=ovOf(e.sender); if(o) o.win.setIgnoreMouseEvents(!!v,{forward:true}); });
ipcMain.on('wm:patch',(e,p)=>patch(p));
ipcMain.on('wm:ready',e=>{ const o=ovOf(e.sender); if(o) sendOv(o,'settings',cfgFor(o)); syncHelpers(); setTimeout(pushWins,200); });
ipcMain.on('wm:openSettings',()=>openSettings());
ipcMain.on('wm:quit',()=>app.quit());
ipcMain.on('wm:pomodoro',()=>startPomodoro());
ipcMain.on('wm:cmd',(e,c)=>sendAll('cmd',c));
ipcMain.on('wm:chat',(e,t)=>sendOv(overlays[0],'cmd',{name:'chat',arg:String(t||'').slice(0,200)}));
ipcMain.on('wm:feed',(e,kind)=>sendOv(overlays[0],'cmd',{name:'feed',arg:{kind}}));
ipcMain.on('wm:openFolder',()=>{ const dir=path.join(userDir(),'characters'); try{ fs.mkdirSync(dir,{recursive:true}); }catch(x){} shell.openPath(dir); });
ipcMain.on('wm:renameChar',(e,a)=>{ const u=(cfg.userChars||[]).map(x=>x.id===a.id?Object.assign({},x,{name:String(a.name||x.name).slice(0,24)}):x); patch({userChars:u}); });
ipcMain.on('wm:removeChar',(e,id)=>{ const gone=(cfg.userChars||[]).find(x=>x.id===id); const u=(cfg.userChars||[]).filter(x=>x.id!==id);
  try{ if(gone&&gone.file&&userFileOk(gone.file)) fs.unlinkSync(gone.file); }catch(x){}
  patch({userChars:u,character:cfg.character===id?'octopus':cfg.character,friends:(cfg.friends||[]).filter(f=>f!==id)}); });
ipcMain.on('wm:addChar',async()=>{
  const r=await dialog.showOpenDialog({title:'Choose a character file',filters:[{name:'3D characters',extensions:['vrm','glb','gltf']}],properties:['openFile']});
  if(r.canceled||!r.filePaths[0]) return;
  const src=r.filePaths[0], dir=path.join(userDir(),'characters'); fs.mkdirSync(dir,{recursive:true});
  const base=path.basename(src), id='u_'+Date.now().toString(36), dest=path.join(dir,id+path.extname(base));
  fs.copyFileSync(src,dest);
  patch({userChars:(cfg.userChars||[]).concat([{id,name:base.replace(/\.[^.]+$/,'').slice(0,24),file:dest}]),character:id});
});
ipcMain.on('wm:addSkin',async()=>{
  const r=await dialog.showOpenDialog({title:'Choose a skin picture (png)',filters:[{name:'Skin picture',extensions:['png']}],properties:['openFile']});
  if(r.canceled||!r.filePaths[0]) return;
  const dir=path.join(userDir(),'characters'); fs.mkdirSync(dir,{recursive:true});
  const dest=path.join(dir,'skin_'+Date.now().toString(36)+'.png'); fs.copyFileSync(r.filePaths[0],dest);
  patch({skinFile:dest,character:'blocky'});
});

/* ---------------- app ---------------- */
app.whenReady().then(()=>{
  protocol.handle('wm',req=>{
    const u=new URL(req.url); let p=decodeURIComponent(u.pathname); if(p==='/'||!p) p='/overlay.html';
    const file=path.normalize(path.join(__dirname,p));
    if(!file.startsWith(path.normalize(__dirname))) return new Response('no',{status:403});
    return net.fetch(pathToFileURL(file).toString());
  });
  loadCfg();
  helperDir=path.join(userDir(),'helpers'); try{ helpers.install(helperDir); }catch(e){}
  if(app.isPackaged) app.setLoginItemSettings({openAtLogin:!!cfg.startup});
  buildOverlays(); buildTray();
  screen.on('display-metrics-changed',()=>{ buildOverlays(); });
});
app.on('second-instance',()=>openSettings());
app.on('window-all-closed',()=>{});
app.on('before-quit',()=>{ Object.keys(procs).forEach(stop); });
