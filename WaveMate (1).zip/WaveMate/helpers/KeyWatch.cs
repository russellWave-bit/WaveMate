using System;
using System.Runtime.InteropServices;
using System.Threading;

/* Counts key presses so the character can tap along. It never records WHICH key was pressed, only how many. */
public static class KeyWatch
{
    [DllImport("user32.dll")] static extern short GetAsyncKeyState(int v);

    public static void Run()
    {
        bool[] down = new bool[256];
        int batch = 0;
        DateTime t0 = DateTime.UtcNow;
        while (true)
        {
            for (int k = 8; k <= 222; k++)
            {
                if (k >= 16 && k <= 18) continue;
                bool d = (GetAsyncKeyState(k) & 0x8000) != 0;
                if (d && !down[k]) batch++;
                down[k] = d;
            }
            if (batch > 0 && (DateTime.UtcNow - t0).TotalMilliseconds >= 40)
            {
                Console.WriteLine(batch);
                Console.Out.Flush();
                batch = 0;
                t0 = DateTime.UtcNow;
            }
            Thread.Sleep(12);
        }
    }
}
