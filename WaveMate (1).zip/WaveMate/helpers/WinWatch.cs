using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class WinWatch
{
    delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc p, IntPtr l);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint f);
    [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONITORINFO mi);
    [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out RECT r, int sz);
    [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int sz);

    [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
    [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public int dwFlags; }

    static bool IsSkippedClass(string cls)
    {
        return cls == "Progman" || cls == "WorkerW" || cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd"
            || cls == "Windows.UI.Core.CoreWindow" || cls == "ApplicationFrameInputSinkWindow" || cls == "XamlExplorerHostIslandWindow";
    }

    /* Prints one line of JSON whenever the set of windows changes. Only positions and sizes, never titles or contents. */
    public static void Run(int ownPid)
    {
        SetProcessDPIAware();
        StringBuilder sb = new StringBuilder(256);
        string last = "";
        while (true)
        {
            IntPtr fg = GetForegroundWindow();
            List<string> list = new List<string>();
            bool fs = false;
            EnumWindows(delegate(IntPtr h, IntPtr l)
            {
                if (!IsWindowVisible(h) || IsIconic(h)) return true;
                int ex = GetWindowLong(h, -20);
                if ((ex & 0x80) != 0 && (ex & 0x40000) == 0) return true;
                int cloaked = 0;
                DwmGetWindowAttribute(h, 14, out cloaked, 4);
                if (cloaked != 0) return true;
                uint pid;
                GetWindowThreadProcessId(h, out pid);
                if (pid == (uint)ownPid) return true;
                sb.Length = 0;
                GetClassName(h, sb, 256);
                if (IsSkippedClass(sb.ToString())) return true;
                RECT r;
                if (DwmGetWindowAttribute(h, 9, out r, 16) != 0) GetWindowRect(h, out r);
                int w = r.R - r.L, hh = r.B - r.T;
                if (w < 140 || hh < 80) return true;
                bool full = false;
                MONITORINFO mi = new MONITORINFO();
                mi.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
                IntPtr mon = MonitorFromWindow(h, 2);
                if (mon != IntPtr.Zero && GetMonitorInfo(mon, ref mi))
                    full = r.L <= mi.rcMonitor.L && r.T <= mi.rcMonitor.T && r.R >= mi.rcMonitor.R && r.B >= mi.rcMonitor.B;
                bool isfg = (h == fg);
                if (full && isfg) fs = true;
                list.Add("{\"id\":" + h.ToInt64() + ",\"x\":" + r.L + ",\"y\":" + r.T + ",\"w\":" + w + ",\"h\":" + hh
                    + ",\"fg\":" + (isfg ? "true" : "false") + ",\"fs\":" + (full ? "true" : "false") + "}");
                return true;
            }, IntPtr.Zero);
            string json = "{\"fs\":" + (fs ? "true" : "false") + ",\"list\":[" + string.Join(",", list.ToArray()) + "]}";
            if (json != last) { Console.WriteLine(json); Console.Out.Flush(); last = json; }
            Thread.Sleep(150);
        }
    }
}
