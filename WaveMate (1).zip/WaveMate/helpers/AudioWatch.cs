using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;

[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
class MMDeviceEnumeratorComObject { }

[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator
{
    int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
    int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
}

[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice
{
    int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
}

[ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioMeterInformation
{
    int GetPeakValue(out float peak);
}

/* Prints how loud the default speakers are right now (0 to 1). It hears loudness only, never the sound itself. */
public static class AudioWatch
{
    public static void Run()
    {
        while (true)
        {
            try
            {
                IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorComObject();
                IMMDevice dev;
                en.GetDefaultAudioEndpoint(0, 1, out dev);
                Guid iid = typeof(IAudioMeterInformation).GUID;
                object o;
                dev.Activate(ref iid, 23, IntPtr.Zero, out o);
                IAudioMeterInformation m = (IAudioMeterInformation)o;
                while (true)
                {
                    float p;
                    m.GetPeakValue(out p);
                    Console.WriteLine(p.ToString("0.000", CultureInfo.InvariantCulture));
                    Console.Out.Flush();
                    Thread.Sleep(90);
                }
            }
            catch (Exception) { Thread.Sleep(2000); }
        }
    }
}
