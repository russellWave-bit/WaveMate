/* Starts the small Windows watchers (window positions, key-press counts, speaker loudness) as separate PowerShell processes.
   If one of them fails, the rest of WaveMate keeps working. */
const {spawn}=require('child_process');
const fs=require('fs'), path=require('path');

const PS=(cls,args)=>`param([int]$OwnPid=0)
$src = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot '${cls}.cs')
Add-Type -TypeDefinition $src -Language CSharp
[${cls}]::Run(${args})
`;

function install(dir){
  fs.mkdirSync(dir,{recursive:true});
  for(const n of ['WinWatch','KeyWatch','AudioWatch']){
    fs.writeFileSync(path.join(dir,n+'.cs'),fs.readFileSync(path.join(__dirname,'helpers',n+'.cs')));
    fs.writeFileSync(path.join(dir,n+'.ps1'),PS(n,n==='WinWatch'?'$OwnPid':''));
  }
}

function run(dir,name,onLine,onExit){
  if(process.platform!=='win32') return null;
  const p=spawn('powershell.exe',['-NoProfile','-NoLogo','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(dir,name+'.ps1'),String(process.pid)],{windowsHide:true,stdio:['ignore','pipe','ignore']});
  let buf='';
  p.stdout.on('data',d=>{ buf+=d.toString(); let i; while((i=buf.indexOf('\n'))>=0){ const line=buf.slice(0,i).trim(); buf=buf.slice(i+1); if(line) onLine(line); } });
  p.on('exit',()=>{ if(onExit) onExit(); });
  p.on('error',()=>{ if(onExit) onExit(); });
  return p;
}
module.exports={install,run};
