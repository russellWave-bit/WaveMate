import DEFAULTS from '../defaults.json';
export {DEFAULTS};
export const BUILTIN=[
  {id:'octopus',name:'Wave Octopus',icon:'🐙',note:'Your Wave octopus'},
  {id:'eye',name:'Wave Eye',icon:'👁️',note:'The small mic eye'},
  {id:'robot',name:'Robot',icon:'🤖',note:'Artist-made, CC0'},
  {id:'fox',name:'Fox',icon:'🦊',note:'Artist-made, CC0 / CC-BY'},
  {id:'blocky',name:'Blocky Miner',icon:'⛏️',note:'Blocky body, takes any skin file'}
];
