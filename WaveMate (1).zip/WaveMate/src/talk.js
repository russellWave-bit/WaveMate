/* Little lines and a tiny offline chat brain. Nothing here goes online. */
export const LINES={
  morning:['Good morning!','Morning! Ready for the day?','Rise and shine!'],
  afternoon:['Good afternoon!','Hello there!','Afternoon! How is it going?'],
  evening:['Good evening!','Evening! Nearly time to rest.','Hi! How was your day?'],
  night:['It is getting late…','Do not stay up too long!','Night owl, eh?'],
  pat:['Mmm, that feels nice.','Hehe, thank you!','More pats please!','You are so kind.'],
  poke:['Hey!','Boop!','What was that?','Ooh!','I am right here!'],
  wake:['Oh! I was dreaming…','Huh? I am awake!','Back already?'],
  typing:['You type so fast!','Clack clack clack!','I will type with you!','Working hard, I see.'],
  music:['Ooh, I love this one!','Time to dance!','What a tune!','Turn it up!'],
  hungry:['I am a bit hungry…','Any snacks around?','My tummy is rumbling.','Feed me, please?'],
  fed:['Yum!','Delicious, thank you!','Nom nom nom!','That hit the spot!'],
  full:['I am full, thank you!','No more, I will burst!'],
  idle:['La la la…','What shall we do next?','Nice screen you have here.','I wonder what is in that window.','Do you need a break?','Remember to drink some water.','Stretch your back for a moment!','I like it up here.'],
  bye:['See you soon!','Bye bye!']
};
const JOKES=['Why did the octopus beat the druggist? It wanted to a-r-m itself!','What do you call a fish with no eyes? A fsh.','Why do ducks make great detectives? They always quack the case.','I told my computer I needed a break. It said: no problem, I will go to sleep.','What is an octopus favourite game? Hide and squid.'];
export const pickOf=a=>a[(Math.random()*a.length)|0];
export function dayPart(){ const h=new Date().getHours(); return h<5?'night':h<12?'morning':h<17?'afternoon':h<21?'evening':'night'; }
/* returns {text, action?} */
export function reply(input,ctx){
  const t=(input||'').toLowerCase().trim(); const has=(...w)=>w.some(x=>t.includes(x));
  if(!t) return {text:'?'};
  if(has('hello','hi ','hey','howdy','hullo')||t==='hi') return {text:pickOf(['Hello!','Hey you!','Hi there, '+(ctx.user||'friend')+'!'])};
  if(has('how are you','how r u','how do you feel','you ok')) return {text:ctx.hunger>70?'A bit hungry, to be honest.':ctx.hunger>40?'Pretty good! Could eat something.':'Great! My tummy is full.'};
  if(has('your name','who are you')) return {text:'I am '+ctx.name+'. I live on your desktop!'};
  if(has('time','what hour')) return {text:'It is '+new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})+'.'};
  if(has('date','today','what day')) return {text:'Today is '+new Date().toLocaleDateString([],{weekday:'long',day:'numeric',month:'long'})+'.'};
  if(has('joke','funny')) return {text:pickOf(JOKES)};
  if(has('thank')) return {text:pickOf(['You are welcome!','Anytime!','My pleasure!']),action:'happy'};
  if(has('love you','i love','like you')) return {text:pickOf(['Aww, I like you too!','You are the best!']),action:'happy'};
  if(has('bye','goodbye','good night','see you')) return {text:pickOf(LINES.bye)};
  if(has('hungry','food','eat','snack','feed')) return {text:ctx.hunger>50?'Yes please! Right-click me, then Feed me.':'I just ate, but I never say no to snacks!'};
  if(has('trick','show me something','show off','do something')) return {text:pickOf(['Watch this!','Ta-da incoming!','Okay, look!']),action:'trick'};
  if(has('dance')) return {text:'Watch this!',action:'dance'};
  if(has('sleep','tired','nap')) return {text:'Okay… goodnight.',action:'sleep'};
  if(has('wake')) return {text:'I am up!',action:'wander'};
  if(has('sit')) return {text:'Sitting down.',action:'sit'};
  if(has('wave','hello there')) return {text:'*waves*',action:'wave'};
  if(has('sing')) return {text:'La la laaa… 🎵',action:'dance'};
  if(has('help','what can you do')) return {text:'Pat my head, drag me around, feed me, or type to me here. Right-click me for more.'};
  if(has('fight','eye')) return {text:'Oh, you want the eye? Fine!',action:'eye'};
  if(has('tired','sad','bad day')) return {text:'I am here with you. Take a deep breath.'};
  return {text:pickOf(['Hmm, tell me more!','Interesting!','I am only a small desktop friend, but I am listening.','Ha! Okay!','Really?'])};
}
