import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {makePose,stepPose} from './humanoid.js';
import {makeKeyboard,clamp,lerp,kf} from './props.js';
import {createSprings} from './spring.js';

export function loadGLTF(src){
  const l=new GLTFLoader();
  return new Promise((res,rej)=>{
    if(typeof src==='string') l.load(src,res,undefined,rej);
    else l.parse(src,'',res,rej);
  });
}

function fitModel(scene,height){
  const box=new THREE.Box3().setFromObject(scene), size=new THREE.Vector3(); box.getSize(size);
  const k=height/Math.max(size.y,1e-4); scene.scale.multiplyScalar(k);
  const b2=new THREE.Box3().setFromObject(scene);
  scene.position.x-= (b2.min.x+b2.max.x)/2; scene.position.z-=(b2.min.z+b2.max.z)/2; scene.position.y-=b2.min.y;
  return k;
}


/* ---- bone helpers for the animated GLB characters (aim a limb in world space, whatever its local axes are) ---- */
const _a=new THREE.Vector3(), _b=new THREE.Vector3(), _q=new THREE.Quaternion(), _q2=new THREE.Quaternion(), _pq=new THREE.Quaternion();
function worldQ(o,out){ return o.getWorldQuaternion(out); }
let FRAME=0; const TOUCHED=new Set();
function newFrame(){ FRAME++; TOUCHED.forEach(b=>{ const u=b.userData; if(u.wrote&&u.restQ&&b.quaternion.equals(u.wrote)) b.quaternion.copy(u.restQ); }); TOUCHED.clear(); } /* bones the clip does not drive would keep last frame's turn */
function applyWorldDelta(bone,dq,w){ /* rotate a bone by dq (in world space), w = how much (0..1) */
  if(w<=0.001) return;
  const u=bone.userData;
  if(u.restQ===undefined) u.restQ=bone.quaternion.clone();
  if(u.frame!==FRAME){ u.frame=FRAME; if(u.wrote&&bone.quaternion.equals(u.wrote)) bone.quaternion.copy(u.restQ); } /* a bone the clip does not drive would otherwise pile up turns */
  bone.updateMatrixWorld(true);
  _q2.copy(dq); if(w<1) _q2.slerp(new THREE.Quaternion(),1-w); worldQ(bone,_q); _q2.multiply(_q);
  if(bone.parent) worldQ(bone.parent,_pq).invert(); else _pq.identity();
  bone.quaternion.copy(_pq.multiply(_q2));
  u.wrote=bone.quaternion.clone(); TOUCHED.add(bone);
  bone.updateMatrixWorld(true);
}
function aimBone(bone,child,dir,w){ /* point the bone->child direction along dir (world) */
  if(!bone||!child||w<=0.001) return;
  bone.updateWorldMatrix(true,true);
  bone.getWorldPosition(_a); child.getWorldPosition(_b); _b.sub(_a).normalize();
  _q.setFromUnitVectors(_b,dir.clone().normalize()); applyWorldDelta(bone,_q,w);
}

/* ============ animated GLB characters (artist-made models with their own clips) ============ */
const find=(names,re)=>names.find(n=>re.test(n));
export function createClipChar(gltf,cfg){
  const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
  const model=gltf.scene; rig.add(model);
  fitModel(model,cfg.height||32);
  model.traverse(o=>{ if(o.isMesh){ o.frustumCulled=false; } if(o.isBone) o.userData.restQ=o.quaternion.clone(); }); /* the bind pose: what undriven bones go back to */
  const mixer=new THREE.AnimationMixer(model);
  const clips={}; gltf.animations.forEach(a=>{ clips[a.name]=a; });
  const names=Object.keys(clips);
  const map=Object.assign({},cfg.map||{});
  const auto={idle:/idle|stand|survey|rest/i,walk:/walk/i,run:/run/i,dance:/danc/i,sit:/sit/i,wave:/wave|hello|greet/i,jump:/jump|hop/i,pat:/thumb|yes|happy/i,punch:/punch|attack|hit/i};
  for(const k in auto) if(!map[k]){ const n=find(names,auto[k]); if(n) map[k]=n; }
  if(!map.idle) map.idle=names[0];
  const acts={}; const act=(k)=>{ const n=map[k]; if(!n||!clips[n]) return null; if(!acts[n]) acts[n]=mixer.clipAction(clips[n]); return acts[n]; };
  let cur=null, curKey='', once=0, yaw=0, kbT=0, yawNow=0, yawX=0;
  const kb=makeKeyboard(); kb.scale.setScalar(4.2); kb.visible=false; rig.add(kb);
  function play(key,ts,loopOnce){
    const a=act(key)||act('idle'); if(!a) return;
    if(cur===a && !loopOnce) { a.timeScale=ts||1; return; }
    a.reset(); a.timeScale=ts||1;
    if(loopOnce){ a.setLoop(THREE.LoopOnce,1); a.clampWhenFinished=true; } else a.setLoop(THREE.LoopRepeat,Infinity);
    a.enabled=true; a.fadeIn(0.25).play(); if(cur&&cur!==a) cur.fadeOut(0.25); cur=a;
  }
  play('idle');
  const H=cfg.height||32;
  const api={
    id:cfg.id,kind:'walk',root,unit:cfg.unit||7, clips:names,
    hit:(mode)=>({cx:0,cy:H*0.5,rx:cfg.rx||H*0.4,ry:H*0.52}),
    X:{},
    update(dt,S){
      const m=S.mode; let key='idle',ts=1;
      if(m==='walk'){ if((S.speed||0)>0.8 && map.run) { key='run'; } else key='walk'; ts=0.6+0.9*(S.speed||0.5); }
      else if(m==='sit'){ key=map.sit?'sit':'idle'; }
      else if(m==='type'){ key=(S.sitting&&map.sit)?'sit':'idle'; }
      else if(m==='sleep'){ key=map.sit?'sit':'idle'; ts=0.25; }
      else if(m==='dance') key=map.dance?'dance':'idle';
      else if(m==='grab') key=(cfg.post||!map.wave)?'idle':'wave';
      else if(m==='wave') key=map.wave?'wave':'idle';
      else if(m==='pat') key=map.pat?'pat':'idle';
      else if(m==='jump'||m==='fall') key=map.jump?'jump':'idle';
      else if(m==='act'){ key='act_'+S.act; if(!map[key]) key=(S.act==='dance'&&map.dance)?'dance':(S.act==='wave'&&map.wave)?'wave':'idle'; ts=(cfg.actTs&&cfg.actTs[S.act])||1; }
      const sk=key+'|'+ts.toFixed(1);
      if(S.startle>0.6 && once<=0 && map.jump){ play('jump',1.2,true); once=0.8; curKey='once'; }
      else if(S.punch>0.6 && once<=0 && map.punch){ play('punch',1.4,true); once=0.7; curKey='once'; }
      else if(once>0){ once-=dt; }
      else if(sk!==curKey || (cur!==act(key)&&act(key))){ curKey=sk; play(key,ts,!!(m==='act'&&cfg.actOnce&&cfg.actOnce.includes(S.act))); }
      mixer.update(dt);
      if(cfg.post){ newFrame(); yawNow=yaw; cfg.post({model,root,S,dt,find:(n)=>model.getObjectByName(n.replace(/[.\[\]:\/]/g,'')),yaw}); }
      /* turn: side-on while walking, quarter turn when still (animals) or face the camera (people) */
      const f=S.facing||1; let ty=0;
      if(m==='walk'||(m==='act'&&S.moving)) ty=f*(cfg.walkYaw!=null?cfg.walkYaw:1.15); else if(cfg.idleYaw) ty=f*cfg.idleYaw;
      yaw+=(ty-yaw)*kf(dt,9);
      /* spinning on the spot (tail chasing, twirls): keep turning while asked, then settle on a whole turn */
      if(S.spinRate){ yawX+=S.spinRate*dt; } else { const tg=Math.round(yawX/(Math.PI*2))*Math.PI*2; yawX+=(tg-yawX)*kf(dt,10); if(Math.abs(yawX-tg)<0.002) yawX=0; }
      root.rotation.y=yaw+yawX;
      rig.rotation.z=(m==='drag')?clamp(-(S.vx||0)*0.0013,-0.45,0.45):0;
      const want=m==='type'?1:0; kbT+=(want-kbT)*kf(dt,10); kb.visible=kbT>0.02; kb.scale.setScalar(4.2*kbT*(cfg.kb||1)); kb.position.set(0,H*0.42,H*0.28); kb.rotation.x=0.15;
    },
    poke(){}, startle(){}, happy(){}, jet(){}, flinch(){}, wave(){}, tap(){},
    setMood(){}, summon(){}, takeApart(){}, isApart:()=>false, assembling:()=>false, shell(){},
    dispose(){ root.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  };
  return api;
}


/* ---- extra poses for the Robot and the Fox ---- */
const clampN=(v,a,b)=>Math.max(a,Math.min(b,v));
export function robotPost(){
  const st={w:{L:0,R:0},grab:0,type:0};
  const sm=(v,t,dt,r)=>v+(t-v)*(1-Math.exp(-dt*r));
  return (c)=>{
    const {S,dt,find}=c, m=S.mode;
    const uL=find('UpperArm.L'), lL=find('LowerArm.L'), uR=find('UpperArm.R'), lR=find('LowerArm.R');
    if(!uL||!uR) return;
    const typing=m==='type', grab=m==='grab'||S.grab;
    st.type=sm(st.type,typing?1:0,dt,10); st.grab=sm(st.grab,grab?1:0,dt,9);
    if(st.type>0.01){
      const tl=S.tapL||0, tr=S.tapR||0, w=st.type;
      /* the arm on screen-right is the robot's left one when it faces us */
      aimBone(uL,lL,new THREE.Vector3(0.5,-0.8,0.25),w);
      aimBone(lL,find('Palm2.L'),new THREE.Vector3(-0.5-0.0*tl,-0.05-0.3*tl,0.85),w);
      aimBone(uR,lR,new THREE.Vector3(-0.5,-0.8,0.25),w);
      aimBone(lR,find('Palm2.R'),new THREE.Vector3(0.5,-0.05-0.3*tr,0.85),w);
    }
    /* tricks that the clips do not cover */
    if(m==='act'){
      const clamp=clampN, id=S.act, t=S.actT||0, p=S.actP||0, env=Math.min(1,Math.sin(Math.PI*p)*2.4), neck=find('Neck'), head=find('Head'), Yax=new THREE.Vector3(0,1,0), Xax=new THREE.Vector3(1,0,0), Zax=new THREE.Vector3(0,0,1);
      const turn=(b,ang)=>{ if(!b) return; _q.setFromAxisAngle(Yax,ang); applyWorldDelta(b,_q,1); };
      const tilt=(b,ang)=>{ if(!b) return; _q.setFromAxisAngle(Xax,ang); applyWorldDelta(b,_q,1); };
      const roll=(b,ang)=>{ if(!b) return; _q.setFromAxisAngle(Zax,ang); applyWorldDelta(b,_q,1); };
      const sm3=x=>x*x*(3-2*x);
      if(id==='headspin') turn(neck,Math.PI*4*sm3(p));
      else if(id==='scan'){ turn(neck,Math.sin(t*2.3)*1.15*env); tilt(neck,0.1*env); }
      else if(id==='salute'){ const d1=new THREE.Vector3(-0.95,0.3,0.1), d2=new THREE.Vector3(0.2,0.85,0.45); aimBone(uR,lR,d1,env); aimBone(lR,find('Palm2.R'),d2,env); tilt(neck,-0.08*env); }
      else if(id==='glitch'){ const on=Math.sin(t*37)>0.15; if(on){ const r=(k)=>Math.sin(t*(53+k*17)+k*3.1); turn(neck,r(1)*0.7); roll(neck,r(2)*0.35); tilt(neck,r(3)*0.3); if(uL&&lL) aimBone(uL,lL,new THREE.Vector3(0.6+r(4)*0.5,-0.4+r(5)*0.8,0.3),0.8); if(uR&&lR) aimBone(uR,lR,new THREE.Vector3(-0.6+r(6)*0.5,-0.4+r(7)*0.8,0.3),0.8); } }
      else if(id==='powerdown'){ const droop=p<0.68?sm3(clamp(p/0.25,0,1)):1-sm3(clamp((p-0.68)/0.08,0,1)); tilt(neck,0.6*droop); if(uL&&lL) aimBone(uL,lL,new THREE.Vector3(0.12,-1,0.1),droop*0.8); if(uR&&lR) aimBone(uR,lR,new THREE.Vector3(-0.12,-1,0.1),droop*0.8); if(p>0.7&&p<0.86){ turn(neck,Math.sin(t*40)*0.18); } }
      else if(id==='dance'){ turn(neck,Math.sin(t*4.5)*0.35); }
    }
    if(st.grab>0.01){
      const dx=S.cursorDx||0, dy=S.cursorDy||0, n=Math.hypot(dx,dy)||1, d=new THREE.Vector3(dx/n,dy/n,0.25);
      const right=dx>=0; /* cursor on screen-right -> the L arm */
      const u=right?uL:uR, l=right?lL:lR, p=find(right?'Palm2.L':'Palm2.R');
      aimBone(u,l,d,st.grab); aimBone(l,p,d,st.grab);
    }
  };
}
export function foxPost(){
  const st={type:0,sit:0,t:0};
  const sm=(v,t,dt,r)=>v+(t-v)*(1-Math.exp(-dt*r));
  const Y=new THREE.Vector3(0,1,0), X=new THREE.Vector3(1,0,0);
  return (c)=>{
    const {S,dt,find,yaw}=c, m=S.mode; st.t+=dt;
    const head=find('b_Head_05'), neck=find('b_Neck_04'), hip=find('b_Hip_01');
    const fwd=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw)), side=new THREE.Vector3().crossVectors(Y,fwd).normalize();
    /* sit: nose up, rump down */
    const A=m==='act'?S.act:null, ap=S.actP||0, aenv=Math.min(1,Math.sin(Math.PI*ap)*2.4), at=S.actT||0;
    st.sit=sm(st.sit,(m==='sit'||m==='sleep'||(m==='type'&&S.sitting)||A==='curl'||A==='howl'||A==='beg')?1:0,dt,5);
    if(hip&&st.sit>0.01){ _q.setFromAxisAngle(side,-0.4*st.sit); applyWorldDelta(hip,_q,1); const sp=find('b_Spine01_02'); if(sp){ _q.setFromAxisAngle(side,0.12*st.sit); applyWorldDelta(sp,_q,1); } }
    /* sleep: head down */
    if(m==='sleep'&&neck){ _q.setFromAxisAngle(side,0.7); applyWorldDelta(neck,_q,1); }
    /* tricks */
    if(A){
      const dip=(b,a)=>{ if(b){ _q.setFromAxisAngle(side,a); applyWorldDelta(b,_q,1); } };
      const swing=(b,a)=>{ if(b){ _q.setFromAxisAngle(Y,a); applyWorldDelta(b,_q,1); } };
      const spine=find('b_Spine01_02'), spine2=find('b_Spine02_03');
      if(A==='pounce'){
        const crouch=ap<0.62?aenv*0+Math.min(1,ap/0.12)*(ap>0.5?1:1):Math.max(0,1-(ap-0.62)/0.2);
        const leap=(ap>0.62&&ap<0.84)?1:0;
        if(hip) dip(hip,0.42*crouch*(leap?0:1)-0.2*leap); dip(neck,0.35*crouch); dip(head,0.2*crouch);
        if(hip&&ap>0.48&&ap<0.62) swing(hip,Math.sin(at*34)*0.22);
      }
      else if(A==='playbow'){ if(hip) dip(hip,0.5*aenv); dip(spine,0.2*aenv); dip(neck,0.5*aenv); }
      else if(A==='curl'){ dip(neck,1.0*aenv); dip(spine2,0.5*aenv); dip(head,0.25*aenv); }
      else if(A==='howl'){ dip(neck,-0.95*aenv); dip(head,-0.4*aenv); if(head){ _q.setFromAxisAngle(fwd,Math.sin(at*3)*0.05); applyWorldDelta(head,_q,1); } }
      else if(A==='sniff'){ dip(neck,0.8*aenv+0.1*Math.sin(at*9)*aenv); dip(head,0.35*aenv); }
      else if(A==='dig'){ if(hip) dip(hip,0.35*aenv); dip(neck,0.55*aenv); }
      else if(A==='chasetail'){ if(neck) swing(neck,0.9*aenv); if(spine) swing(spine,0.35*aenv); }
    }
    /* look at the cursor */
    if(head&&m!=='sleep'&&m!=='walk'&&!(A&&A!=='beg')){ const lx=S.lookX||0, ly=S.lookY||0; _q.setFromAxisAngle(Y,-lx*0.7*(Math.cos(yaw)>0?1:-1)); applyWorldDelta(head,_q,1); _q2.setFromAxisAngle(side,-ly*0.35); applyWorldDelta(head,_q2,1); }
    /* tail wag, wilder when happy */
    const happy=(m==='pat'||m==='dance'||A==='chasetail'||A==='playbow'||A==='zoomies'||A==='beg'||A==='pounce')?1:0.35, rate=happy>0.5?9:3;
    ['b_Tail01_012','b_Tail02_013','b_Tail03_014'].forEach((n,i)=>{ const b=find(n); if(b){ _q.setFromAxisAngle(Y,Math.sin(st.t*rate-i*0.7)*0.28*happy); applyWorldDelta(b,_q,1); } });
    /* paws: tap on the keyboard, reach for the cursor */
    st.type=sm(st.type,(m==='type')?1:0,dt,10);
    if(st.type>0.01){
      const L=[['b_RightUpperArm_06','b_RightForeArm_07',S.tapL||0],['b_LeftUpperArm_09','b_LeftForeArm_010',S.tapR||0]];
      L.forEach(([u,l,tap])=>{ const U=find(u),Lo=find(l); if(U&&Lo){ const d=fwd.clone().multiplyScalar(0.85).addScaledVector(Y,-0.55+0.25*tap); aimBone(U,Lo,d,st.type); const h=find(l.replace('ForeArm','Hand').replace('_07','_08').replace('_010','_011')); if(h) aimBone(Lo,h,fwd.clone().multiplyScalar(0.9).addScaledVector(Y,-0.35-0.35*tap),st.type); } });
    }
    if(A==='beg'||A==='dig'){
      const wob=Math.sin(at*(A==='dig'?16:6));
      [['b_RightUpperArm_06','b_RightForeArm_07',1],['b_LeftUpperArm_09','b_LeftForeArm_010',-1]].forEach(([u,l,sg])=>{ const U=find(u),Lo=find(l); if(!U||!Lo) return;
        const d=A==='beg'?fwd.clone().multiplyScalar(0.6).addScaledVector(Y,0.8+0.15*wob*sg):fwd.clone().multiplyScalar(-0.35+0.55*Math.max(0,wob*sg)).addScaledVector(Y,-0.85);
        aimBone(U,Lo,d,aenv); });
    }
    if(m==='grab'||S.grab){ const dx=S.cursorDx||0, dy=S.cursorDy||0, n=Math.hypot(dx,dy)||1, d=new THREE.Vector3(dx/n,dy/n,0.2);
      const U=find(dx>=0?'b_LeftUpperArm_09':'b_RightUpperArm_06'), Lo=find(dx>=0?'b_LeftForeArm_010':'b_RightForeArm_07'); if(U&&Lo) aimBone(U,Lo,d,1); }
  };
}

/* ============ VRM models (people-style characters you add yourself): skeleton, faces, hair and clothes swaying ============ */
const BONES=['hips','spine','chest','neck','head','leftUpperArm','leftLowerArm','rightUpperArm','rightLowerArm','leftUpperLeg','leftLowerLeg','rightUpperLeg','rightLowerLeg'];
export async function createVRM(gltf,cfg){
  cfg=cfg||{};
  const json=gltf.parser.json, ext=json.extensions||{};
  const v0=ext.VRM, v1=ext.VRMC_vrm;
  if(!v0&&!v1) throw new Error('This file is not a VRM model.');
  const idx={};
  if(v0&&v0.humanoid) (v0.humanoid.humanBones||[]).forEach(b=>{ idx[b.bone]=b.node; });
  else if(v1&&v1.humanoid) for(const k in v1.humanoid.humanBones) idx[k]=v1.humanoid.humanBones[k].node;
  const bones={};
  for(const n of BONES) if(idx[n]!=null) bones[n]=await gltf.parser.getDependency('node',idx[n]);
  if(!bones.hips||!bones.head) throw new Error('This VRM has no usable skeleton.');
  const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
  const model=gltf.scene; if(v0) model.rotation.y=Math.PI; rig.add(model);
  model.updateMatrixWorld(true);
  const fit=fitModel(model,32);
  const blinks=[],joys=[];
  model.traverse(o=>{
    if(o.isMesh||o.isSkinnedMesh){
      o.frustumCulled=false;
      const ms=Array.isArray(o.material)?o.material:[o.material];
      const out=ms.map(m=>{ const n=new THREE.MeshLambertMaterial({map:m.map||null,color:m.color?m.color.clone():0xffffff,transparent:m.transparent,alphaTest:m.alphaTest||0,side:THREE.DoubleSide,emissive:m.emissive?m.emissive.clone():0x000000,emissiveMap:m.emissiveMap||null});
        n.skinning=!!o.isSkinnedMesh; n.morphTargets=!!o.morphTargetInfluences; n.morphNormals=false; if(m.map) m.map.encoding=THREE.sRGBEncoding; return n; });
      o.material=Array.isArray(o.material)?out:out[0];
      if(o.morphTargetDictionary){ for(const nm in o.morphTargetDictionary){
        if(/^(blink|fcl_eye_close|eye_?close)$/i.test(nm)) blinks.push([o,o.morphTargetDictionary[nm]]);
        else if(/^(joy|fcl_all_joy|happy|fcl_eye_joy)$/i.test(nm)) joys.push([o,o.morphTargetDictionary[nm]]); } }
    }
  });
  /* expressions: blink, happy, angry, sad, relaxed, surprised and mouth shapes a i u e o */
  const assoc=gltf.parser.associations, byMesh={}, byNode={};
  model.traverse(o=>{ const a=assoc&&assoc.get(o); if(a){ if(a.meshes!=null&&o.morphTargetInfluences) (byMesh[a.meshes]=byMesh[a.meshes]||[]).push(o); if(a.nodes!=null) (byNode[a.nodes]=byNode[a.nodes]||[]).push(o); } });
  const morphsUnder=o=>{ const r=[]; o.traverse(m=>{ if(m.morphTargetInfluences) r.push(m); }); return r; };
  const EX={}; /* name -> [[mesh,index,weight 0..1]] */
  const addEx=(nm,list)=>{ if(list.length) EX[nm]=(EX[nm]||[]).concat(list); };
  if(v0&&v0.blendShapeMaster){
    const map0={blink:'blink',joy:'happy',angry:'angry',sorrow:'sad',fun:'relaxed',a:'aa',i:'ih',u:'ou',e:'ee',o:'oh'};
    for(const g of (v0.blendShapeMaster.blendShapeGroups||[])){ const nm=map0[(g.presetName||'').toLowerCase()]; if(!nm) continue;
      const l=[]; (g.binds||[]).forEach(b=>{ (byMesh[b.mesh]||[]).forEach(m=>l.push([m,b.index,(b.weight==null?100:b.weight)/100])); }); addEx(nm,l); }
  } else if(v1&&v1.expressions&&v1.expressions.preset){
    const pr=v1.expressions.preset;
    for(const nm in pr){ const l=[]; ((pr[nm]&&pr[nm].morphTargetBinds)||[]).forEach(b=>{ (byNode[b.node]||[]).forEach(o=>morphsUnder(o).forEach(m=>l.push([m,b.index,b.weight==null?1:b.weight]))); }); addEx(nm,l); }
  }
  const exCur={}, hasEx=Object.keys(EX).length>0;
  const rest={}; for(const n in bones) rest[n]=bones[n].quaternion.clone();
  let springs=null; try{ springs=await createSprings(gltf,model,rig,fit); }catch(e){ console.warn('springs',e); }
  let lastX=0,lastY=0;
  const hipRest=bones.hips.position.clone();
  const feet=new THREE.Box3().setFromObject(model).min.y;
  const hipsY=new THREE.Vector3().setFromMatrixPosition(bones.hips.matrixWorld); /* world, before scaling parent; we use ratio below */
  const hipH=(()=>{ model.updateMatrixWorld(true); const v=new THREE.Vector3().setFromMatrixPosition(bones.hips.matrixWorld); const b=new THREE.Box3().setFromObject(model); return v.y-b.min.y; })();
  const pose=makePose(); const E=new THREE.Euler(), Q=new THREE.Quaternion();
  const q=(x,y,z)=>Q.setFromEuler(E.set(x,y,z,'XYZ')).clone();
  const kb=makeKeyboard(); kb.scale.setScalar(4.6); kb.visible=false; rig.add(kb);
  let blinkT=2+Math.random()*3, blinkV=0, kbT=0, dropY=0, t=0;
  const setMorph=(list,v)=>list.forEach(([o,i])=>{ o.morphTargetInfluences[i]=v; });
  const api={
    id:cfg.id||'vrm',kind:'walk',isHuman:true,root,unit:7,
    hit:(mode)=>mode==='perch'?{cx:0,cy:5,rx:10,ry:17}:{cx:0,cy:16,rx:10,ry:17},
    X:{},
    update(dt,S){
      t+=dt; const p=stepPose(pose,S,dt);
      root.rotation.y=p.turn;
      dropY+=((-hipH*p.drop*0.98)-dropY)*kf(dt,9);
      rig.position.y=dropY+(p.bob+p.hop)*32;
      const B=bones, R=rest;
      const set=(n,dq)=>{ if(B[n]) B[n].quaternion.copy(R[n]).multiply(dq); };
      set('spine',q(p.pitch*0.6,0,p.roll*0.6)); if(B.chest) set('chest',q(p.pitch*0.4,0,p.roll*0.4));
      if(B.neck) set('neck',q(p.headX*0.4,p.headY*0.4,p.headZ*0.4)); set('head',q(p.headX*0.6,p.headY*0.6,p.headZ*0.6));
      const arm=(side,ang,fw,el)=>{
        const L=side==='left', z=L?ang:ang+Math.PI;
        const dq=new THREE.Quaternion().setFromEuler(E.set(fw,0,0)).multiply(new THREE.Quaternion().setFromEuler(E.set(0,0,z)));
        set(L?'leftUpperArm':'rightUpperArm',dq);
        set(L?'leftLowerArm':'rightLowerArm',q(0,L?-el:el,0));
      };
      arm('left',p.aLa,p.aLf,p.aLe); arm('right',p.aRa,p.aRf,p.aRe);
      set('leftUpperLeg',q(p.lLx,0,0)); set('rightUpperLeg',q(p.lRx,0,0)); set('leftLowerLeg',q(p.lLk,0,0)); set('rightLowerLeg',q(p.lRk,0,0));
      /* blinking and joy */
      blinkT-=dt; if(blinkT<0){ blinkV=1; blinkT=2.5+Math.random()*3.5; }
      blinkV=Math.max(0,blinkV-dt*7);
      const closed=(S.mode==='sleep')?1:Math.sin(Math.PI*Math.min(1,blinkV))*1;
      if(!hasEx){ setMorph(blinks,clamp(closed,0,1)); setMorph(joys,S.mode==='pat'?1:0); }
      else {
        const m=S.mode, talk=S.talk>0;
        const T={blink:closed,happy:(m==='pat'||m==='dance'||S.joy>0.3||(m==='act'&&/^(cheer|peace|flex|spin|jacks|clap|bow|salute)$/.test(S.act)))?1:0,angry:S.punch>0.3?1:0,sad:0,relaxed:(m==='sit'&&!talk)?0.6:0,surprised:(S.startle>0.35||m==='fall'||m==='drag')?1:0,aa:0,ih:0,ou:0,ee:0,oh:0};
        if(m==='sleep'){ T.blink=1; T.relaxed=0.5; }
        if(m==='act'){ const en=Math.min(1,Math.sin(Math.PI*(S.actP||0))*2.4); if(S.act==='yawn'){ T.aa=0.9*en; T.blink=Math.max(T.blink,0.7*en); } else if(S.act==='facepalm'){ T.sad=0.8*en; } else if(S.act==='karate'||S.act==='mine'){ T.angry=0.5*en; } else if(S.act==='think'){ T.relaxed=0.6*en; } else if(S.act==='eat'){ T.relaxed=0.3; T.aa=0.45*Math.abs(Math.sin(t*7))*en; } }
        if(talk){ const ph=Math.floor(t*7.5)%5, o=0.35+0.45*Math.abs(Math.sin(t*15)); T[['aa','oh','ih','ee','ou'][ph]]=o; }
        else if(T.surprised&&!EX.surprised) T.oh=0.7;
        for(const nm in EX){ exCur[nm]=(exCur[nm]||0)+((T[nm]||0)-(exCur[nm]||0))*kf(dt,nm==='blink'?30:14); }
        for(const nm in EX) EX[nm].forEach(([mm,i])=>{ mm.morphTargetInfluences[i]=0; });
        for(const nm in EX){ const v=exCur[nm]; if(v>0.002) EX[nm].forEach(([mm,i,w])=>{ mm.morphTargetInfluences[i]=Math.min(1,mm.morphTargetInfluences[i]+v*w); }); }
      }
      /* hair and clothes */
      if(springs){ const sc=S.unitScale||7; const mx=((S.vx||0)*dt)/sc, my=-((S.vy||0)*dt)/sc; springs.update(dt,clamp(mx,-3,3),clamp(my,-3,3)); }
      const want=S.mode==='type'?1:0; kbT+=(want-kbT)*kf(dt,10); kb.visible=kbT>0.02; kb.scale.setScalar(4.6*kbT); kb.position.set(0,hipH+dropY*0+2.5,7.5); kb.rotation.x=0.15;
    },
    poke(){}, startle(){}, happy(){}, jet(){}, flinch(){}, wave(){}, tap(){},
    setMood(){}, summon(){}, takeApart(){}, isApart:()=>false, assembling:()=>false, shell(){},
    dispose(){ root.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  };
  return api;
}
