import {clamp,lerp,kf} from './props.js';
import {actPose} from './actpose.js';

/* One animation brain for every humanoid (blocky, VRM). It turns the behaviour state into joint angles.
   Arms use "ang": the direction the arm points in the screen plane (-PI/2 = straight down, 0 = toward screen right, PI/2 = up). */
const DOWN=-Math.PI/2;
export function makePose(){
  return { ph:0, t:0, cur:{bob:0,turn:0,roll:0,pitch:0,headX:0,headY:0,headZ:0,
    aLa:DOWN+0.18,aLf:0,aLe:0,aRa:DOWN-0.18,aRf:0,aRe:0, lLx:0,lLk:0,lRx:0,lRk:0, drop:0, hop:0} };
}
export function stepPose(st,S,dt){
  st.t+=dt; const t=st.t, c=st.cur, m=S.mode, mu=0.5+0.5*(S.music||0);
  const f=S.facing||1, tg={bob:0,turn:0,roll:0,pitch:0,headX:0,headY:0,headZ:0,
    aLa:DOWN+0.18,aLf:0,aLe:0.1,aRa:DOWN-0.18,aRf:0,aRe:0.1, lLx:0,lLk:0,lRx:0,lRk:0, drop:0, hop:0};
  const lookY=clamp(S.lookX||0,-1,1)*0.7, lookX=-clamp(S.lookY||0,-1,1)*0.35;
  tg.headY=lookY; tg.headX=lookX; tg.pitch=0.02*Math.sin(t*2);
  let rate=12;
  switch(m){
    case 'walk': {
      st.ph+=dt*(5+5*(S.speed||0.5)); const s=Math.sin(st.ph), cs=Math.cos(st.ph);
      tg.lLx=s*0.8; tg.lRx=-s*0.8; tg.lLk=Math.max(0,cs)*0.8; tg.lRk=Math.max(0,-cs)*0.8;
      tg.aLf=-s*0.65; tg.aRf=s*0.65; tg.bob=Math.abs(s)*0.04; tg.turn=f*1.15; tg.headY=lookY*0.4; tg.pitch=0.06; tg.roll=0.03*s; break; }
    case 'sit': case 'sleep': {
      tg.drop=1; tg.lLx=-1.5+Math.sin(t*1.4)*0.12; tg.lRx=-1.5+Math.sin(t*1.4+1.4)*0.12; tg.lLk=1.45; tg.lRk=1.45;
      tg.aLf=-0.3; tg.aRf=-0.3; tg.aLa=DOWN+0.3; tg.aRa=DOWN-0.3; tg.turn=0.12*f;
      if(m==='sleep'){ tg.headX=0.6; tg.headY=0.1; tg.pitch=0.18+0.03*Math.sin(t*1.2); tg.aLf=-0.55; tg.aRf=-0.55; }
      break; }
    case 'dance': {
      const s=Math.sin(t*5.5), s2=Math.sin(t*2.75);
      tg.bob=Math.abs(s)*0.09*mu; tg.roll=s2*0.12*mu; tg.turn=s2*0.6;
      tg.aLa=Math.PI/2-0.25+s*0.4*mu; tg.aRa=Math.PI/2+0.25-s*0.4*mu; tg.aLe=0.6; tg.aRe=0.6;
      tg.lLx=s*0.4*mu; tg.lRx=-s*0.4*mu; tg.lLk=0.5*Math.max(0,s); tg.lRk=0.5*Math.max(0,-s); tg.headZ=s*0.12; tg.headX=0.1*Math.abs(s); break; }
    case 'type': {
      if(S.sitting){ tg.drop=1; tg.lLx=-1.5; tg.lRx=-1.5; tg.lLk=1.45; tg.lRk=1.45; }
      tg.aLf=-1.25+0.22*(S.tapL||0); tg.aRf=-1.25+0.22*(S.tapR||0); tg.aLe=1.0; tg.aRe=1.0; tg.aLa=DOWN+0.45; tg.aRa=DOWN-0.45;
      tg.headX=0.28+lookX*0.3; tg.pitch=0.08; break; }
    case 'wave': {
      tg.aRa=Math.PI/2+0.35+Math.sin(t*9)*0.3; tg.aRe=0.7+0.4*Math.sin(t*9); tg.headZ=0.1; tg.turn=-0.2; break; }
    case 'jump': case 'fall': {
      const fl=Math.sin(t*14)*0.25;
      tg.aLa=Math.PI/2-0.5+fl; tg.aRa=Math.PI/2+0.5-fl; tg.lLx=-0.5+fl; tg.lRx=0.3-fl; tg.lLk=0.8; tg.lRk=0.4; tg.pitch=m==='jump'?0.1:0; rate=9; break; }
    case 'drag': {
      const sw=Math.sin(t*7)*0.25+clamp(-(S.vx||0)*0.0016,-0.5,0.5);
      tg.aLa=Math.PI/2-0.15+sw*0.6; tg.aRa=Math.PI/2+0.15+sw*0.6; tg.lLx=sw; tg.lRx=-sw*0.6; tg.lLk=0.3; tg.lRk=0.3;
      tg.roll=clamp(-(S.vx||0)*0.0013,-0.45,0.45); tg.drop=0.0; rate=9; break; }
    case 'pat': {
      tg.headZ=0.15*Math.sin(t*9); tg.roll=0.07*Math.sin(t*9+1); tg.aLa=1.0; tg.aRa=Math.PI-1.0; tg.aLe=1.6; tg.aRe=1.6; tg.headX=-0.15; tg.bob=0.03*Math.abs(Math.sin(t*9)); break; }
    case 'act': actPose(S.act,S,tg,st,dt); break;
    default: break; /* idle */
  }
  if(m==='grab' || S.grab){
    const a=Math.atan2(S.cursorDy||0,S.cursorDx||0);
    if((S.cursorDx||0)>=0){ tg.aLa=a; tg.aLe=0.15; tg.aLf=0; } else { tg.aRa=a; tg.aRe=0.15; tg.aRf=0; }
  }
  if(S.punch>0.02){ tg.aRa=DOWN-0.2+S.punch*0.0; tg.aRf=-1.55*S.punch; tg.aRe=0.1; tg.turn+=0.3*S.punch; tg.pitch+=0.12*S.punch; }
  if(S.startle>0.05){ tg.aLa=Math.PI/2-0.4; tg.aRa=Math.PI/2+0.4; tg.hop=S.startle*0.12; }
  if(m!=='act'&&Math.abs(c.turn)>Math.PI){ c.turn-=Math.round(c.turn/(Math.PI*2))*Math.PI*2; } /* after a twirl */
  for(const k in tg){ const r=(k==='headX'||k==='headY')?10:rate; c[k]+=(tg[k]-c[k])*kf(dt,r); }
  return c;
}
