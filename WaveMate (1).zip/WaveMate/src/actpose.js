import {clamp,lerp} from './props.js';
/* Poses for the tricks of people-shaped characters (Blocky Miner, VRM models).
   Called from stepPose with the target pose `tg` already set to idle; we bend it toward the trick.
   Arm angle: -PI/2 down, 0 screen-right, PI/2 up, PI screen-left. aXf = swing forward (negative), aXe = elbow bend.
   aL is the arm on the screen's right, aR on the screen's left. */
const DOWN=-Math.PI/2, TAU=Math.PI*2;
const sm=p=>p*p*(3-2*p);
export const swingPhase=(t)=>{ /* the pickaxe: 0 = rest, 1 = raised */
  const ph=(t/0.8)%1; if(ph<0.6) return sm(ph/0.6); if(ph<0.72) return 1-sm((ph-0.6)/0.12); return 0; };
export const swingCount=(t)=>Math.floor(t/0.8+0.28);

export function actPose(id,S,tg,st,dt){
  const t=S.actT||0, p=clamp(S.actP||0,0,1);
  const env=Math.min(1,Math.sin(Math.PI*p)*2.4); /* ease in, hold, ease out */
  const B=(k,v)=>{ tg[k]+=(v-tg[k])*env; };
  const sin=Math.sin, abs=Math.abs;
  switch(id){
    case 'stretch': B('aLa',Math.PI/2-0.12); B('aRa',Math.PI/2+0.12); B('aLe',0); B('aRe',0); B('pitch',-0.2); B('headX',-0.3); tg.bob+=0.05*env; tg.roll+=0.1*sin(t*2.2)*env; break;
    case 'bow': B('pitch',0.9); B('headX',0.3); B('aLa',DOWN+0.05); B('aRa',DOWN-0.05); B('aLf',-0.15); B('aRf',-0.15); break;
    case 'peace': B('aRa',Math.PI/2+0.4+0.08*sin(t*6)); B('aRe',1.9); B('aRf',-0.5); B('headZ',0.22); B('turn',-0.25); tg.hop+=0.02*abs(sin(t*4))*env; break;
    case 'spin': B('aLa',0.1); B('aRa',Math.PI-0.1); B('aLe',0); B('aRe',0); tg.turn=TAU*2*sm(p); tg.hop+=0.07*env*abs(sin(t*5)); break;
    case 'cheer': B('aLa',Math.PI/2-0.25+0.22*sin(t*10)); B('aRa',Math.PI/2+0.25-0.22*sin(t*10)); B('aLe',0.3); B('aRe',0.3); B('headX',-0.2); tg.hop+=0.11*abs(sin(t*8))*env; break;
    case 'think': B('aRf',-1.35); B('aRe',2.3); B('aRa',DOWN+0.3); B('aLf',-1.0); B('aLe',1.7); B('aLa',DOWN+0.35); B('headZ',0.22); B('headX',0.12); tg.headY=0.35*sin(t*0.9)*env; break;
    case 'yawn': { const up=sm(clamp(p*1.6,0,1))*(1-sm(clamp((p-0.7)/0.3,0,1))); tg.aLa+=((Math.PI/2-0.45)-tg.aLa)*up; tg.aRa+=((Math.PI/2+0.45)-tg.aRa)*up; tg.aLe=tg.aRe=0; B('headX',-0.5); B('pitch',-0.12); tg.bob+=0.04*up; break; }
    case 'salute': B('aRa',Math.PI-0.5); B('aRe',2.5); B('aRf',-0.25); B('pitch',-0.06); B('headX',-0.05); break;
    case 'karate': { const s=sin(t*7); B('aLa',DOWN+0.5); B('aRa',DOWN-0.5); tg.aLf=-1.55*Math.max(0,s)*env; tg.aRf=-1.55*Math.max(0,-s)*env; B('lLx',0.3); B('lRx',-0.3); B('lLk',0.35); B('lRk',0.35); tg.bob-=0.04*env; tg.turn=0.4*s*env; tg.headX=0.1*env; break; }
    case 'flex': B('aLf',-1.5); B('aRf',-1.5); B('aLe',1.7+0.2*sin(t*8)); B('aRe',1.7+0.2*sin(t*8)); B('aLa',DOWN+0.35); B('aRa',DOWN-0.35); B('pitch',-0.1); B('headX',-0.1); tg.hop+=0.015*abs(sin(t*8))*env; break;
    case 'clap': { const c=0.5+0.5*sin(t*14); B('aLf',-1.25); B('aRf',-1.25); B('aLe',1.0); B('aRe',1.0); tg.aLa+=((DOWN+0.55-0.55*c)-tg.aLa)*env; tg.aRa+=((DOWN-0.55+0.55*c)-tg.aRa)*env; tg.hop+=0.02*abs(sin(t*7))*env; B('headX',0.1); break; }
    case 'facepalm': B('aRf',-1.5); B('aRe',2.4); B('aRa',DOWN+0.2); B('headX',0.5); B('pitch',0.08); tg.headY=0.15*sin(t*7)*env; break;
    case 'jacks': { const k=0.5+0.5*sin(t*8); tg.aLa+=((lerp(DOWN+0.2,Math.PI/2-0.3,k))-tg.aLa)*env; tg.aRa+=((lerp(DOWN-0.2,Math.PI/2+0.3-TAU,k))-tg.aRa)*env; tg.hop+=0.12*k*env; tg.lLk=0.3*k*env; tg.lRk=0.3*k*env; break; }
    case 'sneak': { st.ph+=dt*3.2; const s=sin(st.ph), cs=Math.cos(st.ph);
      B('pitch',0.38); B('lLk',0.85); B('lRk',0.85); tg.lLx+=(0.5+s*0.45)*env; tg.lRx+=(0.5-s*0.45)*env; tg.bob-=0.05*env; B('aLa',DOWN+0.45); B('aRa',DOWN-0.45); B('aLf',-0.35); B('aRf',-0.35); B('aLe',0.5); B('aRe',0.5);
      tg.headY=sin(t*1.7)*0.6*env; tg.turn=(S.facing||1)*1.15*env; break; }
    case 'mine': { const L=swingPhase(t); B('aRa',DOWN-0.1); tg.aRf+=((-0.35-2.0*L)-tg.aRf)*env; tg.aRe+=(0.35-tg.aRe)*env; B('aLf',-0.5); B('aLe',0.8); tg.pitch+=(0.1+0.3*(1-L))*env; tg.headX+=0.25*env; tg.turn=-0.35*env; tg.bob-=0.02*env; break; }
    case 'build': { const placing=(t%1.1)<0.3; B('pitch',0.3); B('aRf',-1.2-(placing?0.35:0)); B('aLf',-0.9); B('aRe',0.8); B('aLe',0.8); B('aRa',DOWN-0.2); B('aLa',DOWN+0.3); B('headX',0.35); tg.turn=0.45*env; tg.bob-=0.03*env; break; }
    case 'eat': { const bite=0.5+0.5*sin(t*7); B('aRf',-1.45); B('aRe',2.3); B('aRa',DOWN-0.1); B('headX',0.12+0.15*bite); tg.headZ=0.05*sin(t*7)*env; B('aLf',-0.2); break; }
    default: break;
  }
  if(S.act!=='spin'&&S.act!=='sneak'&&S.act!=='karate'&&S.act!=='peace'&&S.act!=='mine'&&S.act!=='build'){ /* keep facing the screen */ }
}
