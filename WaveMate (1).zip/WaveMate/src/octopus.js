import * as THREE from 'three';
export function createOctopus(){
'use strict';
var TMIN=0.2, TMAX=1.4;
/* ---------- materials (PE-1 set) ---------- */
var SHELL={white:0xf1f2f0,graphite:0x2f353a};
var shellTinted=[];
var MK={
  white:function(){return new THREE.MeshPhysicalMaterial({color:SHELL.white,roughness:0.5,metalness:0,clearcoat:0.3,clearcoatRoughness:0.35})},
  steel:function(){return new THREE.MeshStandardMaterial({color:0xd4d8db,metalness:0.7,roughness:0.5,envMapIntensity:0.75})},
  brushed:function(){return new THREE.MeshStandardMaterial({color:0xb4babf,metalness:0.6,roughness:0.6,envMapIntensity:0.7})},
  dark:function(){return new THREE.MeshStandardMaterial({color:0x22272c,metalness:0.4,roughness:0.6,side:THREE.DoubleSide})},
  black:function(){return new THREE.MeshStandardMaterial({color:0x0e1114,metalness:0.2,roughness:0.6})},
  orange:function(){var m=new THREE.MeshStandardMaterial({color:0xe4572e,emissive:0x5a1a06,emissiveIntensity:0,metalness:0.1,roughness:0.45}); m.userData.orange=true; return m;},
  pcb:function(){return new THREE.MeshStandardMaterial({color:0x1b2a26,metalness:0.3,roughness:0.55})},
  blade:function(){return new THREE.MeshStandardMaterial({color:0x2a3036,metalness:0.55,roughness:0.45,side:THREE.DoubleSide})},
  glass:function(){return new THREE.MeshPhysicalMaterial({color:0x10161c,metalness:0,roughness:0.03,clearcoat:1,clearcoatRoughness:0.02,transparent:true,opacity:0.3,depthWrite:false,envMapIntensity:1.8,side:THREE.DoubleSide})},
  coated:function(tex){return new THREE.MeshPhysicalMaterial({color:0xffffff,map:tex,metalness:0.1,roughness:0.08,clearcoat:1,clearcoatRoughness:0.04,envMapIntensity:1.5,side:THREE.DoubleSide})},
  liner:function(){return new THREE.MeshStandardMaterial({color:0x2a3035,metalness:0.5,roughness:0.65,side:THREE.DoubleSide})}
};
function coatTex(){
  var c=document.createElement('canvas'); c.width=8; c.height=512;
  var x=c.getContext('2d'); x.fillStyle='#0a0d11'; x.fillRect(0,0,8,512);
  function band(v,w,col){var y0=v*512; var gg=x.createLinearGradient(0,y0-w,0,y0+w); gg.addColorStop(0,'rgba(0,0,0,0)'); gg.addColorStop(0.5,col); gg.addColorStop(1,'rgba(0,0,0,0)'); x.fillStyle=gg; x.fillRect(0,y0-w,8,w*2);}
  [[0.10,10,'rgba(120,90,190,.55)'],[0.20,7,'rgba(70,150,150,.6)'],[0.30,6,'rgba(190,140,60,.5)'],[0.40,8,'rgba(90,110,190,.5)'],[0.46,4,'rgba(200,200,210,.55)']].forEach(function(b){
    band(b[0],b[1],b[2]); band(1-b[0],b[1],b[2]);
  });
  var t=new THREE.CanvasTexture(c); t.encoding=THREE.sRGBEncoding; t.anisotropy=4; return t;
}
var COAT=coatTex();
/* ---------- geometry helpers (PE-1) ---------- */
function gearGeo(Ro,Ri,teeth,depth,toothH,bore){
  var sh=new THREE.Shape(), step=Math.PI*2/teeth, rr=Ro-toothH, i, a;
  function P(ang,r){return [Math.cos(ang)*r,Math.sin(ang)*r]}
  for(i=0;i<teeth;i++){
    a=i*step;
    var p=[P(a,rr),P(a+step*0.12,Ro),P(a+step*0.38,Ro),P(a+step*0.5,rr)];
    for(var k=0;k<4;k++){ if(i===0&&k===0) sh.moveTo(p[k][0],p[k][1]); else sh.lineTo(p[k][0],p[k][1]); }
  }
  sh.closePath();
  var h=new THREE.Path(); h.absarc(0,0,bore||Ri,0,Math.PI*2,true); sh.holes.push(h);
  var g=new THREE.ExtrudeGeometry(sh,{depth:depth,bevelEnabled:true,bevelThickness:depth*0.12,bevelSize:0.004,bevelSegments:1,curveSegments:12});
  g.translate(0,0,-depth/2); return g;
}
function ringGeo(Ro,Ri,depth){
  var sh=new THREE.Shape(); sh.absarc(0,0,Ro,0,Math.PI*2,false);
  var h=new THREE.Path(); h.absarc(0,0,Ri,0,Math.PI*2,true); sh.holes.push(h);
  var g=new THREE.ExtrudeGeometry(sh,{depth:depth,bevelEnabled:true,bevelThickness:depth*0.15,bevelSize:0.006,bevelSegments:2,curveSegments:64});
  g.translate(0,0,-depth/2); return g;
}
function lensGeo(R,zf,zb,steps){
  var pts=[],k;
  for(k=0;k<=steps;k++){var u=k/steps; pts.push(new THREE.Vector2(R*u,zf*(1-u*u)));}
  for(k=steps;k>=0;k--){var u2=k/steps; pts.push(new THREE.Vector2(R*u2,-zb*(1-u2*u2)));}
  var g=new THREE.LatheGeometry(pts,56); g.rotateX(Math.PI/2); return g;
}
function cyl(r,len,seg,open){var g=new THREE.CylinderGeometry(r,r,len,seg||40,1,!!open); g.rotateX(Math.PI/2); return g;}
function lerp(a,b,t){return a+(b-a)*t;}
function clamp(x,a,b){return x<a?a:(x>b?b:x);}
function sm(x){x=clamp(x,0,1);return x*x*(3-2*x);}
/* ---------- scene graph ----------
   rig (camera orbit) > body (floats) > head parts + eye core + tentacles. The head centre is the body origin. */
var root=new THREE.Group(); var rig=new THREE.Group(); root.add(rig);
var body=new THREE.Group(); rig.add(body);
var BODY_Y=0.72;
var headG=new THREE.Group(); body.add(headG);
var linerG=new THREE.Group(); headG.add(linerG);
var gazePivot=new THREE.Group(); body.add(gazePivot);
var CS=0.58, CZ=0.765;
var core=new THREE.Group(); core.position.z=CZ; core.scale.setScalar(CS); gazePivot.add(core);

var parts=[], movers=[];
function Part(id,name,o){
  var p={id:id,name:name,mats:{},specs:[],note:'',anchor:new THREE.Vector3(),obj:null,screen:{x:0,y:0}};
  for(var k in o) p[k]=o[k];
  parts.push(p); return p;
}
function M(p,key,arg){
  if(!p.mats[key]){ p.mats[key]=MK[key](arg); if(key==='white') shellTinted.push(p.mats[key]); }
  return p.mats[key];
}
function mesh(p,geo,key,parent,o){
  o=o||{};
  var m=new THREE.Mesh(geo,M(p,key,o.arg));
  m.castShadow=!o.noShadow; m.receiveShadow=true; m.userData.part=p; parent.add(m); return m;
}
function mover(p,o){
  var g=new THREE.Group(); g.userData.part=p; core.add(g); g.position.z=o.home||0;
  var mv={g:g,home:o.home||0,away:o.away||0,zoomK:o.zoomK||0,rank:o.rank||0}; movers.push(mv);
  if(!p.obj) p.obj=g;
  return mv;
}

/* --- head shell: 27 panels + rear cap over a dark liner. Each band is one instanced mesh. --- */
var R=1.6, TH0=0.40, GAP=0.02;
var Rop=R*Math.sin(TH0), Zop=R*Math.cos(TH0);
var shellPart=Part('shell','Shell panels',{
  specs:[['Panels','27 + rear cap'],['Finish','Satin ceramic polymer'],['Fasteners','86 button screws']],
  note:'Outer panels bolt to the dark chassis liner. They slide outward when the head is opened and flinch when the head is tapped.'});
shellPart.anchorFn=function(v){ var p=panels[9]; v.copy(p.dir).multiplyScalar(R+p.off); };
var panels=[], bandMeshes=[], screws=[], screwMesh;
(function(){
  var bands=[[TH0,1.02,6,0],[1.02,1.72,8,0.5],[1.72,2.42,8,0],[2.42,2.96,5,0.5],[2.96,Math.PI-0.001,1,0]];
  bands.forEach(function(b,bi){
    var n=b[2], seg=Math.PI*2/n;
    var t0=b[0]+GAP, t1=b[1]-(bi===4?0:GAP), p0=(n===1?0:GAP/Math.max(0.5,Math.sin((t0+t1)/2))), p1=(n===1?Math.PI*2-0.001:seg-p0);
    var g=new THREE.SphereGeometry(R,Math.max(6,Math.round((p1-p0)*9)),Math.max(4,Math.round((t1-t0)*9)),p0,p1-p0,t0,t1-t0);
    g.rotateX(Math.PI/2);
    var outer=new THREE.InstancedMesh(g,M(shellPart,'white'),n), inner=new THREE.InstancedMesh(g,M(shellPart,'dark'),n);
    outer.castShadow=true; outer.receiveShadow=true; outer.frustumCulled=false; inner.frustumCulled=false;
    outer.userData.part=shellPart; inner.userData.part=shellPart; outer.userData.head=true; inner.userData.head=true;
    headG.add(outer,inner); bandMeshes.push({outer:outer,inner:inner,first:panels.length,n:n});
    var tm=(t0+t1)/2, pm=(p0+p1)/2;
    for(var i=0;i<n;i++){
      var rot=i*seg+b[3]*seg, pp=pm+rot;
      var dir=new THREE.Vector3(-Math.cos(pp)*Math.sin(tm),-Math.sin(pp)*Math.sin(tm),Math.cos(tm)).normalize();
      var pi=panels.length;
      panels.push({dir:dir,rot:rot,rank:0.34+0.09*bi+0.012*i,off:0,spin:0});
      if(bi<4){
        var ends=(bi===1||bi===2)?[t0+0.1,t1-0.1]:[bi===0?t1-0.1:t0+0.1];
        ends.forEach(function(tt){
          [-1,1].forEach(function(sg){
            var ph=pp+sg*(p1-p0)*0.38;
            screws.push({panel:pi,d:new THREE.Vector3(-Math.cos(ph)*Math.sin(tt),-Math.sin(ph)*Math.sin(tt),Math.cos(tt)).normalize()});
          });
        });
      }
    }
  });
  screwMesh=new THREE.InstancedMesh(new THREE.CylinderGeometry(0.028,0.028,0.02,10),M(shellPart,'steel'),screws.length);
  screwMesh.frustumCulled=false; screwMesh.userData.part=shellPart; screwMesh.userData.head=true; headG.add(screwMesh);
})();

/* --- chassis liner with two thin orange seam lines --- */
var linerPart=Part('liner','Chassis liner',{
  specs:[['Material','Machined aluminium, black anodised'],['Seams','2 orange index lines'],['Role','Carries the panels, eye and arm collars']],
  note:'Dark inner frame. It stays in place so the gaps between panels never show daylight.'});
linerPart.obj=linerG; linerPart.anchor.set(-1.0,0.95,-0.55);
(function(){
  var g=new THREE.SphereGeometry(1.46,48,32,0,Math.PI*2,TH0-0.03,Math.PI-TH0+0.03); g.rotateX(Math.PI/2);
  var m=mesh(linerPart,g,'liner',linerG); m.userData.head=true;
  [1.02,1.72].forEach(function(th){
    var s=mesh(linerPart,new THREE.TorusGeometry(R*0.985*Math.sin(th),0.008,6,96),'orange',linerG,{noShadow:true});
    s.position.z=R*0.985*Math.cos(th);
  });
})();

/* --- front bezel: fixed to the head, the eye turns behind it --- */
var bezelPart=Part('bezel','Front bezel',{
  specs:[['Outer diameter','1.36 units'],['Finish','Brushed steel with an orange index ring'],['Mount','6 locking tabs']],
  note:'Frames the eye socket. The eye turns behind it, so the head stays sealed while the eye looks around.'});
var bezelG=new THREE.Group(); bezelG.position.z=Zop; headG.add(bezelG); bezelPart.obj=bezelG; bezelPart.anchor.set(Rop,0.1,0);
(function(){
  var b=mesh(bezelPart,new THREE.TorusGeometry(Rop,0.058,20,80),'steel',bezelG); b.userData.head=true;
  var o=mesh(bezelPart,new THREE.TorusGeometry(Rop-0.07,0.036,12,80),'orange',bezelG,{noShadow:true}); o.position.z=0.03;
})();

/* --- eye core (PE-1 mechanism, scaled down and set into the head) --- */
var glassP=Part('glass','Front glass',{
  specs:[['Element','Sapphire-coated, f/1.4 class'],['Diameter','0.81 units'],['Coating','Anti-reflective, multilayer']],
  note:'Protects the lens stack. The dark tint cuts glare while the coating keeps colour neutral.'});
glassP.anchor.set(0.45,0.4,0.1);
var glassMv=mover(glassP,{home:1.02,away:3.9,zoomK:0.55,rank:0.5});
mesh(glassP,lensGeo(0.7,0.17,0.04,22),'glass',glassMv.g,{noShadow:true});
mesh(glassP,new THREE.TorusGeometry(0.71,0.03,10,56),'dark',glassMv.g);

var scaleP=Part('scale','Scale ring',{
  specs:[['Marks','60 minor, 12 major'],['Speed','Follows the swim speed'],['Material','White polymer, laser-etched']],
  note:'Reads the lens position. It turns slowly all the time so the eye never looks parked.'});
scaleP.anchor.set(0.8,-0.45,0);
var scaleMv=mover(scaleP,{home:1.13,away:2.8,rank:0.46});
var scaleSpin=new THREE.Group(); scaleMv.g.add(scaleSpin);
mesh(scaleP,ringGeo(0.94,0.79,0.08),'blade',scaleSpin);
(function(){
  var minor=new THREE.InstancedMesh(new THREE.BoxGeometry(0.012,0.06,0.01),M(scaleP,'steel'),60);
  var major=new THREE.InstancedMesh(new THREE.BoxGeometry(0.02,0.085,0.011),M(scaleP,'orange'),12);
  var d=new THREE.Object3D(), mi=0, ji=0;
  for(var i=0;i<60;i++){
    var a=i/60*Math.PI*2, isMaj=(i%5===0), r=isMaj?0.868:0.872;
    d.position.set(Math.cos(a)*r,Math.sin(a)*r,0.054); d.rotation.set(0,0,a-Math.PI/2); d.updateMatrix();
    if(isMaj) major.setMatrixAt(ji++,d.matrix); else minor.setMatrixAt(mi++,d.matrix);
  }
  minor.count=mi; major.count=ji; minor.userData.part=scaleP; major.userData.part=scaleP; scaleSpin.add(minor,major);
})();

var focusP=Part('focus','Focus ring',{
  specs:[['Knurl','72 teeth'],['Drive','Geared to the focus motor'],['Material','Stainless steel']],
  note:'Spins up in short bursts when the eye refocuses, then settles.'});
focusP.anchor.set(-0.8,0.45,0);
var focusMv=mover(focusP,{home:0.97,away:2.25,rank:0.42});
var focusSpin=new THREE.Group(); focusMv.g.add(focusSpin);
mesh(focusP,gearGeo(0.9,0.79,72,0.1,0.022,0.79),'steel',focusSpin);

var irisP=Part('iris','Iris, 9 blades',{
  specs:[['Blades','9, hardened steel'],['Range','f/1.4 to f/6.3'],['Reflex','Narrows when startled']],
  note:'Each blade pivots on a pin in the housing ring. Closing them together narrows the pupil.'});
irisP.anchor.set(0.25,0.25,-0.04);
var irisMv=mover(irisP,{home:0.82,away:1.72,rank:0.38});
var blades=[];
(function(){
  mesh(irisP,ringGeo(0.78,0.60,0.06),'brushed',irisMv.g);
  var sh=new THREE.Shape(); sh.absellipse(0.26,0.05,0.26,0.11,0,Math.PI*2,false,0);
  var bg=new THREE.ExtrudeGeometry(sh,{depth:0.012,bevelEnabled:false,curveSegments:20});
  var pinG=new THREE.CylinderGeometry(0.022,0.022,0.09,10); pinG.rotateX(Math.PI/2);
  var pins=new THREE.InstancedMesh(pinG,M(irisP,'steel'),9), d=new THREE.Object3D(); pins.userData.part=irisP;
  for(var i=0;i<9;i++){
    var b=new THREE.Mesh(bg,M(irisP,'blade')); b.userData.a=i*Math.PI*2/9; b.userData.part=irisP;
    b.receiveShadow=true; irisMv.g.add(b); blades.push(b);
    d.position.set(Math.cos(b.userData.a)*0.62,Math.sin(b.userData.a)*0.62,-0.01); d.updateMatrix(); pins.setMatrixAt(i,d.matrix);
  }
  irisMv.g.add(pins);
})();

var lensP=Part('lens','Lens and barrel',{
  specs:[['Element','Biconvex, multi-coated'],['Barrel','Black anodised, 1.0 unit'],['Coating','Violet, teal and amber layers']],
  note:'The coated element slides along the barrel to refocus. The coloured rings are anti-reflection layers.'});
lensP.anchor.set(-0.3,0.3,0.1);
var midMv=mover(lensP,{home:0.55,away:1.2,zoomK:-0.7,rank:0.33});
mesh(lensP,lensGeo(0.62,0.13,0.1,24),'coated',midMv.g,{arg:COAT});
var barrelMv=mover(lensP,{home:0.72,away:0.3,rank:0.28});
mesh(lensP,cyl(0.78,1.0,56,true),'dark',barrelMv.g);

var driveP=Part('drive','Drive train',{
  specs:[['Ring gear','60 teeth, hardened steel'],['Pinion motors','2, with 9-tooth pinions'],['Ratio','60 : 9']],
  note:'Two small motors turn the pinions that drive the large ring gear, which rotates the lens barrel.'});
driveP.anchor.set(-0.95,-0.25,0);
var gearMv=mover(driveP,{home:0.45,away:0.7,rank:0.22});
var gearSpin=new THREE.Group(); gearMv.g.add(gearSpin);
mesh(driveP,gearGeo(1.02,0.82,60,0.1,0.05,0.82),'brushed',gearSpin);
var motorMv=mover(driveP,{home:0,away:0,rank:0.2});
var pinions=[], motorKids=[];
[-1,1].forEach(function(sg){
  var kid=new THREE.Group(); kid.userData.sx=sg; kid.position.set(sg*1.145,0,0); motorMv.g.add(kid); motorKids.push(kid);
  var pin=new THREE.Group(); pin.position.z=0.45; kid.add(pin); pinions.push(pin);
  mesh(driveP,gearGeo(0.17,0.04,9,0.1,0.04,0.04),'steel',pin);
  mesh(driveP,cyl(0.04,0.55,12),'steel',kid).position.z=0.3;
  mesh(driveP,cyl(0.13,0.42,24),'black',kid).position.z=0.12;
  mesh(driveP,cyl(0.135,0.04,24),'orange',kid).position.z=-0.1;
});

var sensorP=Part('sensor','Sensor stack',{
  specs:[['Sensor','Stacked CMOS, 48 MP'],['Heat sink','8 aluminium fins on a copper spine'],['Load limit','65 C']],
  note:'Where the image lands. The finned heat sink behind the board draws heat off the sensor.'});
sensorP.anchor.set(-0.5,-0.4,0);
var sensorMv=mover(sensorP,{home:0.26,away:-0.7,rank:0.14});
mesh(sensorP,cyl(0.74,0.04,48),'pcb',sensorMv.g);
(function(){
  mesh(sensorP,new THREE.BoxGeometry(0.46,0.46,0.04),'black',sensorMv.g).position.z=0.04;
  mesh(sensorP,new THREE.BoxGeometry(0.32,0.32,0.01),'coated',sensorMv.g,{arg:COAT}).position.z=0.066;
  mesh(sensorP,cyl(0.03,0.02,10),'orange',sensorMv.g).position.set(0.58,-0.2,0.03);
})();
var heatMv=mover(sensorP,{home:-0.5,away:-1.8,rank:0.08});
(function(){
  mesh(sensorP,cyl(0.13,0.95,16),'brushed',heatMv.g);
  var fins=new THREE.InstancedMesh(cyl(0.66,0.03,40),M(sensorP,'brushed'),8), d=new THREE.Object3D();
  for(var i=0;i<8;i++){ d.position.set(0,0,0.42-i*0.12); d.updateMatrix(); fins.setMatrixAt(i,d.matrix); }
  fins.castShadow=true; fins.userData.part=sensorP; heatMv.g.add(fins);
})();

/* ---------- tentacles: 8 chains of 10 chunky segments, all instanced ---------- */
var NT=8, NS=8, L0=0.80, LR=0.885, R0=0.38, RR=0.895, BETA=0.80;
var LEN=[], RAD=[];
for(var k0=0;k0<NS;k0++){ LEN.push(L0*Math.pow(LR,k0)); RAD.push(R0*Math.pow(RR,k0)); }

var collarP=Part('collar','Arm collars',{
  specs:[['Count','8, one per arm'],['Material','Brushed steel'],['Seal','Double O-ring, 300 m rated']],
  note:'Steel rings that lock each arm into the head and carry the first ball joint.'});
var segP=Part('seg','Arm segments',{
  specs:[['Count','64, eight per arm'],['Taper','0.60 down to 0.23 units wide'],['Shell','Satin white polymer over an alloy spine']],
  note:'Chunky hollow links. Each one is a little narrower and shorter than the one before it.'});
var jointP=Part('joint','Ball joints',{
  specs:[['Count','64'],['Travel','About 30 degrees each way'],['Drive','Twin tendon, self-centring']],
  note:'Dark ball joints between the links. Waves run from joint to joint, which is how the arms swim.'});
var ringP=Part('ring','Accent rings',{
  specs:[['Count','32, every second link'],['Colour','Signal orange'],['Use','Marks the tendon service points']],
  note:'Thin orange bands. They make it easy to see each arm bend and twist.'});
var suckP=Part('sucker','Sucker discs',{
  specs:[['Count','128, two per link'],['Material','Black elastomer'],['Grip','Vacuum cup with pressure sensing']],
  note:'Small dark cups on the inner side of each arm. They feel what the arm touches.'});

var segGeo=(function(){
  var pr=[[0,0],[0.80,0],[0.96,0.05],[1.0,0.12],[1.0,0.84],[0.94,0.95],[0.74,1],[0,1]], pts=[];
  pr.forEach(function(p){pts.push(new THREE.Vector2(p[0],p[1]));});
  var g=new THREE.LatheGeometry(pts,8).toNonIndexed(); g.computeVertexNormals(); return g;
})();
function profR(y){ return 0.93; }
var suckGeo=(function(){
  var pr=[[0,0.25],[0.42,0.25],[0.6,0.62],[0.8,0.7],[1.0,0.42],[1.0,0]], pts=[];
  pr.forEach(function(p){pts.push(new THREE.Vector2(p[0],p[1]));});
  return new THREE.LatheGeometry(pts,14);
})();
function inst(geo,part,key,count,kind){
  var m=new THREE.InstancedMesh(geo,M(part,key),count);
  m.castShadow=true; m.receiveShadow=true; m.frustumCulled=false; m.userData.part=part; m.userData.kind=kind;
  body.add(m); return m;
}
var segM=inst(segGeo,segP,'white',NT*NS,'seg');
var grooveM=inst(new THREE.CylinderGeometry(1,1,1,8,1,true),segP,'dark',NT*NS,'seg'); grooveM.castShadow=false;
var jointM=inst(new THREE.SphereGeometry(1,16,12),jointP,'dark',NT*NS,'joint');
var ringM=inst(new THREE.CylinderGeometry(1,1,1,8,1,true),ringP,'orange',NT*NS/2,'ring'); ringM.castShadow=false;
var suckM=inst(suckGeo,suckP,'black',NT*NS*2,'sucker'); suckM.castShadow=false;
var boltM=inst(new THREE.CylinderGeometry(0.5,0.5,0.5,6),segP,'steel',NT*NS*2,'seg'); boltM.castShadow=false;
var collarM=inst(new THREE.TorusGeometry(0.36,0.062,12,28),collarP,'steel',NT,'collar');

var T=[], segMid=[];
(function(){
  var order=[3,6,1,4,7,2,5,0];
  for(var i=0;i<NT;i++){
    var az=(i+0.5)*Math.PI*2/NT;
    var o=new THREE.Vector3(Math.sin(az),0,Math.cos(az)), s=new THREE.Vector3(Math.cos(az),0,-Math.sin(az));
    var radial=new THREE.Vector3(o.x*Math.sin(BETA),-Math.cos(BETA),o.z*Math.sin(BETA));
    T.push({o:o,s:s,radial:radial,ph1:Math.random()*6.28,ph2:Math.random()*6.28,ph3:Math.random()*6.28,
      fm:0.84+0.32*((i*0.618)%1),rec:0,recV:0,ripK:0,ripT:-99,ripA:0,ripS:1,order:order[i]/7,pose:0,colOff:0});
    var row=[]; for(var k=0;k<NS;k++) row.push(new THREE.Vector3()); segMid.push(row);
  }
})();
function midAnchor(i,k,lift){ return function(v){ v.copy(segMid[i][k]); if(lift) v.y+=lift; }; }
collarP.anchorFn=function(v){ v.copy(T[1].radial).multiplyScalar(R+0.03+T[1].colOff); };
segP.anchorFn=midAnchor(1,2); jointP.anchorFn=function(v){ v.copy(segMid[1][3]).addScaledVector(segMid[1][4],1).multiplyScalar(0.5); };
ringP.anchorFn=midAnchor(2,4); suckP.anchorFn=midAnchor(2,6,-0.1);

/* rest pose: pitch of each link. 0 points straight out, positive tips downward. */
function prof(u){
  if(u<0.30) return lerp(0.50,-0.62,sm(u/0.30));
  if(u<0.58) return lerp(-0.62,0.05,sm((u-0.30)/0.28));
  var x=(u-0.58)/0.42; return lerp(0.05,3.7,Math.pow(x,1.35));
}

/* ======================= WaveMate glue: state, assembly, per-frame update ======================= */
var reduce=false;
var time=0, tw=0, wavy=1, swim=1, mood=0, level=0, levelS=0, speakP=0;
var startle=0, squeeze=0, jetT=-99, flinch=0, jumpY=0, jumpV=0, lean=0, happy=0;
var S={ap:0.2,jit:0,impulse:0,zoom:0,zoomT:0};
var gaze={x:0,y:0,tx:0,ty:0}, nextGaze=1, nextIris=2, nextFocus=4;
var explT=0, expl=0;
var asm={mode:'none',t:0,dur:1,stag:1,E:7}, leave={mode:'none',t:0};
var RM={lv:new THREE.Vector3(),chute:0,reachArm:-1,reachT:0};
for(var ai=0;ai<NT;ai++) T[ai].pc={off:new THREE.Vector3()};
var bezelPc={off:new THREE.Vector3()};
/* controls from WaveMate */
var X={perch:0,stance:0,wp:0,ws:0,aim:[null,null,null,null,null,null,null,null],float:1,dance:0,lookX:0,lookY:0,vx:0,vy:0,sleep:0,eyeOnly:0};
var rigY=0, rigYT=0;
var lowest=0;

function backOut(x){ var c=1.25; x-=1; return 1+(c+1)*x*x*x+c*x*x; }
function asmVal(rank){
  if(asm.mode!=='none'){
    var x=(asm.t-rank*asm.stag)/asm.dur;
    if(x<=0) return asm.E; if(x>=1) return 0;
    return asm.E*(1-(asm.mode==='slow'?backOut(x):1-Math.pow(1-x,3)));
  }
  if(leave.mode==='disassemble'){
    var y=clamp((leave.t-(1-rank)*0.3)/0.8,0,1); return 1.7*y*y*y;
  }
  return 0;
}
function partE(rank){ return Math.max(-0.06,expl+asmVal(rank)); }
function wrapPI(a){ while(a>Math.PI) a-=2*Math.PI; while(a<-Math.PI) a+=2*Math.PI; return a; }
var _A=new THREE.Vector3();

var _m=new THREE.Matrix4(), _m2=new THREE.Matrix4(), _q=new THREE.Quaternion(), _q2=new THREE.Quaternion(), _p=new THREE.Vector3(), _s=new THREE.Vector3();
var _x=new THREE.Vector3(), _y=new THREE.Vector3(), _z=new THREE.Vector3(), _d=new THREE.Vector3(), _n=new THREE.Vector3(), _a=new THREE.Vector3();
var ZAX=new THREE.Vector3(0,0,1), YAX=new THREE.Vector3(0,1,0), ONE=new THREE.Vector3(1,1,1);

function updatePanels(){
  var i, p, spinning=asm.mode!=='none'||leave.mode==='disassemble';
  for(i=0;i<panels.length;i++){
    p=panels[i]; var av=asmVal(p.rank), e=Math.max(-0.06,expl+av);
    p.off=e*0.95+flinch*0.07; p.spin=spinning?av*0.35:0;
  }
  for(var b=0;b<bandMeshes.length;b++){
    var bm=bandMeshes[b];
    for(i=0;i<bm.n;i++){
      p=panels[bm.first+i];
      _q.setFromAxisAngle(ZAX,p.rot);
      if(p.spin){ _q2.setFromAxisAngle(p.dir,p.spin); _q.premultiply(_q2); }
      _p.copy(p.dir).multiplyScalar(p.off);
      _m.compose(_p,_q,ONE); bm.outer.setMatrixAt(i,_m);
      _s.setScalar(0.992); _m.compose(_p,_q,_s); bm.inner.setMatrixAt(i,_m);
    }
    bm.outer.instanceMatrix.needsUpdate=true; bm.inner.instanceMatrix.needsUpdate=true;
  }
  for(i=0;i<screws.length;i++){
    var s=screws[i]; p=panels[s.panel];
    _q.setFromUnitVectors(YAX,s.d);
    _p.copy(s.d).multiplyScalar(R+0.004);
    if(p.spin){ _q2.setFromAxisAngle(p.dir,p.spin); _q.premultiply(_q2); _p.applyQuaternion(_q2); }
    _p.addScaledVector(p.dir,p.off);
    _m.compose(_p,_q,ONE); screwMesh.setMatrixAt(i,_m);
  }
  screwMesh.instanceMatrix.needsUpdate=true;
}

function updateTentacles(dt){
  var amp=wavy*(reduce?0.3:1)*(mood===1?0.6:1)*(1+0.35*speakP+1.1*X.dance+1.2*happy);
  var spinning=asm.mode!=='none'||leave.mode==='disassemble';
  for(var i=0;i<NT;i++){
    var t=T[i], o=t.o, s=t.s, go=t.pc.off;
    var lead=Math.max(0,o.x*RM.lv.x+o.z*RM.lv.z), side=-(RM.lv.x*s.x+RM.lv.z*s.z);
    var reach=(RM.reachArm===i)?Math.sin(Math.PI*clamp(RM.reachT/2.6,0,1)):0;
    /* recoil spring */
    t.recV+=(-38*t.rec-7.5*t.recV)*dt; t.rec+=t.recV*dt;
    var tau=time-t.ripT;
    var rankBase=0.46+0.14*t.order;
    var eBase=partE(rankBase), pose=clamp(eBase,0,1);
    var eCol=partE(rankBase-0.03); t.colOff=eCol*0.55;
    /* collar */
    _q.setFromUnitVectors(ZAX,t.radial); _p.copy(t.radial).multiplyScalar(R+0.03+t.colOff).add(go);
    _m.compose(_p,_q,ONE); collarM.setMatrixAt(i,_m);
    var px=t.radial.x*(R+0.10+eBase*1.0)+go.x, py=t.radial.y*(R+0.10+eBase*1.0)+go.y, pz=t.radial.z*(R+0.10+eBase*1.0)+go.z;
    for(var k=0;k<NS;k++){
      var u=k/(NS-1), w=0.15+0.85*u, len=LEN[k], rad=RAD[k];
      var phi=prof(u), psi=0;
      phi+=amp*w*(0.20*Math.sin(tw*1.1*t.fm-3.2*u+t.ph1)+0.10*Math.sin(tw*0.67*t.fm-5.1*u+t.ph2));
      psi+=amp*w*(0.22*Math.sin(tw*0.83*t.fm-2.6*u+t.ph3)+0.08*Math.sin(tw*1.9-6*u+t.ph1));
      if(mood===1) phi-=0.16*Math.sin(Math.PI*u)+0.3*levelS*u*u*Math.sin(time*9+i);
      if(mood===2) phi+=0.25*u*u*Math.sin(time*0.9+i*0.8);
      phi+=t.rec*(0.55*u-0.12);
      /* swimming: arms stream out behind, the leading side folds back; resting: arms curl in */
      phi+=clamp(RM.lv.y*0.32,-0.45,0.6)*u+lead*0.28*u-RM.chute*0.55*Math.sin(Math.PI*u)*(1-0.4*u);
      psi+=clamp(side*0.3,-0.5,0.5)*u;
      if(mood===4) phi+=0.55*u+0.3*u*u;
      if(reach) phi-=reach*(0.75*Math.sin(Math.PI*u)+1.6*u*u);
      if(tau<3){ var g=Math.exp(-Math.pow(k-t.ripK-16*tau,2)/3)*Math.exp(-1.5*tau)*t.ripA; phi-=0.6*g; psi+=0.3*g*t.ripS; }
      if(squeeze>0.001){ phi=lerp(phi,1.25+0.35*u,squeeze*0.75); psi*=1-0.6*squeeze; }
      if(startle>0.001){ phi=lerp(phi,0.95+2.2*u,startle*0.7); }
      if(pose>0.001){ phi=lerp(phi,0.5,pose); psi*=1-pose; }
      if(X.perch>0.001){ var pp=lerp(0.6,1.55,Math.pow(u,0.7))+0.75*u*u*u+0.14*Math.sin(tw*1.3*t.fm-2.2*u+t.ph1)*w; phi=lerp(phi,pp,X.perch); psi=lerp(psi,psi*0.4+0.12*Math.sin(tw*0.9+t.ph2+i)*w,X.perch); }
      if(X.stance>0.001){ var sp2=lerp(1.05,0.12,Math.pow(u,0.8))+X.ws*0.38*Math.sin(X.wp+i*1.7-u*1.2)*(1-0.4*u); phi=lerp(phi,sp2,X.stance); psi=lerp(psi,X.ws*0.28*Math.cos(X.wp+i*1.7)*(1-u),X.stance); }
      var aimI=X.aim[i];
      if(aimI && aimI.w>0.001){
        _A.set(aimI.x-px,aimI.y-py,aimI.z-pz); var al=_A.length()||1; _A.multiplyScalar(1/al);
        var phT=Math.atan2(-_A.y,_A.x*o.x+_A.z*o.z), psT=Math.asin(clamp(_A.x*s.x+_A.z*s.z,-1,1));
        var wk=aimI.w*(0.22+0.78*Math.pow(u,0.6));
        phi+=wrapPI(phT-phi)*wk; psi+=wrapPI(psT-psi)*wk;
      }
      var cph=Math.cos(phi), sph=Math.sin(phi), cps=Math.cos(psi), sps=Math.sin(psi);
      _d.set(o.x*cph*cps+s.x*sps,-sph*cps,o.z*cph*cps+s.z*sps);
      _n.set(-o.x*sph,-cph,-o.z*sph); _n.addScaledVector(_d,-_n.dot(_d)).normalize();
      _x.crossVectors(_d,_n);
      var av=asmVal(rankBase+0.36*u), e=Math.max(-0.06,expl+av), ep=Math.max(e,0);
      var stretch=len*(1+0.5*ep), bl=len*0.74, start=len*0.13+len*0.25*ep;
      /* joint */
      var jr=(k===0?0.82:0.66)*rad; _s.setScalar(jr); _p.set(px,py,pz);
      _m.compose(_p,_q.identity(),_s); jointM.setMatrixAt(i*NS+k,_m);
      /* link body */
      var sx=px+_d.x*start, sy=py+_d.y*start, sz=pz+_d.z*start;
      _m.makeBasis(_x,_d,_n);
      if(spinning && av){ _m2.makeRotationAxis(_d,av*0.5); _m.premultiply(_m2); }
      _m2.copy(_m); _s.set(rad,bl,rad); _m.scale(_s); _m.setPosition(sx,sy,sz); segM.setMatrixAt(i*NS+k,_m);
      _m.copy(_m2); _s.set(rad*0.97,bl*0.06,rad*0.97); _m.scale(_s); _m.setPosition(sx+_d.x*bl*0.845,sy+_d.y*bl*0.845,sz+_d.z*bl*0.845); grooveM.setMatrixAt(i*NS+k,_m);
      segMid[i][k].set(sx+_d.x*bl*0.5,sy+_d.y*bl*0.5,sz+_d.z*bl*0.5);
      if(k%2===0){
        var ro=bl*0.30-len*0.3*ep;
        _m.copy(_m2); _s.set(rad*1.03,bl*0.10,rad*1.03); _m.scale(_s); _m.setPosition(sx+_d.x*ro,sy+_d.y*ro,sz+_d.z*ro); ringM.setMatrixAt(i*NS/2+k/2,_m);
      }
      /* bolts on the outer side */
      _a.copy(_n).negate();
      for(var q=0;q<2;q++){
        var by=0.2+0.6*q, bo=rad*0.93, br=rad*0.13;
        _m.makeBasis(_x,_a,_d); _s.set(br,br,br); _m.scale(_s);
        _m.setPosition(sx+_d.x*bl*by+_a.x*bo,sy+_d.y*bl*by+_a.y*bo,sz+_d.z*bl*by+_a.z*bo);
        boltM.setMatrixAt((i*NS+k)*2+q,_m);
      }
      /* suckers on the inner side */
      _z.copy(_d).negate();
      for(var j=0;j<2;j++){
        var yy=0.3+0.42*j, off=rad*profR(yy)*0.95+ep*rad*1.3, sr=rad*(0.27-0.03*j);
        _m.makeBasis(_x,_n,_z); _s.set(sr,sr*0.5,sr); _m.scale(_s);
        _m.setPosition(sx+_d.x*bl*yy+_n.x*off,sy+_d.y*bl*yy+_n.y*off,sz+_d.z*bl*yy+_n.z*off);
        suckM.setMatrixAt((i*NS+k)*2+j,_m);
      }
      px+=_d.x*stretch; py+=_d.y*stretch; pz+=_d.z*stretch;
    }
  }
  segM.instanceMatrix.needsUpdate=true; grooveM.instanceMatrix.needsUpdate=true; jointM.instanceMatrix.needsUpdate=true;
  boltM.instanceMatrix.needsUpdate=true; ringM.instanceMatrix.needsUpdate=true; suckM.instanceMatrix.needsUpdate=true; collarM.instanceMatrix.needsUpdate=true;
}

function update(dt,ctl){
  if(ctl){ for(var k in ctl) X[k]=ctl[k]; }
  var kf=function(r){return 1-Math.exp(-dt*r);};
  time+=dt; tw+=dt*swim*(1+0.6*X.dance);
  expl+=(explT-expl)*kf(3.0);
  if(asm.mode!=='none'){ asm.t+=dt; if(asm.t>asm.dur+asm.stag+0.05){ asm.mode='none'; } }
  if(leave.mode==='disassemble') leave.t+=dt;
  var jt=time-jetT, sqT=jt<0.3?jt/0.3:(jt<1.9?1-sm((jt-0.3)/1.6):0);
  squeeze+=(sqT-squeeze)*kf(12);
  startle*=Math.exp(-dt*1.5); if(startle<0.002) startle=0;
  flinch*=Math.exp(-dt*5); happy*=Math.exp(-dt*0.9); if(happy<0.002) happy=0;
  jumpV+=(-30*jumpY-6.5*jumpV)*dt; jumpY+=jumpV*dt;
  levelS+=(level-levelS)*kf(10);
  speakP=mood===3?Math.max(0,Math.sin(time*11)*Math.sin(time*3.1))*(0.5+0.5*Math.sin(time*1.7)):speakP*Math.exp(-dt*6);
  /* the arms trail behind the movement */
  _A.set(X.vx,X.vy,0); RM.lv.lerp(_A,kf(5));
  RM.chute+=((X.chute||0)-RM.chute)*kf(4);

  /* eye: gaze, iris, focus bursts */
  if(X.look){ gaze.tx=clamp(X.lookX*0.11,-0.1,0.1); gaze.ty=clamp(X.lookY*0.09,-0.09,0.09); }
  else if(time>nextGaze){ gaze.tx=(Math.random()*2-1)*0.095; gaze.ty=(Math.random()*2-1)*0.08; nextGaze=time+1.6+Math.random()*2.4; }
  if(time>nextIris){ S.jit=(Math.random()*2-1)*0.14; nextIris=time+2+Math.random()*3; }
  if(time>nextFocus){ S.zoomT=Math.random(); S.impulse=Math.max(S.impulse,1.0); nextFocus=time+4+Math.random()*5; }
  gaze.x+=(gaze.tx-gaze.x)*kf(6); gaze.y+=(gaze.ty-gaze.y)*kf(6);
  gazePivot.rotation.y=gaze.x; gazePivot.rotation.x=-gaze.y;
  var apT=0.2+S.jit;
  if(mood===4||X.sleep>0.5) apT=0.03+0.02*Math.sin(time*0.6); else if(mood===3) apT=0.22+0.3*speakP;
  if(happy>0.2) apT=0.1;
  if(X.dance>0.3) apT=0.35+0.3*Math.abs(Math.sin(time*4));
  if(startle>0.15) apT=0.97;
  S.ap+=(clamp(apT,0,1)-S.ap)*kf(startle>0.15?14:5);
  S.zoom+=(S.zoomT-S.zoom)*kf(2.4);
  if(X.dance>0.3) S.impulse=Math.max(S.impulse,0.7);
  S.impulse*=Math.exp(-dt*1.1);

  /* eye parts: explode + zoom slide */
  var i, zs=S.zoom*0.2, spinning=asm.mode!=='none'||leave.mode==='disassemble';
  for(i=0;i<movers.length;i++){
    var mv=movers[i], av=Math.min(asmVal(mv.rank),2.2), e=Math.max(-0.04,expl+av);
    mv.g.position.z=lerp(mv.home+mv.zoomK*zs,mv.away,e);
    mv.g.rotation.z=spinning?av*0.9:0;
  }
  var em=Math.max(0,expl+Math.min(asmVal(motorMv.rank),2.2));
  for(i=0;i<motorKids.length;i++) motorKids[i].position.x=motorKids[i].userData.sx*(1.145+em*0.75);
  bezelG.position.z=Zop+Math.max(-0.02,expl+Math.min(asmVal(0.56),3))*1.9;
  bezelG.rotation.z=spinning?asmVal(0.56)*0.5:0;
  var ls=1-sm(asmVal(0)/asm.E*1.4); if(leave.mode==='disassemble') ls=1;
  linerG.visible=ls>0.02; linerG.scale.setScalar(Math.max(0.02,ls));
  var tb=TMIN+(TMAX-TMIN)*S.ap;
  for(i=0;i<blades.length;i++){
    var b=blades[i], a=b.userData.a;
    b.position.set(Math.cos(a)*0.62,Math.sin(a)*0.62,-0.035+i*0.0042);
    b.rotation.z=a+Math.PI/2+tb;
  }
  var spd=0.6+0.4*swim+0.6*X.dance;
  var wS=(0.35+S.impulse*0.4)*spd, wF=-(0.9+S.impulse*2.2)*spd, wG=(0.22+S.impulse*0.1)*spd;
  scaleSpin.rotation.z+=wS*dt; focusSpin.rotation.z+=wF*dt; gearSpin.rotation.z+=wG*dt;
  for(i=0;i<pinions.length;i++) pinions[i].rotation.z-=wG*dt*60/9;

  /* body: float, sway, breathing */
  var fl=X.float*(1-clamp(expl,0,1));
  lean+=(0-lean)*kf(3);
  var dz=X.dance, sw=Math.sin(time*5.5)*dz;
  body.position.set(0.10*Math.sin(tw*0.31+1)*fl+0.25*sw, BODY_Y+(0.13*Math.sin(tw*0.9)+0.04*Math.sin(tw*0.37+2)+0.05*speakP)*fl+jumpY+0.18*Math.abs(Math.sin(time*5.5))*dz, 0.08*Math.sin(tw*0.23)*fl);
  body.rotation.set(0.03*Math.sin(tw*0.4+2)*fl+lean-jumpV*0.012+clamp(RM.lv.y*0.02,-0.2,0.2), 0.05*Math.sin(tw*0.19)*fl, 0.045*Math.sin(tw*0.5)*fl+clamp(-RM.lv.x*0.012,-0.35,0.35)+0.14*sw+0.12*Math.sin(time*13)*happy);
  var br=(explT?0:0.011*Math.sin(time*(X.sleep>0.5?1.2:2.0)));
  headG.scale.set(1+br,1+br*1.3,1+br);

  if(X._wave){ var wv=X._wave; wv.t+=dt; var wl=wv.t<2.2?Math.sin(Math.PI*wv.t/2.2):0;
    if(wv.t>=2.2){ X.aim[wv.arm]=null; X._wave=null; }
    else{ var ao=T[wv.arm].o; X.aim[wv.arm]={x:ao.x*2.6+Math.sin(time*7)*0.7,y:3.4+Math.sin(time*5)*0.3,z:ao.z*2.6,w:wl}; } }
  updatePanels();
  updateTentacles(dt);

  /* where is the ground? */
  var low=1e9;
  if(X.stance>0.5){
    for(i=0;i<NT;i++) for(var kk=0;kk<NS;kk++){ var yy=segMid[i][kk].y-RAD[kk]*0.9; if(yy<low) low=yy; }
    rigYT=-(low+body.position.y);
  } else if(X.perch>0.5){ rigYT=-(body.position.y-0.72*R); }
  else rigYT=-BODY_Y;
  rigY+=(rigYT-rigY)*kf(7);
  rig.position.y=rigY;
}
function bodyLocal(wx,wy,wz,out){ out.set(wx,wy,wz); body.updateWorldMatrix(true,false); body.worldToLocal(out); return out; }

var api={
  id:'octopus', kind:'float', root:root, unit:34,
  /* nominal clickable area, in model units around the anchor (y up) */
  hit:function(mode){ return mode==='perch'?{cx:0,cy:1.6,rx:2.3,ry:2.3}:(mode==='floor'?{cx:0,cy:1.7,rx:3.0,ry:2.4}:{cx:0,cy:0.3,rx:2.7,ry:3.6}); },
  headWorldRadius:R,
  update:update,
  X:X,
  body:body, rig:rig, T:T, NT:NT, R:R,
  bodyLocal:bodyLocal,
  setMood:function(n){ mood=n|0; if(mood===2) S.impulse=1.2; },
  poke:function(target){
    if(target==='head'){ startle=1; flinch=1; jumpV+=3.2; S.impulse=1.2; return; }
    var i=(typeof target==='number')?((target|0)%NT+NT)%NT:Math.floor(Math.random()*NT), k=2+Math.floor(Math.random()*4), t=T[i];
    t.ripK=k; t.ripT=time; t.ripA=1; t.ripS=Math.random()<0.5?-1:1; t.recV+=5.5; T[(i+1)%NT].recV+=1.8; T[(i+NT-1)%NT].recV+=1.8;
    S.jit=0.25; gaze.tx=clamp(t.o.x*0.12,-0.1,0.1); gaze.ty=-0.08;
  },
  startle:function(p){ startle=p==null?1:p; flinch=1; jumpV+=2.4; S.impulse=1.2; },
  happy:function(p){ happy=Math.max(happy,p==null?1:p); S.jit=-0.08; },
  jet:function(){ jetT=time; jumpV+=1.9; },
  flinch:function(){ flinch=1; jumpV+=1.6; },
  wave:function(){ var i=(Math.random()*NT)|0; X._wave={arm:i,t:0}; },
  summon:function(mode){
    mode=mode||'slow'; leave.mode='none'; leave.t=0; if(explT) explT=0;
    if(mode==='none'){ asm.mode='none'; return; }
    asm.mode=mode; asm.t=0; asm.dur=mode==='slow'?1.5:0.5; asm.stag=mode==='slow'?1.5:0.45; asm.E=7;
  },
  takeApart:function(on){ explT=on?1:0; },
  isApart:function(){ return !!explT; },
  assembling:function(){ return asm.mode!=='none'; },
  /* tip of arm i in model units relative to the root (for taps / fights) */
  armTip:function(i,out){ var k=NS-1; out.copy(segMid[i][k]); body.localToWorld(out); root.worldToLocal(out); return out; },
  armBase:function(i,out){ out.copy(T[i].radial).multiplyScalar(R+0.1); body.localToWorld(out); root.worldToLocal(out); return out; },
  shell:function(name){ var c=name==='graphite'?SHELL.graphite:SHELL.white; shellTinted.forEach(function(m){ m.color.setHex(c); }); },
  dispose:function(){ root.traverse(function(o){ if(o.geometry) o.geometry.dispose(); }); }
};
return api;
}
