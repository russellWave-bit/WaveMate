import * as THREE from 'three';

/* A little keyboard used when WaveMate imitates your typing. Built around the origin, keys facing +y. */
export function makeKeyboard(){
  const g=new THREE.Group();
  const base=new THREE.Mesh(new THREE.BoxGeometry(3.2,0.14,1.25),new THREE.MeshStandardMaterial({color:0x1b2025,roughness:0.55,metalness:0.4}));
  g.add(base);
  const rows=[13,13,12,11], keyGeo=new THREE.BoxGeometry(0.18,0.1,0.18);
  const keys=new THREE.InstancedMesh(keyGeo,new THREE.MeshStandardMaterial({color:0xdfe3e6,roughness:0.5}),rows.reduce((a,b)=>a+b,0));
  const d=new THREE.Object3D(); let n=0;
  rows.forEach((c,r)=>{ for(let i=0;i<c;i++){ d.position.set((i-(c-1)/2)*0.225,0.11,(r-1.5)*0.24); d.updateMatrix(); keys.setMatrixAt(n++,d.matrix);} });
  g.add(keys);
  const bar=new THREE.Mesh(new THREE.BoxGeometry(1.1,0.1,0.18),new THREE.MeshStandardMaterial({color:0xe4572e,roughness:0.45}));
  bar.position.set(0,0.11,0.96*0.5+0.02); g.add(bar);
  g.userData.keys=keys;
  return g;
}

/* soft round shadow that sits under a character */
export function makeBlob(){
  const c=document.createElement('canvas'); c.width=c.height=128;
  const x=c.getContext('2d'); const gr=x.createRadialGradient(64,64,4,64,64,62);
  gr.addColorStop(0,'rgba(0,0,0,0.55)'); gr.addColorStop(0.55,'rgba(0,0,0,0.25)'); gr.addColorStop(1,'rgba(0,0,0,0)');
  x.fillStyle=gr; x.fillRect(0,0,128,128);
  const t=new THREE.CanvasTexture(c);
  const m=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({map:t,transparent:true,depthWrite:false}));
  m.renderOrder=-1;
  return m;
}

export const clamp=(x,a,b)=>x<a?a:(x>b?b:x);
export const lerp=(a,b,t)=>a+(b-a)*t;
export const sm=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
export const kf=(dt,r)=>1-Math.exp(-dt*r);
