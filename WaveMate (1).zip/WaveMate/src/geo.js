import * as THREE from 'three';
/* ---------- geometry helpers (PE-1) ---------- */
export function gearGeo(Ro,Ri,teeth,depth,toothH,bore){
  var sh=new THREE.Shape(), step=Math.PI*2/teeth, rr=Ro-toothH, i, a;
  function P(ang,r){return [Math.cos(ang)*r,Math.sin(ang)*r]}
  for(i=0;i<teeth;i++){
    a=i*step;
    var p=[P(a,rr),P(a+step*0.12,Ro),P(a+step*0.38,Ro),P(a+step*0.5,rr)];
    for(var k=0;k<4;k++){ if(i===0&&k===0) sh.moveTo(p[k][0],p[k][1]); else sh.lineTo(p[k][0],p[k][1]); }
  }
  sh.closePath();
  var h=new THREE.Path(); h.absarc(0,0,bore||Ri,0,Math.PI*2,true); sh.holes.push(h);
  var g=new THREE.ExtrudeGeometry(sh,{depth:depth,bevelEnabled:true,bevelThickness:depth*0.12,bevelSize:0.004,bevelSegments:1,curveSegments:12});
  g.translate(0,0,-depth/2); return g;
}
export function ringGeo(Ro,Ri,depth){
  var sh=new THREE.Shape(); sh.absarc(0,0,Ro,0,Math.PI*2,false);
  var h=new THREE.Path(); h.absarc(0,0,Ri,0,Math.PI*2,true); sh.holes.push(h);
  var g=new THREE.ExtrudeGeometry(sh,{depth:depth,bevelEnabled:true,bevelThickness:depth*0.15,bevelSize:0.006,bevelSegments:2,curveSegments:64});
  g.translate(0,0,-depth/2); return g;
}
export function lensGeo(R,zf,zb,steps){
  var pts=[],k;
  for(k=0;k<=steps;k++){var u=k/steps; pts.push(new THREE.Vector2(R*u,zf*(1-u*u)));}
  for(k=steps;k>=0;k--){var u2=k/steps; pts.push(new THREE.Vector2(R*u2,-zb*(1-u2*u2)));}
  var g=new THREE.LatheGeometry(pts,56); g.rotateX(Math.PI/2); return g;
}
export function cyl(r,len,seg,open){var g=new THREE.CylinderGeometry(r,r,len,seg||40,1,!!open); g.rotateX(Math.PI/2); return g;}
export function lerp(a,b,t){return a+(b-a)*t;}
export function clamp(x,a,b){return x<a?a:(x>b?b:x);}
export function sm(x){x=clamp(x,0,1);return x*x*(3-2*x);}
