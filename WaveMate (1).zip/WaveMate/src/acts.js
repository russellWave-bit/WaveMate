/* Tricks: what each kind of character likes to do. The brain (app.js) starts them, the characters draw them.
   kind: octopus | eye | robot | fox | blocky | human (VRM people).  dur = seconds range, w = how often (weight).
   sit: the character sits down for it.  move: the trick moves it along the edge. */
const H=(id,icon,name,dur,w,extra)=>Object.assign({id,icon,name,dur,w:w||1},extra||{});

export const HUMAN=[
  H('stretch','🙆','Stretch',[3.5,4.5],1.2),
  H('bow','🙇','Take a bow',[2.4,3],0.8),
  H('peace','✌️','Peace sign',[2.6,3.4],1),
  H('spin','💫','Twirl',[2.2,2.8],1),
  H('cheer','🙌','Cheer',[2.6,3.6],1),
  H('think','🤔','Think',[3.4,5],0.8),
  H('yawn','🥱','Yawn',[3,4],0.8),
  H('salute','🫡','Salute',[2.2,3],0.7),
  H('karate','🥋','Karate chops',[3,4.5],0.8),
  H('flex','💪','Show off',[2.6,3.6],0.8),
  H('clap','👏','Clap',[2.6,3.6],0.9),
  H('facepalm','🤦','Facepalm',[2.2,3],0.5),
  H('jacks','🤸','Jumping jacks',[3,4.5],0.8),
  H('sneak','🥷','Sneak around',[4,6],0.7,{move:true})
];
export const BLOCKY=HUMAN.concat([
  H('mine','⛏️','Mine something',[4,6],1.6),
  H('build','🧱','Build a little tower',[5,7],1.2),
  H('eat','🍎','Eat an apple',[3.4,4.5],1)
]);
export const ROBOT=[
  H('nod','👍','Nod yes',[1.8,2.4],0.8),
  H('shake','🙅','Shake head no',[1.8,2.4],0.8),
  H('thumbsup','👍','Thumbs up',[2.4,3],1),
  H('punchair','🥊','Punch the air',[2.4,3.2],0.9),
  H('dance','🕺','Robot dance',[4,6],1.2),
  H('glitch','⚡','Glitch out',[2.2,3],1,{fx:true}),
  H('scan','📡','Scan the room',[3.6,5],1.2),
  H('headspin','🌀','Spin its head',[2.2,3],0.9),
  H('powerdown','🪫','Power down and reboot',[5,7],0.8,{sit:true}),
  H('salute','🫡','Salute',[2.2,3],0.7),
  H('playdead','💀','Play dead',[4.5,6],0.8),
  H('zoomies','💨','Zoom along',[2.4,3.4],0.8,{move:true})
];
export const FOX=[
  H('zoomies','💨','Zoomies',[2.6,3.6],1.3,{move:true}),
  H('pounce','🐾','Pounce on the cursor',[3,4.5],1.2,{needsCursor:true}),
  H('chasetail','🌀','Chase its tail',[3,4.2],1.1,{spinRate:5.8}),
  H('curl','😴','Curl up',[5,8],0.9,{sit:true}),
  H('sniff','👃','Sniff the ground',[3.6,5],1.1,{move:true}),
  H('howl','🌙','Howl',[2.8,3.6],0.8,{sit:true}),
  H('dig','🕳️','Dig',[3.2,4.4],0.9),
  H('playbow','🙇','Play bow',[2.2,3],0.9),
  H('beg','🥺','Beg for a snack',[3,4.2],0.9,{sit:true})
];
export const EYE=[
  H('roll','🌀','Barrel roll',[2.6,3.2],1),
  H('scan','🔍','Scan around',[3.6,5],1.2),
  H('flash','📸','Take a photo',[2,2.6],0.9,{fx:true}),
  H('zoom','💨','Zoom across the edge',[2.2,3],0.9,{move:true}),
  H('bounce','⛹️','Bounce',[2.8,3.6],1),
  H('shy','🙈','Act shy',[3,4],0.7),
  H('party','🎉','Disco spin',[3.4,4.6],1),
  H('blinkblink','😑','Blink blink',[2.6,3.4],0.8),
  H('dizzy','😵‍💫','Get dizzy',[2.4,3.2],0.7)
];
export const OCTOPUS=[
  H('waveall','👋','Wave every arm',[3,4],1.3),
  H('reach','🫳','Stretch out and reach',[3.2,4.4],1,{reach:true}),
  H('taptap','🥁','Drum on the edge',[3.2,4.4],1),
  H('juggle','🤹','Juggle',[5,7],1.1,{fx:true}),
  H('bubbles','🫧','Blow bubbles',[4,5.5],1,{fx:true}),
  H('ink','🌫️','Ink puff and jet away',[1.4,1.8],0.9,{fx:true}),
  H('jetlap','🚀','Jet along the edge',[2.4,3.2],0.9,{move:true}),
  H('tinker','🔧','Tinker (takes itself apart)',[10,12],0.9),
  H('shellswap','🎨','Change shell colour',[2.6,3.2],0.7)
];

export const GENERIC=[
  H('spin','💫','Twirl',[2.2,2.8],1,{spinRate:5.5}),
  H('dance','🕺','Dance',[4,5.5],1),
  H('wave','👋','Wave',[2.4,3],1)
];
export function actsFor(c){
  const id=c&&c.id;
  if(id==='octopus') return OCTOPUS;
  if(id==='eye') return EYE;
  if(id==='robot') return ROBOT;
  if(id==='fox') return FOX;
  if(id==='blocky') return BLOCKY;
  return c&&c.isHuman?HUMAN:GENERIC;
}
export function pickAct(list,avoid){
  const l=list.filter(a=>a.id!==avoid); let tot=0; l.forEach(a=>{ tot+=a.w; }); let r=Math.random()*tot;
  for(const a of l){ r-=a.w; if(r<=0) return a; } return l[0];
}

/* Octopus arms: where arm i reaches for during a trick, in body units (x right, y up, z toward you), or null.
   Arms: 0,1,2 on the right, 3,4 behind/bottom, 5,6,7 on the left (the same numbering as typing). */
export function octAim(id,i,t,data){
  const s=Math.sin;
  switch(id){
    case 'waveall': { const a=(i/8)*Math.PI*2; return {x:Math.cos(a)*1.7+s(t*6+i)*0.9,y:3.4+0.9*s(t*7+i*0.8),z:0.8}; }
    case 'reach': { const L=data&&data.pts&&data.pts[i]; return L||null; }
    case 'taptap': { const m={7:-0.55,0:0.55,6:-1.35,1:1.35}; if(m[i]==null) return null; const ph=(i%2?0:Math.PI), k=Math.max(0,s(t*8+ph)); return {x:m[i],y:-2.5-0.55*k,z:2.1}; }
    case 'juggle': { if(i!==1&&i!==6) return null; const ph=i===1?0:Math.PI; return {x:(i===1?1:-1)*(1.2+0.5*s(t*4+ph)),y:3.1+1.0*s(t*5+ph),z:1.1}; }
    case 'bubbles': { if(i!==1&&i!==6) return null; return {x:(i===1?0.35:-0.35),y:3.0+0.3*s(t*9),z:1.9}; }
    default: return null;
  }
}
