import * as THREE from 'three';
import {makePose,stepPose} from './humanoid.js';
import {makeKeyboard,clamp,lerp,kf} from './props.js';

/* ---------- the standard 64x64 skin layout ---------- */
function faces(u,v,w,h,d){
  return {top:[u+d,v,w,d],bottom:[u+d+w,v,w,d],right:[u,v+d,d,h],front:[u+d,v+d,w,h],left:[u+d+w,v+d,d,h],back:[u+2*d+w,v+d,w,h]};
}
const PARTS={
  head:  {u:0, v:0, w:8,h:8, d:8, ou:32,ov:0},
  body:  {u:16,v:16,w:8,h:12,d:4, ou:16,ov:32},
  rArm:  {u:40,v:16,w:4,h:12,d:4, ou:40,ov:32},
  lArm:  {u:32,v:48,w:4,h:12,d:4, ou:48,ov:48},
  rLeg:  {u:0, v:16,w:4,h:12,d:4, ou:0, ov:32},
  lLeg:  {u:16,v:48,w:4,h:12,d:4, ou:0, ov:48}
};

/* an original default skin: orange hoodie, navy trousers, teal hair. Nothing from the real game. */
export function defaultSkinCanvas(){
  const c=document.createElement('canvas'); c.width=c.height=64; const x=c.getContext('2d');
  const fill=(r,col)=>{ x.fillStyle=col; x.fillRect(r[0],r[1],r[2],r[3]); };
  const SK='#e9bd96', SK2='#d9a77f', HAIR='#2a7a76', HAIR2='#1f5f5c', HOOD='#e4572e', HOOD2='#c9461f', PANT='#2b2f55', PANT2='#20244a', SHOE='#e7e9ea', WHITE='#f3f4f4', DARK='#1a1d22';
  const H=faces(0,0,8,8,8);
  for(const k in H) fill(H[k],SK);
  fill(H.top,HAIR); fill(H.back,HAIR); fill([H.right[0],H.right[1],8,3],HAIR); fill([H.left[0],H.left[1],8,3],HAIR); fill([H.right[0]+4,H.right[1]+3,4,2],HAIR2); fill([H.left[0],H.left[1]+3,4,2],HAIR2);
  fill([H.front[0],H.front[1],8,2],HAIR); fill([H.front[0],H.front[1]+2,2,1],HAIR); fill([H.front[0]+5,H.front[1]+2,3,1],HAIR);
  fill([H.front[0]+1,H.front[1]+4,2,1],WHITE); fill([H.front[0]+5,H.front[1]+4,2,1],WHITE);
  fill([H.front[0]+2,H.front[1]+4,1,1],DARK); fill([H.front[0]+5,H.front[1]+4,1,1],DARK);
  fill([H.front[0]+3,H.front[1]+6,2,1],SK2);
  const B=faces(16,16,8,12,4); for(const k in B) fill(B[k],HOOD);
  fill([B.front[0]+2,B.front[1]+8,4,3],HOOD2); fill([B.front[0]+3,B.front[1],1,4],WHITE); fill([B.front[0]+4,B.front[1],1,4],WHITE);
  fill([B.top[0],B.top[1],8,4],HOOD2);
  const arm=(p)=>{ const A=faces(p.u,p.v,4,12,4); for(const k in A) fill(A[k],HOOD); ['right','front','left','back'].forEach(k=>fill([A[k][0],A[k][1]+8,A[k][2],4],SK)); fill(A.bottom,SK); fill(A.top,HOOD2); };
  arm(PARTS.rArm); arm(PARTS.lArm);
  const leg=(p)=>{ const L=faces(p.u,p.v,4,12,4); for(const k in L) fill(L[k],PANT); ['right','front','left','back'].forEach(k=>fill([L[k][0],L[k][1]+9,L[k][2],3],SHOE)); fill(L.bottom,SHOE); fill(L.top,PANT2); };
  leg(PARTS.rLeg); leg(PARTS.lLeg);
  return c;
}

/* load someone's skin png (64x64 or the old 64x32), returns {canvas, slim} */
export async function skinFromBytes(buf){
  const bmp=await createImageBitmap(new Blob([buf]));
  const c=document.createElement('canvas'); c.width=c.height=64; const x=c.getContext('2d'); x.imageSmoothingEnabled=false;
  x.drawImage(bmp,0,0);
  if(bmp.height===32){
    const flip=(sx,sy,w,h,dx,dy)=>{ x.save(); x.translate(dx+w,dy); x.scale(-1,1); x.drawImage(c,sx,sy,w,h,0,0,w,h); x.restore(); };
    const mirrorLimb=(su,sv,du,dv,w,d,h)=>{
      const s=faces(su,sv,w,h,d), t=faces(du,dv,w,h,d);
      flip(...s.top,t.top[0],t.top[1]); flip(...s.bottom,t.bottom[0],t.bottom[1]); flip(...s.front,t.front[0],t.front[1]); flip(...s.back,t.back[0],t.back[1]);
      flip(...s.right,t.left[0],t.left[1]); flip(...s.left,t.right[0],t.right[1]);
    };
    mirrorLimb(0,16,16,48,4,4,12); mirrorLimb(40,16,32,48,4,4,12);
  }
  const d=x.getImageData(55,20,1,1).data; const slim=d[3]===0;
  return {canvas:c,slim};
}

function makeUV(geo,rects,y0,y1){
  const uv=geo.attributes.uv, order=['left','right','top','bottom','front','back'];
  order.forEach((nm,fi)=>{
    let [x,y,w,h]=rects[nm];
    if(nm!=='top'&&nm!=='bottom'){ const hh=h; y=y+hh*y0; h=hh*(y1-y0); }
    const u0=x/64,u1=(x+w)/64,v1=1-y/64,v0=1-(y+h)/64, i=fi*4;
    uv.setXY(i,u0,v1); uv.setXY(i+1,u1,v1); uv.setXY(i+2,u0,v0); uv.setXY(i+3,u1,v0);
  });
  uv.needsUpdate=true;
}

export function createBlocky(){
  const root=new THREE.Group(), rig=new THREE.Group(); root.add(rig);
  let tex=new THREE.CanvasTexture(defaultSkinCanvas()); tex.magFilter=THREE.NearestFilter; tex.minFilter=THREE.NearestFilter; tex.encoding=THREE.sRGBEncoding;
  const mat=new THREE.MeshStandardMaterial({map:tex,roughness:0.9,metalness:0,alphaTest:0.5,side:THREE.DoubleSide});
  const state={slim:false};
  const J={}; /* joints */
  const parts=[];
  function box(w,h,d,name,y0,y1,infl,over,cy){
    const P=PARTS[name], r=faces(over?P.ou:P.u,over?P.ov:P.v,P.w,P.h,P.d);
    const g=new THREE.BoxGeometry(w+infl*2,h+infl*2,d+infl*2); makeUV(g,r,y0,y1);
    const m=new THREE.Mesh(g,mat); m.position.y=cy; return m;
  }
  function build(){
    while(rig.children.length) rig.remove(rig.children[0]);
    parts.length=0;
    const armW=state.slim?3:4;
    const spine=new THREE.Group(); spine.position.y=12; rig.add(spine); J.spine=spine;
    for(const o of [0,1]){ const inf=o?0.28:0; const m=box(8,12,4,'body',0,1,inf,!!o,6); spine.add(m); }
    const head=new THREE.Group(); head.position.y=12; spine.add(head); J.head=head;
    for(const o of [0,1]){ head.add(box(8,8,8,'head',0,1,o?0.5:0,!!o,4)); }
    const limb=(nm,px,py,pw,ph,isArm,parent)=>{
      const top=new THREE.Group(); top.position.set(px,py,0); parent.add(top);
      const fore=new THREE.Group(); fore.position.y=-6; top.add(fore);
      for(const o of [0,1]){ const inf=o?0.25:0;
        top.add(box(pw,6,4,nm,0,0.5,inf,!!o,-3)); fore.add(box(pw,6,4,nm,0.5,1,inf,!!o,-3)); }
      return {p:top,f:fore};
    };
    J.aL=limb('lArm',6+(state.slim?-0.5:0)+armW/2-2,10,armW,12,true,spine); J.aL.p.position.x=4+armW/2; J.aL.p.position.y=10;
    J.aR=limb('rArm',0,10,armW,12,true,spine); J.aR.p.position.x=-(4+armW/2); J.aR.p.position.y=10;
    J.lL=limb('lLeg',2,0,4,12,false,rig); J.lL.p.position.set(2,12,0);
    J.lR=limb('rLeg',-2,0,4,12,false,rig); J.lR.p.position.set(-2,12,0);
    spine.position.y=12;
  }
  build();
  const kb=makeKeyboard(); kb.scale.setScalar(4.6); kb.visible=false; rig.add(kb);
  const pose=makePose(); let kbT=0, dropY=0;
  /* props for the tricks: a pickaxe and an apple in the hand, little blocks stacked beside it */
  const stuff=new THREE.Group(); rig.add(stuff);
  const hand=new THREE.Group(); const flat=c=>new THREE.MeshStandardMaterial({color:c,roughness:0.9});
  const cube=(w,h,d,c,x,y,z)=>{ const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),flat(c)); m.position.set(x,y,z); return m; };
  const pick=new THREE.Group(); pick.add(cube(1.2,1.2,11,0x7a5230,0,0,3),cube(9,1.6,1.6,0x8d949a,0,0,8.4),cube(1.8,1.8,1.8,0x8d949a,4.6,0,7.6),cube(1.8,1.8,1.8,0x8d949a,-4.6,0,7.6)); pick.position.set(0,-5.5,0.5); pick.visible=false;
  const apple=new THREE.Group(); apple.add(cube(3.4,3.4,3.4,0xd3322b,0,0,0),cube(0.7,1.2,0.7,0x5a3b22,0,2.2,0),cube(1.6,0.6,1.0,0x3f9c3a,0.9,2.4,0)); apple.position.set(0,-6.2,2.2); apple.visible=false;
  const blocks=[]; const BC=[0x8b8f94,0x7b5a3a,0x4f9d3b,0xb88f55,0x8b8f94,0x4a7fcb];
  for(let i=0;i<6;i++){ const b=cube(4.2,4.2,4.2,BC[i],0,0,0); b.visible=false; stuff.add(b); blocks.push(b); }
  let propsT=0;

  function setSkin(canvas,slim){
    if(tex) tex.dispose();
    tex=new THREE.CanvasTexture(canvas); tex.magFilter=THREE.NearestFilter; tex.minFilter=THREE.NearestFilter; tex.encoding=THREE.sRGBEncoding; mat.map=tex; mat.needsUpdate=true;
    if(!!slim!==state.slim){ state.slim=!!slim; build(); }
  }
  const api={
    id:'blocky',kind:'walk',isHuman:true,root,unit:7,
    hit:(mode)=>mode==='perch'?{cx:0,cy:5,rx:11,ry:17}:{cx:0,cy:16,rx:11,ry:18},
    setSkin, X:{},
    update(dt,S){
      const p=stepPose(pose,S,dt);
      root.rotation.y=p.turn;
      dropY+=((-12*p.drop)-dropY)*kf(dt,9);
      rig.position.y=dropY+(p.bob+p.hop)*32;
      J.spine.rotation.set(p.pitch,0,p.roll); J.head.rotation.set(p.headX,p.headY,p.headZ);
      J.aL.p.rotation.set(p.aLf,0,p.aLa+Math.PI/2); J.aR.p.rotation.set(p.aRf,0,p.aRa+Math.PI/2);
      J.aL.f.rotation.set(-p.aLe,0,0); J.aR.f.rotation.set(-p.aRe,0,0);
      J.lL.p.rotation.x=p.lLx; J.lR.p.rotation.x=p.lRx; J.lL.f.rotation.x=p.lLk; J.lR.f.rotation.x=p.lRk;
      /* tricks: what is in the hand, how many blocks stand beside us */
      const A=S.mode==='act'?S.act:null;
      if(!hand.parent) J.aR.f.add(hand);
      if(pick.parent!==hand){ hand.add(pick,apple); }
      pick.visible=A==='mine'; apple.visible=A==='eat';
      if(A==='eat'){ const k=1-0.22*Math.floor((S.actT||0)/0.85); apple.scale.setScalar(Math.max(0.35,k)); }
      const nb=A==='build'?Math.min(6,Math.floor((S.actT||0)/0.8)):0;
      propsT+=((A==='build'?1:0)-propsT)*kf(dt,6);
      const order=[[11,2.1],[11,6.4],[11,10.7],[15.4,2.1],[15.4,6.4],[19.8,2.1]];
      blocks.forEach((b,i)=>{ b.visible=A==='build'&&i<nb; b.position.set(order[i][0],order[i][1],0); });
      /* keyboard prop for the typing imitation */
      const want=S.mode==='type'?1:0; kbT+=(want-kbT)*kf(dt,10); kb.visible=kbT>0.02; kb.scale.setScalar(4.6*kbT);
      kb.position.set(0,14.5,7.5); kb.rotation.x=0.15;
    },
    poke(){}, startle(){}, happy(){}, jet(){}, flinch(){}, wave(){}, tap(){},
    setMood(){}, summon(){}, takeApart(){}, isApart:()=>false, assembling:()=>false, shell(){},
    dispose(){ root.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  };
  return api;
}
