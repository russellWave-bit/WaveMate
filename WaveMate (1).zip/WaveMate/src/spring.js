import * as THREE from 'three';

/* Light spring-bone physics for VRM hair, skirts, ribbons and tails.
   It follows the VRM spring bone data in the file (stiffness, gravity, drag, spheres to stay out of).
   The body is simulated in the character's own space, and we feed the walking/dragging motion in as a nudge,
   so the hair lags and swings when the character moves. */
export async function createSprings(gltf,model,rig,k){
  const json=gltf.parser.json, ext=json.extensions||{};
  const node=async i=>{ try{ return await gltf.parser.getDependency('node',i); }catch(e){ return null; } };
  const joints=[]; /* simulated joints, parents before children */
  const colGroups=[]; /* [{ spheres:[{node,off:Vector3,r}] }] */
  const tmp=new THREE.Vector3(), tq=new THREE.Quaternion();

  async function makeSpheres(list){
    const out=[]; for(const c of list){ const n=await node(c.node); if(n) out.push({node:n,off:new THREE.Vector3().fromArray(c.offset||[0,0,0]),r:c.radius||0.05}); } return out;
  }
  const v0=ext.VRM&&ext.VRM.secondaryAnimation, v1=ext.VRMC_springBone;
  const groupsOf=[];
  if(v0){
    for(const cg of (v0.colliderGroups||[])){
      groupsOf.push({spheres:await makeSpheres((cg.colliders||[]).map(c=>({node:cg.node,offset:[c.offset.x,c.offset.y,c.offset.z],radius:c.radius})))});
    }
  } else if(v1){
    const cols=v1.colliders||[];
    for(const cg of (v1.colliderGroups||[])){
      const list=[];
      for(const ci of (cg.colliders||[])){ const c=cols[ci]; if(!c) continue; const sh=c.shape||{};
        if(sh.sphere) list.push({node:c.node,offset:sh.sphere.offset,radius:sh.sphere.radius});
        else if(sh.capsule){ list.push({node:c.node,offset:sh.capsule.offset,radius:sh.capsule.radius}); list.push({node:c.node,offset:sh.capsule.tail,radius:sh.capsule.radius}); } }
      groupsOf.push({spheres:await makeSpheres(list)});
    }
  }

  function addJoint(n,tailNode,p,cgs,lastExtra){
    if(!n||!n.parent) return;
    let tl;
    if(tailNode) tl=tailNode.position.clone();
    else { tl=n.position.clone(); if(tl.lengthSq()<1e-10) tl.set(0,-1,0); tl.normalize().multiplyScalar(0.07); }
    const len=tl.length()*k; if(len<1e-5) return;
    joints.push({n,tl:tl.clone().normalize(),restQ:n.quaternion.clone(),len,p,cgs,cur:null,prev:null,ready:false});
  }

  if(v0){
    for(const g of (v0.boneGroups||[])){
      const p={stiff:g.stiffiness!=null?g.stiffiness:(g.stiffness!=null?g.stiffness:1),grav:g.gravityPower||0,gdir:new THREE.Vector3(g.gravityDir?g.gravityDir.x:0,g.gravityDir?g.gravityDir.y:-1,g.gravityDir?g.gravityDir.z:0).normalize(),drag:g.dragForce!=null?g.dragForce:0.4,hit:(g.hitRadius||0.02)*k};
      const cgs=(g.colliderGroups||[]).map(i=>groupsOf[i]).filter(Boolean);
      for(const bi of (g.bones||[])){
        const root=await node(bi); if(!root) continue;
        const walk=(n)=>{ addJoint(n,n.children.length?n.children[0]:null,p,cgs); n.children.forEach(walk); };
        walk(root);
      }
    }
  } else if(v1){
    for(const sp of (v1.springs||[])){
      const js=sp.joints||[]; const cgs=(sp.colliderGroups||[]).map(i=>groupsOf[i]).filter(Boolean);
      const nodes=[]; for(const j of js) nodes.push(await node(j.node));
      for(let i=0;i<js.length;i++){
        const j=js[i], gd=j.gravityDir||[0,-1,0];
        const p={stiff:j.stiffness!=null?j.stiffness:1,grav:j.gravityPower||0,gdir:new THREE.Vector3(gd[0],gd[1],gd[2]).normalize(),drag:j.dragForce!=null?j.dragForce:0.5,hit:(j.hitRadius||0.02)*k};
        if(i<js.length-1) addJoint(nodes[i],nodes[i+1],p,cgs);
      }
    }
  }
  if(!joints.length) return null;

  const rigInv=new THREE.Quaternion(), head=new THREE.Vector3(), nxt=new THREE.Vector3(), pq=new THREE.Quaternion(), pqi=new THREE.Quaternion(), dir=new THREE.Vector3(), rd=new THREE.Vector3(), cw=new THREE.Vector3(), dq=new THREE.Quaternion();
  const toRig=(wp,out)=>rig.worldToLocal(out.copy(wp));

  function init(){
    rig.updateMatrixWorld(true);
    for(const j of joints){
      const tail=j.tl.clone().multiplyScalar(j.len/k); /* node-local tail position */
      j.n.localToWorld(tmp.copy(tail)); j.cur=toRig(tmp,new THREE.Vector3()); j.prev=j.cur.clone(); j.ready=true;
    }
  }

  const shift=new THREE.Vector3();
  return {
    count:joints.length,
    /* dt in seconds; mx,my = how far the whole character moved this frame, in its own units (+x right, +y up) */
    update(dt,mx,my){
      if(!joints.length) return;
      rig.updateMatrixWorld(true);
      if(!joints[0].ready) init();
      rig.getWorldQuaternion(rigInv).invert();
      /* the body moved: the free ends lag behind (cheat: shift them the other way, only part of the way) */
      if(mx||my){ shift.set(-mx,-my,0).applyQuaternion(rigInv); const f=0.55; shift.multiplyScalar(f); for(const j of joints){ j.cur.add(shift); j.prev.add(shift); } }
      const n=Math.min(3,Math.max(1,Math.ceil(dt*60))), h=dt/n;
      for(let s=0;s<n;s++){
        for(const j of joints){
          const nd=j.n, P=nd.parent; if(!P) continue;
          P.getWorldQuaternion(pq).premultiply(rigInv); pqi.copy(pq).invert();
          nd.getWorldPosition(tmp); toRig(tmp,head);
          rd.copy(j.tl).applyQuaternion(j.restQ).applyQuaternion(pq);
          nxt.copy(j.cur).addScaledVector(dir.subVectors(j.cur,j.prev),1-Math.min(0.98,j.p.drag));
          nxt.addScaledVector(rd,j.p.stiff*h*k);
          nxt.addScaledVector(j.p.gdir,j.p.grav*h*k);
          nxt.sub(head).setLength(j.len).add(head);
          /* stay out of the body spheres */
          for(const g of j.cgs) for(const sp of g.spheres){
            cw.copy(sp.off).applyMatrix4(sp.node.matrixWorld); toRig(cw,cw);
            const R=sp.r*k+j.p.hit; dir.subVectors(nxt,cw); const d=dir.length();
            if(d<R&&d>1e-6){ nxt.copy(cw).addScaledVector(dir,R/d); nxt.sub(head).setLength(j.len).add(head); }
          }
          j.prev.copy(j.cur); j.cur.copy(nxt);
          /* turn the bone so it points at the new tail */
          dir.subVectors(nxt,head).normalize().applyQuaternion(pqi);
          rd.copy(j.tl).applyQuaternion(j.restQ);
          dq.setFromUnitVectors(rd,dir);
          nd.quaternion.copy(dq).multiply(j.restQ);
          nd.updateMatrixWorld(true);
        }
      }
    }
  };
}
